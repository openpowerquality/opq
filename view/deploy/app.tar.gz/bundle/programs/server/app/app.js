var require = meteorInstall({"imports":{"api":{"base":{"BaseCollection.js":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// imports/api/base/BaseCollection.js                                                                                  //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
let Meteor;
module.watch(require("meteor/meteor"), {
  Meteor(v) {
    Meteor = v;
  }

}, 0);
let Mongo;
module.watch(require("meteor/mongo"), {
  Mongo(v) {
    Mongo = v;
  }

}, 1);
let SimpleSchema;
module.watch(require("simpl-schema"), {
  default(v) {
    SimpleSchema = v;
  }

}, 2);

let _;

module.watch(require("lodash"), {
  default(v) {
    _ = v;
  }

}, 3);
let Moment;
module.watch(require("moment"), {
  default(v) {
    Moment = v;
  }

}, 4);

/**
 * BaseCollection is an abstract superclass of all other collection classes.
 */
class BaseCollection {
  /**
   * Superclass constructor for all collections.
   * Defines internal fields required by all collections.
   * @param {String} collectionName - The name of the collection.
   * @param {Object} schema - The SimpleSchema instance that defines this collection's schema.
   */
  constructor(collectionName, schema) {
    if (typeof collectionName !== 'string') throw new Meteor.Error('collectionName must be a String.');
    if (!(schema instanceof SimpleSchema)) throw new Meteor.Error('schema must be a SimpleSchema instance.');
    this._collectionName = collectionName;
    this._schema = schema;
    this._collection = new Mongo.Collection(collectionName, {
      idGeneration: 'MONGO'
    });

    this._collection.attachSchema(schema);
  }
  /**
   * Returns the schema (SimpleSchema) associated with this collection.
   * @returns {SimpleSchema} - The SimpleSchema instance.
   */


  getSchema() {
    return this._schema;
  }
  /**
   * Returns the number of documents in this collection.
   * @returns {Number} - The number of documents in the collection.
   */


  count() {
    return this._collection.find().count();
  }
  /**
   * Returns the number of documents in this collection with a UTC millisecond timestamp greater than today's
   * date at midnight.
   * @param timeField The name of the field containing a timestamp in UTC millisecond format.
   * @returns The number of documents whose timestamp is from today.
   */


  countToday(timeField) {
    const startToday = Moment().startOf('day').valueOf();
    const query = {};
    query[timeField] = {
      $gte: startToday
    };
    return this._collection.find(query).count();
  }
  /**
   * Calls the MongoDB native find() on this collection.
   * @see {@link http://docs.meteor.com/api/collections.html#Mongo-Collection-find|Meteor Docs Mongo.Collection.find()}
   * @param {Object} selector - A MongoDB selector object.
   * @param {Object} options - A MongoDB options object.
   * @returns {Cursor} - The MongoDB cursor containing the results of the query.
   */


  find(selector = {}, options = {}) {
    return this._collection.find(selector, options);
  }
  /**
   * Calls the MongoDB native findOne() on this collection.
   * @see {@link http://docs.meteor.com/api/collections.html#Mongo-Collection-findOne|
   * Meteor Docs Mongo.Collection.findOne()}
   * @param {Object} selector - A MongoDB selector object.
   * @param {Object} options - A MongoDB options object.
   * @returns {Object} - The document containing the results of the query.
   */


  findOne(selector = {}, options = {}) {
    return this._collection.findOne(selector, options);
  }
  /**
   * Returns true if the passed entity is in this collection.
   * @param { String | Object } name The docID, or an object specifying a document.
   * @returns {boolean} True if name exists in this collection.
   */


  isDefined(name) {
    return !!this._collection.findOne(name) || !!this._collection.findOne({
      name
    }) || !!this._collection.findOne({
      _id: name
    });
  }
  /**
   * Update the collection.
   * @param selector
   * @param modifier
   * @param options
   * @returns {any}
   */


  update(selector = {}, modifier = {}, options = {}) {
    return this._collection.update(selector, modifier, options);
  }
  /**
   * Default publication of collection (publishes entire collection). Derived classes will often override with
   * their own publish() method, as its generally a bad idea to publish the entire collection to the client.
   */


  publish() {
    if (Meteor.isServer) {
      Meteor.publish(this._collectionName, () => this._collection.find());
    }
  }
  /**
   * Default version of getPublicationName returns the single publication name.
   * Derived classes many need to override this method as well.
   * @returns The default publication name.
   */


  getPublicationName() {
    return this._collectionName;
  }
  /**
   * Returns an object representing the definition of docID in a format appropriate to the restoreOne function.
   * Must be overridden by each collection.
   * @param docID - A docID from this collection.
   * @returns { Object } - An object representing this document.
   */


  dumpOne(docID) {
    // eslint-disable-line no-unused-vars
    throw new Meteor.Error(`Default dumpOne method invoked by collection ${this._collectionName}`);
  }
  /**
   * Dumps the entire collection as a single object with two fields: name and contents.
   * The name is the name of the collection.
   * The contents is an array of all documents within the collection. These documents are generated using the
   * dumpOne() method and subsequently are meant to be used with the restore() method.
   * @returns {Object} An object representing the contents of this collection.
   */


  dumpAll() {
    return {
      name: this._collectionName,
      contents: this.find().map(doc => this.dumpOne(doc._id))
    };
  }
  /**
   * Finds and returns the entire document of the given docID.
   * @param {Object} docID - The Mongo.ObjectID of the document to find.
   * @returns {Object} - The found document.
   */


  findDoc(docID) {
    const doc = this.findOne({
      _id: docID
    }, {});

    if (!doc) {
      throw new Meteor.Error(`Could not find document with docID: ${docID} in collection: ${this._collectionName}.`);
    }

    return doc;
  }
  /**
   * Defines the default integrity checker for the base collection. Derived classes are responsible for implementing
   * their own integrity checker, if it is needed.
   * @returns {[String]} - Array containing a string indicating the use of the default integrity checker.
   */


  checkIntegrity() {
    // eslint-disable-line class-methods-use-this
    return ['There is no integrity checker defined for this collection.'];
  }
  /**
   * Defines a single collection document represented by dumpObject.
   * @returns {String} - The newly created document ID.
   */


  restoreOne(dumpObject) {
    if (typeof this.define === 'function') {
      return this.define(dumpObject);
    }

    return null;
  }
  /**
   * Defines each collection entity given by the passed array of dumpObjects.
   * @param dumpObjects - The array of objects representing entities of the collection.
   */


  restoreAll(dumpObjects) {
    _.each(dumpObjects, dumpObject => this.restoreOne(dumpObject));
  }
  /**
   * Removes all elements of this collection.
   * This is implemented by mapping through all elements because mini-mongo does not implement the remove operation.
   * So this approach can be used on both client and server side.
   * removeAll should only used for testing purposes, so it doesn't need to be efficient.
   * @returns true
   */


  removeAll() {
    const items = this._collection.find().fetch();

    const instance = this;

    _.forEach(items, i => {
      instance.remove(i._id);
    });

    return true;
  }
  /**
   * Default remove function calls remove with the docID.
   * @param docID The docID of the document to be removed.
   */


  remove(docID) {
    this._collection.remove(docID);
  }

}

module.exportDefault(BaseCollection);
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"box-events":{"BoxEventsCollection.js":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// imports/api/box-events/BoxEventsCollection.js                                                                       //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
module.export({
  BoxEvents: () => BoxEvents
});
let Meteor;
module.watch(require("meteor/meteor"), {
  Meteor(v) {
    Meteor = v;
  }

}, 0);
let Mongo;
module.watch(require("meteor/mongo"), {
  Mongo(v) {
    Mongo = v;
  }

}, 1);
let SimpleSchema;
module.watch(require("simpl-schema"), {
  default(v) {
    SimpleSchema = v;
  }

}, 2);
let BaseCollection;
module.watch(require("../base/BaseCollection.js"), {
  default(v) {
    BaseCollection = v;
  }

}, 3);
let Events;
module.watch(require("../events/EventsCollection"), {
  Events(v) {
    Events = v;
  }

}, 4);
let progressBarSetup;
module.watch(require("../../modules/utils"), {
  progressBarSetup(v) {
    progressBarSetup = v;
  }

}, 5);

/**
 * Collection class for the box_events collection.
 * Docs: https://open-power-quality.gitbooks.io/open-power-quality-manual/content/datamodel/description.html#box_events
 */
class BoxEventsCollection extends BaseCollection {
  /**
   * Creates the collection.
   */
  constructor() {
    super('box_events', new SimpleSchema({
      _id: {
        type: Mongo.ObjectID
      },
      event_id: Number,
      box_id: String,
      event_start_timestamp_ms: Number,
      event_end_timestamp_ms: Number,
      window_timestamps_ms: [Number],
      // For research purposes.
      thd: Number,
      itic: String,
      location: {
        type: Object,
        optional: true
      },
      'location.start_time': {
        type: Number,
        optional: true
      },
      'location.zipcode': {
        type: Number,
        optional: true
      },
      data_fs_filename: String // Stores the GridFs filename. Format is 'event_eventNumber_boxId'

    }));
    this.publicationNames = {
      EVENT_DATA: 'event_data'
    };

    if (Meteor.server) {
      this._collection.rawCollection().createIndex({
        event_start_timestamp_ms: 1,
        box_id: 1
      }, {
        background: true
      });
    }
  }
  /**
   * Defines a new BoxEvent document.
   * @param {Number} event_id - The event_id associated with the BoxEvent.
   * @param {String} box_id - The box_id associated with the BoxEvent.
   * @param {Number} event_start - The start timestamp (unix milliseconds) of the event.
   * @param {Number} event_end - The end timestamp (unix milliseconds) of the event.
   * @param {[Number]} window_timestamps - An array of timestamps, for research purposes. See docs for details.
   * @param {Number} thd - The total harmonic distortion value of the event.
   * @param {String} itic - The ITIC value of the event.
   * @param {Object} location - The location of the OPQBox at the time of the event.
   * @param {String} data_fs_filename - The GridFS filename holding the actual event waveform data.
   * @returns The newly created document ID.
   */


  define({
    event_id,
    box_id,
    event_start,
    event_end,
    window_timestamps,
    thd,
    itic,
    location,
    data_fs_filename
  }) {
    const docID = this._collection.insert({
      event_id,
      box_id,
      event_start,
      event_end,
      window_timestamps,
      thd,
      itic,
      location,
      data_fs_filename
    });

    return docID;
  }
  /**
   * Returns an object representing a single BoxEvent.
   * @param {Object} docID - The Mongo.ObjectID of the BoxEvent.
   * @returns {Object} - An object representing a single BoxEvent.
   */


  dumpOne(docID) {
    /* eslint-disable camelcase */
    const doc = this.findDoc(docID);
    const event_id = doc.event_id;
    const box_id = doc.box_id;
    const event_start = doc.event_start;
    const event_end = doc.event_end;
    const window_timestamps = doc.window_timestamps;
    const thd = doc.thd;
    const itic = doc.itic;
    const location = doc.location;
    const data_fs_filename = doc.data_fs_filename;
    return {
      event_id,
      box_id,
      event_start,
      event_end,
      window_timestamps,
      thd,
      itic,
      location,
      data_fs_filename
    };
    /* eslint-enable camelcase */
  }

  checkIntegrity() {
    const problems = [];
    const totalCount = this.count();
    const validationContext = this.getSchema().namedContext('boxEventsIntegrity');
    const pb = progressBarSetup(totalCount, 2000, `Checking ${this._collectionName} collection: `);
    this.find().forEach((doc, index) => {
      pb.updateBar(index); // Update progress bar.
      // Validate each document against the collection schema.

      validationContext.validate(doc);

      if (!validationContext.isValid()) {
        // eslint-disable-next-line max-len
        problems.push(`BoxEvent document failed schema validation: ${doc._id} (Invalid keys: ${JSON.stringify(validationContext.invalidKeys(), null, 2)})`);
      }

      validationContext.resetValidation(); // Ensure event_id points to an existing Event document.

      if (Events.find({
        event_id: doc.event_id
      }).count() < 1) {
        // eslint-disable-next-line max-len
        problems.push(`BoxEvent's event_id does not exist in Events collection: ${doc._id} (event_id: ${doc.event_id})`);
      }
    });
    pb.clearInterval();
    return problems;
  }
  /**
   * Loads all publications related to this collection.
   */


  publish() {
    // eslint-disable-line class-methods-use-this
    if (Meteor.isServer) {// eslint-disable-line no-empty
    }
  }

}
/**
 * Provides the singleton instance of this class.
 * @type {BoxEventsCollection}
 */


const BoxEvents = new BoxEventsCollection();
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"BoxEventsCollectionMethods.js":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// imports/api/box-events/BoxEventsCollectionMethods.js                                                                //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
module.export({
  totalBoxEventsCount: () => totalBoxEventsCount,
  getBoxEvent: () => getBoxEvent
});
let Meteor;
module.watch(require("meteor/meteor"), {
  Meteor(v) {
    Meteor = v;
  }

}, 0);
let ValidatedMethod;
module.watch(require("meteor/mdg:validated-method"), {
  ValidatedMethod(v) {
    ValidatedMethod = v;
  }

}, 1);
let SimpleSchema;
module.watch(require("simpl-schema"), {
  default(v) {
    SimpleSchema = v;
  }

}, 2);
let BoxEvents;
module.watch(require("./BoxEventsCollection.js"), {
  BoxEvents(v) {
    BoxEvents = v;
  }

}, 3);
const totalBoxEventsCount = new ValidatedMethod({
  name: 'BoxEvents.totalBoxEventsCount',
  validate: new SimpleSchema().validator({
    clean: true
  }),

  run() {
    return BoxEvents.find({}).count();
  }

});
const getBoxEvent = new ValidatedMethod({
  name: 'BoxEvents.getBoxEvent',
  validate: new SimpleSchema({
    event_id: {
      type: Number
    },
    box_id: {
      type: String
    }
  }).validator({
    clean: true
  }),

  run({
    event_id,
    box_id
  }) {
    if (!this.isSimulation) {
      const boxEvent = BoxEvents.findOne({
        event_id,
        box_id
      }, {}); // eslint-disable-next-line max-len, camelcase

      if (!boxEvent) throw new Meteor.Error('BoxEvents document not found', `Document not found for event_number: ${event_id}, box_id: ${box_id}`);
      return boxEvent;
    }

    return null;
  }

});
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"index.js":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// imports/api/box-events/index.js                                                                                     //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
module.watch(require("./BoxEventsCollection.js"));
module.watch(require("./BoxEventsCollectionMethods.js"));
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"events":{"EventsCollection.js":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// imports/api/events/EventsCollection.js                                                                              //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
module.export({
  Events: () => Events
});
let Meteor;
module.watch(require("meteor/meteor"), {
  Meteor(v) {
    Meteor = v;
  }

}, 0);
let Mongo;
module.watch(require("meteor/mongo"), {
  Mongo(v) {
    Mongo = v;
  }

}, 1);
let check, Match;
module.watch(require("meteor/check"), {
  check(v) {
    check = v;
  },

  Match(v) {
    Match = v;
  }

}, 2);
let SimpleSchema;
module.watch(require("simpl-schema"), {
  default(v) {
    SimpleSchema = v;
  }

}, 3);
let BaseCollection;
module.watch(require("../base/BaseCollection.js"), {
  default(v) {
    BaseCollection = v;
  }

}, 4);
let progressBarSetup;
module.watch(require("../../modules/utils"), {
  progressBarSetup(v) {
    progressBarSetup = v;
  }

}, 5);

/**
 * Collection class for the events collection.
 * Docs: https://open-power-quality.gitbooks.io/open-power-quality-manual/content/datamodel/description.html#events
 */
class EventsCollection extends BaseCollection {
  /**
   * Creates the collection.
   */
  constructor() {
    super('events', new SimpleSchema({
      _id: {
        type: Mongo.ObjectID
      },
      event_id: Number,
      type: String,
      description: String,
      boxes_triggered: [String],
      boxes_received: [String],
      target_event_start_timestamp_ms: Number,
      target_event_end_timestamp_ms: Number,
      latencies_ms: {
        type: Array,
        optional: true
      },
      'latencies_ms.$': Number
    }));
    this.eventTypes = ['FREQUENCY_SAG', 'FREQUENCY_SWELL', 'VOLTAGE_SAG', 'VOLTAGE_SWELL', 'THD', 'OTHER'];
    this.FREQUENCY_SAG_TYPE = 'FREQUENCY_SAG';
    this.FREQUENCY_SWELL_TYPE = 'FREQUENCY_SWELL';
    this.VOLTAGE_SAG_TYPE = 'VOLTAGE_SAG';
    this.VOLTAGE_SWELL_TYPE = 'VOLTAGE_SWELL';
    this.THD_TYPE = 'THD';
    this.OTHER_TYPE = 'OTHER';
    this.publicationNames = {
      GET_EVENTS: 'get_events',
      GET_RECENT_EVENTS: 'get_recent_events'
    };

    if (Meteor.server) {
      this._collection.rawCollection().createIndex({
        target_event_start_timestamp_ms: 1
      }, {
        background: true
      });
    }
  }
  /**
   * Defines a new Event document.
   * @param {Number} event_id - The event's id value (not Mongo ID)
   * @param {String} type - The unix timestamp (millis) of the measurement.
   * @param {String} description - The description of the event.
   * @param {String} boxes_triggered - The OPQBoxes from which data was requested for this event.
   * @param {Number} latencies - Array of unix timestamps for the event. See docs for details.
   * @returns The newly created document ID.
   */


  define({
    event_id,
    type,
    description,
    boxes_triggered,
    boxes_received,
    target_event_start_timestamp_ms,
    target_event_end_timestamp_ms,
    latencies_ms
  }) {
    const docID = this._collection.insert({
      event_id,
      type,
      description,
      boxes_triggered,
      boxes_received,
      target_event_start_timestamp_ms,
      target_event_end_timestamp_ms,
      latencies_ms
    });

    return docID;
  }
  /**
   * Returns an object representing a single Event.
   * @param {Object} docID - The Mongo.ObjectID of the Event.
   * @returns {Object} - An object representing a single Event.
   */


  dumpOne(docID) {
    /* eslint-disable camelcase */
    const doc = this.findDoc(docID);
    const event_id = doc.event_id;
    const type = doc.type;
    const description = doc.description;
    const boxes_triggered = doc.boxes_triggered;
    const boxes_received = doc.boxes_received;
    const target_event_start_timestamp_ms = doc.target_event_start_timestamp_ms;
    const target_event_end_timestamp_ms = doc.target_event_end_timestamp_ms;
    const latencies_ms = doc.latencies_ms;
    return {
      event_id,
      type,
      description,
      boxes_triggered,
      boxes_received,
      target_event_start_timestamp_ms,
      target_event_end_timestamp_ms,
      latencies_ms
    };
    /* eslint-enable camelcase */
  }

  checkIntegrity() {
    const problems = [];
    const totalCount = this.count();
    const validationContext = this.getSchema().namedContext('eventsIntegrity');
    const pb = progressBarSetup(totalCount, 2000, `Checking ${this._collectionName} collection: `);
    this.find().forEach((doc, index) => {
      pb.updateBar(index); // Update progress bar.
      // Validate each document against the collection schema.

      validationContext.validate(doc);

      if (!validationContext.isValid()) {
        // eslint-disable-next-line max-len
        problems.push(`Events document failed schema validation: ${doc._id} (Invalid keys: ${JSON.stringify(validationContext.invalidKeys(), null, 2)})`);
      }

      validationContext.resetValidation();
    });
    pb.clearInterval();
    return problems;
  }
  /**
   * Loads all publications related to this collection.
   */


  publish() {
    if (Meteor.isServer) {
      const self = this;
      Meteor.publish(this.publicationNames.GET_EVENTS, function ({
        startTime,
        endTime
      }) {
        check(startTime, Match.Maybe(Number));
        check(endTime, Match.Maybe(Number));
        const selector = self.queryConstructors().getEvents({
          startTime,
          endTime
        });
        return self.find(selector);
      });
      Meteor.publish(this.publicationNames.GET_RECENT_EVENTS, function ({
        numEvents,
        excludeOther
      }) {
        check(numEvents, Number);
        const query = excludeOther ? {
          type: {
            $ne: 'OTHER'
          }
        } : {};
        const events = self.find(query, {
          sort: {
            target_event_start_timestamp_ms: -1
          },
          limit: numEvents
        });
        return events;
      });
    }
  }

  queryConstructors() {
    // eslint-disable-line class-methods-use-this
    return {
      getEvents({
        startTime,
        endTime
      }) {
        check(startTime, Match.Maybe(Number));
        check(endTime, Match.Maybe(Number));
        const selector = {};
        if (startTime) selector.target_event_start_timestamp_ms = {
          $gte: startTime
        };
        if (endTime) selector.target_event_end_timestamp_ms = {
          $lte: endTime
        };
        return selector;
      }

    };
  }

}
/**
 * Provides the singleton instance of this class.
 * @type {EventsCollection}
 */


const Events = new EventsCollection();
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"EventsCollectionMethods.js":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// imports/api/events/EventsCollectionMethods.js                                                                       //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
module.export({
  totalEventsCount: () => totalEventsCount,
  eventsCountMap: () => eventsCountMap,
  getEventByEventID: () => getEventByEventID,
  getMostRecentEvent: () => getMostRecentEvent
});
let ValidatedMethod;
module.watch(require("meteor/mdg:validated-method"), {
  ValidatedMethod(v) {
    ValidatedMethod = v;
  }

}, 0);
let SimpleSchema;
module.watch(require("simpl-schema"), {
  default(v) {
    SimpleSchema = v;
  }

}, 1);
let demapify;
module.watch(require("es6-mapify"), {
  demapify(v) {
    demapify = v;
  }

}, 2);
let Events;
module.watch(require("./EventsCollection.js"), {
  Events(v) {
    Events = v;
  }

}, 3);
let timeUnitString;
module.watch(require("../../modules/utils.js"), {
  timeUnitString(v) {
    timeUnitString = v;
  }

}, 4);
const totalEventsCount = new ValidatedMethod({
  name: 'Events.totalEventsCount',
  validate: new SimpleSchema().validator({
    clean: true
  }),

  run() {
    return Events.find({}).count();
  }

});
const eventsCountMap = new ValidatedMethod({
  name: 'Events.eventsCountMap',
  validate: new SimpleSchema({
    timeUnit: {
      type: String
    },
    startTime: {
      type: Number
    },
    endTime: {
      type: Number,
      optional: true
    }
  }).validator({
    clean: true
  }),

  run({
    timeUnit,
    startTime,
    endTime
  }) {
    // TimeUnits can be year, month, week, day, dayOfMonth, hourOfDay
    const selector = Events.queryConstructors().getEvents({
      startTime,
      endTime
    });
    const eventMetaData = Events.find(selector);
    const eventCountMap = new Map();
    eventMetaData.forEach(event => {
      const timeUnitKey = timeUnitString(event.target_event_start_timestamp_ms, timeUnit);

      if (eventCountMap.has(timeUnitKey)) {
        eventCountMap.set(timeUnitKey, eventCountMap.get(timeUnitKey) + 1);
      } else {
        eventCountMap.set(timeUnitKey, 1);
      }
    });
    return demapify(eventCountMap);
  }

});
const getEventByEventID = new ValidatedMethod({
  name: 'Events.getEventByEventID',
  validate: new SimpleSchema({
    event_id: {
      type: Number
    }
  }).validator({
    clean: true
  }),

  run({
    event_id
  }) {
    const eventMetaData = Events.findOne({
      event_id
    }, {});
    return eventMetaData;
  }

});
const getMostRecentEvent = new ValidatedMethod({
  name: 'Events.getMostRecentEvent',
  validate: new SimpleSchema({}).validator({
    clean: true
  }),

  run() {
    const mostRecentEvent = Events.findOne({}, {
      sort: {
        target_event_start_timestamp_ms: -1
      }
    });
    return mostRecentEvent;
  }

});
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"index.js":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// imports/api/events/index.js                                                                                         //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
module.watch(require("./EventsCollection.js"));
module.watch(require("./EventsCollectionMethods.js"));
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"fs-chunks":{"FSChunksCollection.js":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// imports/api/fs-chunks/FSChunksCollection.js                                                                         //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
module.export({
  FSChunks: () => FSChunks
});
let Meteor;
module.watch(require("meteor/meteor"), {
  Meteor(v) {
    Meteor = v;
  }

}, 0);
let Mongo;
module.watch(require("meteor/mongo"), {
  Mongo(v) {
    Mongo = v;
  }

}, 1);
let SimpleSchema;
module.watch(require("simpl-schema"), {
  default(v) {
    SimpleSchema = v;
  }

}, 2);
let BaseCollection;
module.watch(require("../base/BaseCollection.js"), {
  default(v) {
    BaseCollection = v;
  }

}, 3);
let FSFiles;
module.watch(require("../fs-files/FSFilesCollection"), {
  FSFiles(v) {
    FSFiles = v;
  }

}, 4);
let progressBarSetup;
module.watch(require("../../modules/utils"), {
  progressBarSetup(v) {
    progressBarSetup = v;
  }

}, 5);

/**
 * Collection class for the fs.chunks collection.
 * Docs: https://open-power-quality.gitbooks.io/open-power-quality-manual/content/datamodel/description.html#box_events
 */
class FSChunksCollection extends BaseCollection {
  /**
   * Creates the collection.
   */
  constructor() {
    super('fs.chunks', new SimpleSchema({
      _id: {
        type: Mongo.ObjectID
      },
      files_id: {
        type: Mongo.ObjectID
      },
      n: Number,
      data: Uint8Array
    }));
    this.publicationNames = {};
  }
  /**
   * Defines a new fs.chunks document.
   * @param {ObjectID} files_id - The ObjectID of the corresponding fs.files document.
   * @param {Number} n - The number of chunks.
   * @param {Object} data - The binary for this chunk.
   * @returns The newly created document ID.
   */


  define({
    files_id,
    n,
    data
  }) {
    const docID = this._collection.insert({
      files_id,
      n,
      data
    });

    return docID;
  }
  /**
   * Returns an object representing a single fs.chunk.
   * @param {Object} docID - The Mongo.ObjectID of the fs.chunk document.
   * @returns {Object} - An object representing a single fs.chunk document.
   */


  dumpOne(docID) {
    /* eslint-disable camelcase */
    const doc = this.findDoc(docID);
    const files_id = doc.files_id;
    const n = doc.n;
    const data = doc.data;
    return {
      files_id,
      n,
      data
    };
    /* eslint-enable camelcase */
  }

  checkIntegrity() {
    const problems = [];
    const totalCount = this.count();
    const validationContext = this.getSchema().namedContext('fsFilesIntegrity');
    const pb = progressBarSetup(totalCount, 2000, `Checking ${this._collectionName} collection: `);
    this.find().forEach((doc, index) => {
      pb.updateBar(index); // Update progress bar.
      // Validate each document against the collection schema.

      validationContext.validate(doc);

      if (!validationContext.isValid()) {
        // eslint-disable-next-line max-len
        problems.push(`FS.Chunks document failed schema validation: ${doc._id} (Invalid keys: ${JSON.stringify(validationContext.invalidKeys(), null, 2)})`);
      }

      validationContext.resetValidation(); // Ensure files_id points to valid fs.files document.

      const fsFile = FSFiles.findOne({
        _id: doc.files_id
      });

      if (!fsFile) {
        problems.push(`FS.Chunks files_id does match an existing FS.Files document: ${doc._id}`);
      }
    });
    pb.clearInterval();
    return problems;
  }
  /**
   * Loads all publications related to this collection.
   */


  publish() {
    // eslint-disable-line class-methods-use-this
    if (Meteor.isServer) {// eslint-disable-line no-empty
    }
  }

}
/**
 * Provides the singleton instance of this class.
 * @type {FSChunksCollection}
 */


const FSChunks = new FSChunksCollection();
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"index.js":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// imports/api/fs-chunks/index.js                                                                                      //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
module.watch(require("./FSChunksCollection.js"));
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"fs-files":{"FSFilesCollection.js":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// imports/api/fs-files/FSFilesCollection.js                                                                           //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
module.export({
  FSFiles: () => FSFiles
});
let Meteor;
module.watch(require("meteor/meteor"), {
  Meteor(v) {
    Meteor = v;
  }

}, 0);
let Mongo;
module.watch(require("meteor/mongo"), {
  Mongo(v) {
    Mongo = v;
  }

}, 1);
let SimpleSchema;
module.watch(require("simpl-schema"), {
  default(v) {
    SimpleSchema = v;
  }

}, 2);
let BaseCollection;
module.watch(require("../base/BaseCollection.js"), {
  default(v) {
    BaseCollection = v;
  }

}, 3);
let Events;
module.watch(require("../events/EventsCollection"), {
  Events(v) {
    Events = v;
  }

}, 4);
let BoxEvents;
module.watch(require("../box-events/BoxEventsCollection"), {
  BoxEvents(v) {
    BoxEvents = v;
  }

}, 5);
let progressBarSetup;
module.watch(require("../../modules/utils"), {
  progressBarSetup(v) {
    progressBarSetup = v;
  }

}, 6);

/**
 * Collection class for the fs.files collection.
 * Docs: https://open-power-quality.gitbooks.io/open-power-quality-manual/content/datamodel/description.html#box_events
 */
class FSFilesCollection extends BaseCollection {
  /**
   * Creates the collection.
   */
  constructor() {
    super('fs.files', new SimpleSchema({
      _id: {
        type: Mongo.ObjectID
      },
      filename: String,
      length: {
        type: Number
      },
      chunkSize: {
        type: Number
      },
      uploadDate: {
        type: Date
      },
      md5: {
        type: String
      },
      metadata: {
        type: Object
      },
      'metadata.event_id': {
        type: Number
      },
      'metadata.box_id': {
        type: String
      }
    }));
    this.publicationNames = {};
  }
  /**
   * Defines a new fs.files document.
   * @param {String} filename - The filename, which corresponds to box_event's data_fs_filename field.
   * @param {Number} length - The size of data.
   * @param {Number} chunkSize - The max size of chunks.
   * @param {Number} uploadDate - The creation date.
   * @param {String} md5 - The file md5.
   * @param {Object} metadata - Object that holds the event's event_id and box_id.
   * @returns The newly created document ID.
   */


  define({
    filename,
    length,
    chunkSize,
    uploadDate,
    md5,
    metadata
  }) {
    const docID = this._collection.insert({
      filename,
      length,
      chunkSize,
      uploadDate,
      md5,
      metadata
    });

    return docID;
  }
  /**
   * Returns an object representing a single fs.file.
   * @param {Object} docID - The Mongo.ObjectID of the fs.files document.
   * @returns {Object} - An object representing a single fs.files document.
   */


  dumpOne(docID) {
    /* eslint-disable camelcase */
    const doc = this.findDoc(docID);
    const filename = doc.filename;
    const length = doc.length;
    const chunkSize = doc.chunkSize;
    const uploadDate = doc.uploadDate;
    const md5 = doc.md5;
    const metadata = doc.metadata;
    return {
      filename,
      length,
      chunkSize,
      uploadDate,
      md5,
      metadata
    };
    /* eslint-enable camelcase */
  }

  checkIntegrity() {
    const problems = [];
    const totalCount = this.count();
    const validationContext = this.getSchema().namedContext('fsFilesIntegrity');
    const pb = progressBarSetup(totalCount, 2000, `Checking ${this._collectionName} collection: `);
    this.find().forEach((doc, index) => {
      pb.updateBar(index); // Update progress bar.
      // Validate each document against the collection schema.

      validationContext.validate(doc);

      if (!validationContext.isValid()) {
        // eslint-disable-next-line max-len
        problems.push(`FS.Files document failed schema validation: ${doc._id} (Invalid keys: ${JSON.stringify(validationContext.invalidKeys(), null, 2)})`);
      }

      validationContext.resetValidation();
      const event = Events.findOne({
        event_id: doc.metadata.event_id
      }); // Ensure metadata.event_id points to an existing Event document.

      if (!event) {
        problems.push(`FS.Files metadata.event_id does not exist in Events collection: ${doc._id}`);
      } // Ensure metadata.event_id and metadata.box_id points to an existing BoxEvent document.


      const boxEvent = BoxEvents.findOne({
        event_id: doc.metadata.event_id,
        box_id: doc.metadata.box_id
      });

      if (!boxEvent) {
        // eslint-disable-next-line max-len
        problems.push(`FS.Files metadata.event_id and metadata_box_id pair does not exist in the BoxEvents collection: ${doc._id}`);
      }
    });
    pb.clearInterval();
    return problems;
  }
  /**
   * Loads all publications related to this collection.
   */


  publish() {
    // eslint-disable-line class-methods-use-this
    if (Meteor.isServer) {// eslint-disable-line no-empty
    }
  }

}
/**
 * Provides the singleton instance of this class.
 * @type {FSFilesCollection}
 */


const FSFiles = new FSFilesCollection();
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"FSFilesCollectionMethods.js":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// imports/api/fs-files/FSFilesCollectionMethods.js                                                                    //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
module.export({
  getEventData: () => getEventData
});
let ValidatedMethod;
module.watch(require("meteor/mdg:validated-method"), {
  ValidatedMethod(v) {
    ValidatedMethod = v;
  }

}, 0);
let SimpleSchema;
module.watch(require("simpl-schema"), {
  default(v) {
    SimpleSchema = v;
  }

}, 1);
let FSFiles;
module.watch(require("./FSFilesCollection"), {
  FSFiles(v) {
    FSFiles = v;
  }

}, 2);
let FSChunks;
module.watch(require("../fs-chunks/FSChunksCollection"), {
  FSChunks(v) {
    FSChunks = v;
  }

}, 3);
const getEventData = new ValidatedMethod({
  name: 'FSFiles.getEventData',
  validate: new SimpleSchema({
    filename: {
      type: String
    }
  }).validator({
    clean: true
  }),

  run({
    filename
  }) {
    if (!this.isSimulation) {
      // Get file and chunks
      const file = FSFiles.findOne({
        filename
      });
      const chunks = FSChunks.find({
        files_id: file._id
      }, {
        sort: {
          n: 1
        }
      }).fetch(); // Gridfs seems to store chunks as
      // Need to parse binary data chunks as 16-bit signed int.

      const int16Chunks = []; // Array of chunks.

      let totalSize = 0;
      chunks.forEach(chunk => {
        const u8 = new Uint8Array(chunk.data);
        const s16 = new Int16Array(u8.buffer);
        int16Chunks.push(s16);
        totalSize += s16.length;
      }); // Flatten/combine all chunks to a single array.

      const combinedInt16Chunks = new Int16Array(totalSize);
      let offset = 0;
      int16Chunks.forEach(chunk => {
        combinedInt16Chunks.set(chunk, offset);
        offset += chunk.length;
      });
      return Array.from(combinedInt16Chunks); // Return data as regular array.
    }

    return null;
  }

});
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"index.js":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// imports/api/fs-files/index.js                                                                                       //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
module.watch(require("./FSFilesCollection.js"));
module.watch(require("./FSFilesCollectionMethods.js"));
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"measurements":{"MeasurementsCollection.js":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// imports/api/measurements/MeasurementsCollection.js                                                                  //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
module.export({
  Measurements: () => Measurements
});
let Meteor;
module.watch(require("meteor/meteor"), {
  Meteor(v) {
    Meteor = v;
  }

}, 0);
let Mongo;
module.watch(require("meteor/mongo"), {
  Mongo(v) {
    Mongo = v;
  }

}, 1);
let check;
module.watch(require("meteor/check"), {
  check(v) {
    check = v;
  }

}, 2);
let SimpleSchema;
module.watch(require("simpl-schema"), {
  default(v) {
    SimpleSchema = v;
  }

}, 3);
let BaseCollection;
module.watch(require("../base/BaseCollection.js"), {
  default(v) {
    BaseCollection = v;
  }

}, 4);
let OpqBoxes;
module.watch(require("../opq-boxes/OpqBoxesCollection"), {
  OpqBoxes(v) {
    OpqBoxes = v;
  }

}, 5);
let progressBarSetup;
module.watch(require("../../modules/utils"), {
  progressBarSetup(v) {
    progressBarSetup = v;
  }

}, 6);

class MeasurementsCollection extends BaseCollection {
  /**
   * Creates the Measurements collection.
   */
  constructor() {
    super('measurements', new SimpleSchema({
      _id: {
        type: Mongo.ObjectID
      },
      box_id: {
        type: String
      },
      timestamp_ms: {
        type: Number
      },
      voltage: {
        type: Number
      },
      frequency: {
        type: Number
      },
      thd: {
        type: Number,
        optional: true
      },
      expireAt: {
        type: Date
      }
    }));
    this.publicationNames = {
      RECENT_MEASUREMENTS: 'recent_measurements'
    };

    if (Meteor.server) {
      this._collection.rawCollection().createIndex({
        timestamp_ms: 1,
        box_id: 1
      }, {
        background: true
      });
    }
  }
  /**
   * Defines a new Measurement document.
   * @param {String} box_id - The OPQBox's id value (not Mongo ID)
   * @param {Number} timestamp_ms - The unix timestamp (millis) of the measurement.
   * @param {Number} voltage - The voltage measurement.
   * @param {Number} frequency - The frequency measurement.
   * @param {Number} thd - The thd measurement.
   * @returns The newly created document ID.
   */


  define({
    box_id,
    timestamp_ms,
    voltage,
    frequency,
    thd
  }) {
    const docID = this._collection.insert({
      box_id,
      timestamp_ms,
      voltage,
      frequency,
      thd
    });

    return docID;
  }
  /**
   * Returns an object representing a single Measurement.
   * @param {Object} docID - The Mongo.ObjectID of the Measurement.
   * @returns {Object} - An object representing a single Measurement.
   */


  dumpOne(docID) {
    /* eslint-disable camelcase */
    const doc = this.findDoc(docID);
    const box_id = doc.box_id;
    const timestamp_ms = doc.timestamp_ms;
    const voltage = doc.voltage;
    const frequency = doc.frequency;
    const thd = doc.thd;
    return {
      box_id,
      timestamp_ms,
      voltage,
      frequency,
      thd
    };
    /* eslint-enable camelcase */
  }

  checkIntegrity() {
    const problems = [];
    const totalCount = this.count();
    const validationContext = this.getSchema().namedContext('measurementsIntegrity');
    const pb = progressBarSetup(totalCount, 2000, `Checking ${this._collectionName} collection: `); // Get all OpqBox IDs.

    const boxIDs = OpqBoxes.find().map(doc => doc.box_id);
    this.find().forEach((doc, index) => {
      pb.updateBar(index); // Update progress bar.
      // Validate each document against the collection schema.

      validationContext.validate(doc);

      if (!validationContext.isValid()) {
        // eslint-disable-next-line max-len
        problems.push(`Measurements document failed schema validation: ${doc._id} (Invalid keys: ${JSON.stringify(validationContext.invalidKeys(), null, 2)})`);
      }

      validationContext.resetValidation(); // Ensure box_id of the measurement exists in opq_boxes collection.

      if (!boxIDs.includes(doc.box_id)) {
        problems.push(`Measurements box_id does not exist in opq_boxes collection: ${doc.box_id} (docID: ${doc._id})`);
      }
    });
    pb.clearInterval();
    return problems;
  }
  /**
   * Loads all publications related to the Measurements collection.
   * Note: We conditionally import the publications file only on the server as a way to hide publication code from
   * being sent to the client.
   */


  publish() {
    // eslint-disable-line class-methods-use-this
    if (Meteor.isServer) {
      const self = this;
      Meteor.publish(this.publicationNames.RECENT_MEASUREMENTS, function (startTimeSecondsAgo, boxID) {
        check(startTimeSecondsAgo, Number);
        check(boxID, String);
        const instance = this;
        const startTimeMs = Date.now() - startTimeSecondsAgo * 1000; // eslint-disable-next-line max-len

        const publishedMeasurementsMap = new Map(); // {timestamp: id} - To keep track of currently published measurements.

        const selector = boxID ? {
          box_id: boxID,
          timestamp_ms: {
            $gte: startTimeMs
          }
        } : {
          timestamp_ms: {
            $gte: startTimeMs
          }
        };
        let init = true;
        const measurementsHandle = self.find(selector, {
          fields: {
            _id: 1,
            timestamp_ms: 1,
            voltage: 1,
            frequency: 1,
            box_id: 1
          },
          pollingIntervalMs: 1000
        }).observeChanges({
          added: function (id, fields) {
            publishedMeasurementsMap.set(fields.timestamp_ms, id);
            instance.added('measurements', id, fields);

            if (!init) {
              const startTime = Date.now() - startTimeSecondsAgo * 1000; // Note: (_id, timestamp) corresponds to (value, key); for some reason Map's foreach is called this way.

              publishedMeasurementsMap.forEach((_id, timestamp) => {
                if (timestamp < startTime) {
                  instance.removed('measurements', _id);
                  publishedMeasurementsMap.delete(timestamp);
                }
              });
            }
          }
        });
        init = false;
        instance.ready();
        instance.onStop(function () {
          measurementsHandle.stop();
        });
      });
    }
  }

}
/**
 * Provides the singleton instance of this class.
 * @type {MeasurementsCollection}
 */


const Measurements = new MeasurementsCollection();
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"MeasurementsCollectionMethods.js":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// imports/api/measurements/MeasurementsCollectionMethods.js                                                           //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
module.export({
  totalMeasurementsCount: () => totalMeasurementsCount,
  checkBoxStatus: () => checkBoxStatus,
  activeBoxIDs: () => activeBoxIDs,
  getActiveBoxIds: () => getActiveBoxIds,
  getEventMeasurementsByMetaDataId: () => getEventMeasurementsByMetaDataId,
  getEventMeasurements: () => getEventMeasurements,
  dygraphMergeDatasets: () => dygraphMergeDatasets
});
let Mongo;
module.watch(require("meteor/mongo"), {
  Mongo(v) {
    Mongo = v;
  }

}, 0);

let _;

module.watch(require("lodash"), {
  default(v) {
    _ = v;
  }

}, 1);
let Moment;
module.watch(require("moment"), {
  default(v) {
    Moment = v;
  }

}, 2);
let ValidatedMethod;
module.watch(require("meteor/mdg:validated-method"), {
  ValidatedMethod(v) {
    ValidatedMethod = v;
  }

}, 3);
let SimpleSchema;
module.watch(require("simpl-schema"), {
  default(v) {
    SimpleSchema = v;
  }

}, 4);
let Measurements;
module.watch(require("./MeasurementsCollection.js"), {
  Measurements(v) {
    Measurements = v;
  }

}, 5);
let Events;
module.watch(require("../events/EventsCollection.js"), {
  Events(v) {
    Events = v;
  }

}, 6);
const totalMeasurementsCount = new ValidatedMethod({
  name: 'Measurements.totalMeasurementsCount',
  validate: new SimpleSchema().validator({
    clean: true
  }),

  run() {
    return Measurements.find({}).count();
  }

});
const checkBoxStatus = new ValidatedMethod({
  name: 'Measurements.checkBoxStatus',
  validate: new SimpleSchema({
    box_id: {
      type: String
    }
  }).validator({
    clean: true
  }),

  run({
    box_id
  }) {
    if (!this.isSimulation) {
      const oneMinuteAgo = Moment().subtract(60, 'seconds').valueOf();
      const measurements = Measurements.findOne({
        box_id,
        timestamp_ms: {
          $gte: oneMinuteAgo
        }
      });
      return !!measurements;
    }

    return null;
  }

});
const activeBoxIDs = new ValidatedMethod({
  name: 'Measurements.activeBoxIDs',
  validate: new SimpleSchema().validator({
    clean: true
  }),

  run() {
    if (!this.isSimulation) {
      const oneMinuteAgo = Moment().subtract(60, 'seconds').valueOf();
      const measurements = Measurements.find({
        timestamp_ms: {
          $gte: oneMinuteAgo
        }
      }).fetch();

      if (measurements.length > 0) {
        return _.uniq(_.map(measurements, 'box_id'));
      }
    }

    return null;
  }

});
const getActiveBoxIds = new ValidatedMethod({
  name: 'Measurements.getActiveBoxIds',
  validate: new SimpleSchema({
    startTimeMs: {
      type: Number
    }
  }).validator({
    clean: true
  }),

  run({
    startTimeMs
  }) {
    const recentMeasurements = Measurements.find({
      timestamp_ms: {
        $gte: startTimeMs
      }
    }, {
      fields: {
        box_id: 1
      }
    }).fetch(); // Returns an array of unique deviceIds, sorted asc.

    return recentMeasurements.length > 0 ? _.uniq(_.pluck(recentMeasurements, 'box_id')).sort((a, b) => a - b) : null;
  }

});
const getEventMeasurementsByMetaDataId = new ValidatedMethod({
  name: 'Measurements.getEventMeasurementsByMetaDataId',
  validate: new SimpleSchema({
    eventMetaDataId: {
      type: Mongo.ObjectID
    }
  }).validator({
    clean: true
  }),

  run({
    eventMetaDataId
  }) {
    if (!this.isSimulation) {
      const eventMetaData = Events.findOne({
        _id: eventMetaDataId
      });
      const eventMeasurements = Measurements.find({
        box_id: eventMetaData.boxes_triggered[0],
        // Just look at first triggering device for now.
        timestamp_ms: {
          $gte: eventMetaData.event_start,
          $lte: eventMetaData.event_end
        }
      }, {
        sort: {
          event_end: 1
        }
      }).fetch();
      const firstMeasurementTimestamp = eventMeasurements[0].timestamp_ms;
      const lastMeasurementTimestamp = eventMeasurements[eventMeasurements.length - 1].timestamp_ms; // Let's also retrieve some measurements preceding and proceeding event range. 20% of event range on both sides.

      const eventDurationMs = eventMetaData.event_end - eventMetaData.event_start;
      const precedingTimestamp = eventMetaData.event_start - eventDurationMs * 0.2;
      const proceedingTimestamp = eventMetaData.event_end + eventDurationMs * 0.2;
      const precedingMeasurements = Measurements.find({
        box_id: eventMetaData.boxes_triggered[0],
        timestamp_ms: {
          $gte: precedingTimestamp,
          $lte: firstMeasurementTimestamp
        }
      }, {}).fetch();
      const proceedingMeasurements = Measurements.find({
        box_id: eventMetaData.boxes_triggered[0],
        timestamp_ms: {
          $gte: lastMeasurementTimestamp,
          $lte: proceedingTimestamp
        }
      }, {}).fetch();
      return {
        eventMeasurements,
        precedingMeasurements,
        proceedingMeasurements
      };
    }

    return null;
  }

});
const getEventMeasurements = new ValidatedMethod({
  name: 'Measurements.getEventMeasurements',
  validate: new SimpleSchema({
    box_id: {
      type: Number,
      optional: true
    },
    // Get rid of optional later.
    startTime: {
      type: Number,
      optional: true
    },
    endTime: {
      type: Number,
      optional: true
    }
  }).validator({
    clean: true
  }),

  run({
    box_id,
    startTime,
    endTime
  }) {
    if (!this.isSimulation) {
      console.log(box_id, startTime, endTime);
      const eventMeasurements = Measurements.find({
        box_id,
        timestamp_ms: {
          $gte: startTime,
          $lte: endTime
        }
      }, {
        sort: {
          timestamp_ms: 1
        }
      }).fetch();
      const firstMeasurementTimestamp = eventMeasurements[0].timestamp_ms;
      const lastMeasurementTimestamp = eventMeasurements[eventMeasurements.length - 1].timestamp_ms; // Let's also retrieve some measurements preceding and proceeding event range. 20% of event range on both sides.

      const duration = endTime - startTime;
      const precedingTimestamp = startTime - duration * 15.0;
      const proceedingTimestamp = endTime + duration * 15.0;
      const precedingMeasurements = Measurements.find({
        box_id,
        timestamp_ms: {
          $gte: precedingTimestamp,
          $lte: firstMeasurementTimestamp
        }
      }, {}).fetch();
      const proceedingMeasurements = Measurements.find({
        box_id,
        timestamp_ms: {
          $gte: lastMeasurementTimestamp,
          $lte: proceedingTimestamp
        }
      }, {}).fetch();
      return {
        eventMeasurements,
        precedingMeasurements,
        proceedingMeasurements
      };
    }

    return null;
  }

});

const dygraphMergeDatasets = (xFieldName, yFieldName, ...datasets) => {
  const mergedData = new Map();
  const numDatasets = datasets.length;
  datasets.forEach((dataset, index) => {
    // Dygraph requires a data format of:
    // [
    //  [x1, y1, y2, y3, ...],
    //  [x2, y1, y2, y3, ...]
    // ]
    // Where x is the independent variable and y is the dependant variable. As such, the y1 column represents a dataset,
    // the y2 column represents another dataset, and the y3 column represents the final dataset. Dygraph will expect
    // null when there is no value for a given dataset.
    //
    // As such, when iterating through our datasets, we need to insert data at appropriate index of array, and so we
    // must keep track of correct index to write into.
    const writeIndex = index;
    dataset.forEach(data => {
      const x = data[xFieldName];
      const y = data[yFieldName];

      if (mergedData.has(x)) {
        // Get the array and update at appropriate index.
        const arr = mergedData.get(x);
        arr[writeIndex] = y;
        mergedData.set(x, arr);
      } else {
        // Create a null filled array of length equal to number of datasets.
        const newArr = new Array(numDatasets).fill(null);
        newArr[writeIndex] = y; // Set the y value at the proper index.

        mergedData.set(x, newArr);
      }
    });
  });
  const mergedDataset = Array.from(mergedData.keys()).map(key => [key, ...mergedData.get(key)]); // Sort by the independent variable, which is the 0th index of each array.

  mergedDataset.sort((a, b) => a[0] - b[0]);
  return mergedDataset;
};
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"index.js":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// imports/api/measurements/index.js                                                                                   //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
module.watch(require("./MeasurementsCollection.js"));
module.watch(require("./MeasurementsCollectionMethods.js"));
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"opq-boxes":{"OpqBoxesCollection.js":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// imports/api/opq-boxes/OpqBoxesCollection.js                                                                         //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
module.export({
  OpqBoxes: () => OpqBoxes
});
let SimpleSchema;
module.watch(require("simpl-schema"), {
  default(v) {
    SimpleSchema = v;
  }

}, 0);
let Meteor;
module.watch(require("meteor/meteor"), {
  Meteor(v) {
    Meteor = v;
  }

}, 1);
let Moment;
module.watch(require("moment"), {
  default(v) {
    Moment = v;
  }

}, 2);
let BaseCollection;
module.watch(require("../base/BaseCollection.js"), {
  default(v) {
    BaseCollection = v;
  }

}, 3);
let progressBarSetup;
module.watch(require("../../modules/utils"), {
  progressBarSetup(v) {
    progressBarSetup = v;
  }

}, 4);

/**
 * Collection class for the opq_boxes collection.
 * Docs: https://open-power-quality.gitbooks.io/open-power-quality-manual/content/datamodel/description.html#opq_boxes
 */
class OpqBoxesCollection extends BaseCollection {
  /**
   * Creates the collection.
   */
  constructor() {
    super('opq_boxes', new SimpleSchema({
      box_id: String,
      name: {
        type: String,
        optional: true
      },
      description: {
        type: String,
        optional: true
      },
      unplugged: {
        type: Boolean,
        optional: true
      },
      calibration_constant: Number,
      locations: {
        type: Array
      },
      'locations.$': {
        type: Object,
        blackbox: true
      }
    }));
  }
  /**
   * Defines a new OpqBox document.
   * Only works on server side.
   * Updates info associated with box_id if it is already defined.
   * @param {String} box_id - The unique identification value of the OPQBox.
   * @param {String} name - The unique user-friendly name of the OPQBox.
   * @param {String} description - The (optional) description of the OPQBox.
   * @param {Boolean} unplugged - True if the box is not attached to an outlet. Default: false (plugged in)
   * @param {Number} calibration_constant - The calibration constant value of the box. See docs for details.
   * @param {[Object]} locations - The history of locations of the OPQBox.
   * @returns The docID of the new or changed OPQBox document, or undefined if invoked on the client side.
   */


  define({
    box_id,
    name,
    description,
    calibration_constant,
    locations,
    unplugged = false
  }) {
    if (Meteor.isServer) {
      // Create or modify the OpqBox document associated with this box_id.
      const newLocs = this.makeLocationArray(locations);

      this._collection.upsert({
        box_id
      }, {
        $set: {
          name,
          description,
          calibration_constant,
          locations: newLocs,
          unplugged
        }
      });

      const docID = this.findOne({
        box_id
      })._id;

      return docID;
    }

    return undefined;
  }
  /**
   * Returns a new locations array structure where time_stamp_ms has been passed through Moment so that
   * the settings file can provide more user-friendly versions of the timestamp.
   * @param locations The locations array.
   * @returns A new locations array in which time_stamp_ms has been converted to UTC milliseconds.
   */


  makeLocationArray(locations) {
    return locations.map(location => {
      const momentTimestamp = Moment(location.time_stamp_ms);

      if (momentTimestamp.isValid()) {
        location.time_stamp_ms = momentTimestamp.valueOf(); // eslint-disable-line
      }

      return location;
    });
  }
  /**
   * Returns the box document associated with box_id.
   * Throws an error if no box document was found for the passed box_id.
   * @param box_id The box ID.
   * @returns {any} The box document.
   */


  findBox(box_id) {
    const boxDoc = this._collection.findOne({
      box_id
    });

    if (boxDoc) {
      return boxDoc;
    }

    throw new Meteor.Error(`No box found with id: ${box_id}`);
  }
  /**
   * Returns the boxIDs of all boxes in the collection.
   * @return { Array } An array of boxIds.
   */


  findBoxIds() {
    const docs = this._collection.find({}).fetch();

    return docs ? _.map(docs, doc => doc.box_id) : [];
  }
  /**
   * Returns an object representing a single OpqBox.
   * @param {Object} docID - The Mongo.ObjectID of the OpqBox.
   * @returns {Object} - An object representing a single OpqBox.
   */


  dumpOne(docID) {
    /* eslint-disable camelcase */
    const doc = this.findDoc(docID);
    const box_id = doc.box_id;
    const name = doc.name;
    const description = doc.description;
    const calibration_constant = doc.calibration_constant;
    const locations = doc.locations;
    return {
      box_id,
      name,
      description,
      calibration_constant,
      locations
    };
    /* eslint-enable camelcase */
  }

  checkIntegrity() {
    const problems = [];
    const totalCount = this.count();
    const validationContext = this.getSchema().namedContext('opqBoxesIntegrity');
    const pb = progressBarSetup(totalCount, 2000, `Checking ${this._collectionName} collection: `);
    this.find().forEach((doc, index) => {
      pb.updateBar(index); // Update progress bar.
      // Validate each document against the collection schema.

      validationContext.validate(doc);

      if (!validationContext.isValid()) {
        // eslint-disable-next-line max-len
        problems.push(`OpqBox document failed schema validation: ${doc._id} (Invalid keys: ${JSON.stringify(validationContext.invalidKeys(), null, 2)})`);
      }

      validationContext.resetValidation(); // Ensure box_id field is unique

      if (this.find({
        box_id: doc.box_id
      }).count() > 1) problems.push(`OpqBox box_id is not unique: ${doc.box_id}`); // Ensure name field is unique (not counting an unset name - represented by empty strings)
      // eslint-disable-next-line max-len

      if (doc.name && this.find({
        name: doc.name
      }).count() > 1) problems.push(`OpqBox name is not unique: ${doc.name}`);
    });
    pb.clearInterval();
    return problems;
  }

}
/**
 * Provides the singleton instance of this class.
 * @type {OpqBoxesCollection}
 */


const OpqBoxes = new OpqBoxesCollection();
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"OpqBoxesCollectionMethods.js":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// imports/api/opq-boxes/OpqBoxesCollectionMethods.js                                                                  //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
module.export({
  totalOpqBoxesCount: () => totalOpqBoxesCount,
  getBoxCalibrationConstant: () => getBoxCalibrationConstant,
  getBoxIDs: () => getBoxIDs
});
let ValidatedMethod;
module.watch(require("meteor/mdg:validated-method"), {
  ValidatedMethod(v) {
    ValidatedMethod = v;
  }

}, 0);
let SimpleSchema;
module.watch(require("simpl-schema"), {
  default(v) {
    SimpleSchema = v;
  }

}, 1);
let OpqBoxes;
module.watch(require("./OpqBoxesCollection"), {
  OpqBoxes(v) {
    OpqBoxes = v;
  }

}, 2);
const totalOpqBoxesCount = new ValidatedMethod({
  name: 'OpqBoxes.totalOpqBoxesCount',
  validate: new SimpleSchema().validator({
    clean: true
  }),

  run() {
    return OpqBoxes.find({}).count();
  }

});
const getBoxCalibrationConstant = new ValidatedMethod({
  name: 'OpqBoxes.getBoxCalibrationConstant',
  validate: new SimpleSchema({
    box_id: {
      type: String
    }
  }).validator({
    clean: true
  }),

  run({
    box_id
  }) {
    if (!this.isSimulation) {
      const opqBox = OpqBoxes.findOne({
        box_id
      });
      return opqBox ? opqBox.calibration_constant : null;
    }

    return null;
  }

});
const getBoxIDs = new ValidatedMethod({
  name: 'OpqBoxes.getBoxIDs',
  validate: new SimpleSchema({}).validator({
    clean: true
  }),

  run() {
    if (!this.isSimulation) {
      const opqBoxes = OpqBoxes.find({});
      const boxIDs = opqBoxes.map(box => box.box_id);
      return boxIDs;
    }

    return null;
  }

});
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"index.js":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// imports/api/opq-boxes/index.js                                                                                      //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
module.watch(require("./OpqBoxesCollection.js"));
module.watch(require("./OpqBoxesCollectionMethods.js"));
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"system-stats":{"SystemStatsCollection.js":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// imports/api/system-stats/SystemStatsCollection.js                                                                   //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
module.export({
  SystemStats: () => SystemStats
});
let SimpleSchema;
module.watch(require("simpl-schema"), {
  default(v) {
    SimpleSchema = v;
  }

}, 0);
let BaseCollection;
module.watch(require("../base/BaseCollection.js"), {
  default(v) {
    BaseCollection = v;
  }

}, 1);
let Events;
module.watch(require("../events/EventsCollection.js"), {
  Events(v) {
    Events = v;
  }

}, 2);
let BoxEvents;
module.watch(require("../box-events/BoxEventsCollection.js"), {
  BoxEvents(v) {
    BoxEvents = v;
  }

}, 3);
let Measurements;
module.watch(require("../measurements/MeasurementsCollection.js"), {
  Measurements(v) {
    Measurements = v;
  }

}, 4);
let OpqBoxes;
module.watch(require("../opq-boxes/OpqBoxesCollection.js"), {
  OpqBoxes(v) {
    OpqBoxes = v;
  }

}, 5);
let Trends;
module.watch(require("../trends/TrendsCollection.js"), {
  Trends(v) {
    Trends = v;
  }

}, 6);
let UserProfiles;
module.watch(require("../users/UserProfilesCollection.js"), {
  UserProfiles(v) {
    UserProfiles = v;
  }

}, 7);

/* eslint-disable indent */
class SystemStatsCollection extends BaseCollection {
  /**
   * Creates the System Stats collection.
   */
  constructor() {
    super('system_stats', new SimpleSchema({
      events_count: Number,
      events_count_today: Number,
      box_events_count: Number,
      box_events_count_today: Number,
      measurements_count: Number,
      measurements_count_today: Number,
      trends_count: Number,
      trends_count_today: Number,
      opq_boxes_count: Number,
      users_count: Number,
      timestamp: Date,
      box_trend_stats: {
        type: Array
      },
      'box_trend_stats.$': {
        type: Object,
        blackbox: true
      },
      health: {
        type: Array
      },
      'health.$': {
        type: Object,
        blackbox: true
      }
    }));
  }
  /**
   * Defines a new SystemStats document.
   * @param {Number} events_count - The total number of Events documents.
   * @param {Number} events_count_today - The total number of Events documents today.
   * @param {Number} box_events_count - The total number of BoxEvents documents.
   * @param {Number} box_events_count_today - The total number of BoxEvents documents today.
   * @param {Number} measurements_count - The total number of Measurements documents.
   * @param {Number} measurements_count_today - The total number of Measurements documents today.
   * @param {Number} opq_boxes_count - The total number of OpqBoxes documents.
   * @param {Number} trends_count - The total number of Trends documents.
   * @param {Number} trends_count_today - The total number of Trends documents today.
   * @param {Number} users_count - The total number of Users.
   * @param {Object} box_trend_stats - Summary stats on trends for each box.
   * @param {Object} health - Health status of all boxes and services.
   * @returns The newly created document ID.
   */


  define({
    events_count,
    events_count_today,
    box_events_count,
    box_events_count_today,
    measurements_count,
    measurements_count_today,
    opq_boxes_count,
    trends_count,
    trends_count_today,
    users_count,
    box_trend_stats,
    health
  }) {
    const docID = this._collection.insert({
      events_count,
      box_events_count,
      measurements_count,
      opq_boxes_count,
      trends_count,
      users_count,
      timestamp: new Date(),
      box_trend_stats,
      health,
      events_count_today,
      box_events_count_today,
      measurements_count_today,
      trends_count_today
    });

    return docID;
  }
  /**
   * Returns an object representing a single SystemStats.
   * @param {Object} docID - The Mongo.ObjectID of the SystemStat.
   * @returns {Object} - An object representing a single SystemStat.
   */


  dumpOne(docID) {
    /* eslint-disable camelcase */
    const doc = this.findDoc(docID);
    const events_count = doc.events_count;
    const events_count_today = doc.events_count_today;
    const box_events_count = doc.box_events_count;
    const box_events_count_today = doc.box_events_count_today;
    const measurements_count = doc.measurements_count;
    const measurements_count_today = doc.measurements_count_today;
    const trends_count = doc.trends_count;
    const trends_count_today = doc.trends_count_today;
    const opq_boxes_count = doc.opq_boxes_count;
    const users_count = doc.users_count;
    const timestamp = doc.timestamp;
    const box_trend_stats = doc.box_trend_stats;
    return {
      events_count,
      box_events_count,
      measurements_count,
      opq_boxes_count,
      trends_count,
      users_count,
      timestamp,
      box_trend_stats,
      events_count_today,
      box_events_count_today,
      measurements_count_today,
      trends_count_today
    };
    /* eslint-enable camelcase */
  }
  /**
   * No need to check integrity for this collection.
   * @returns {Array}
   */


  checkIntegrity() {
    // eslint-disable-line
    const problems = [];
    return problems;
  }
  /**
   * Return an object with the following fields:
   * boxId: The ID of the box associated with this trend data.
   * firstTrend: A number (UTC timestamp) of the earliest trend data for this box, or 0 if not found.
   * latestTrend: A number (UTC timestamp) of the latest trend data for this box, or 0 if not found.
   * totalTrends: A Number indicating the total number of trends.
   * @param boxId The box ID.
   * @returns An object { boxId, firstTrend, lastTrend, totalTrends }.
   */


  getBoxTrendStat(boxId) {
    // eslint-disable-line
    const firstTrendDoc = Trends.oldestTrend(boxId);
    const firstTrend = firstTrendDoc ? firstTrendDoc.timestamp_ms : 0;
    const lastTrendDoc = Trends.newestTrend(boxId);
    const lastTrend = lastTrendDoc ? lastTrendDoc.timestamp_ms : 0;
    const totalTrends = Trends.countTrends(boxId);
    return {
      boxId,
      firstTrend,
      lastTrend,
      totalTrends
    };
  }
  /**
   * Create an array of objects with fields: type, name, icon, color
   * We just display convert this array to labels to display health.
   */


  getHealthArray() {
    const health = [];
    health.push({
      type: 'service',
      index: 1,
      name: 'Mauka',
      icon: 'check circle',
      color: 'green'
    });
    health.push({
      type: 'service',
      index: 2,
      name: 'Makai',
      icon: 'check circle',
      color: 'green'
    });
    health.push({
      type: 'service',
      index: 3,
      name: 'Mongo',
      icon: 'check circle',
      color: 'green'
    });
    health.push({
      type: 'service',
      index: 4,
      name: 'Health',
      icon: 'check circle',
      color: 'green'
    });
    health.push({
      type: 'box',
      index: 1,
      name: 'Box 01',
      icon: 'check circle',
      color: 'green'
    });
    health.push({
      type: 'box',
      index: 2,
      name: 'Box 02',
      icon: 'plug',
      color: 'grey'
    });
    health.push({
      type: 'box',
      index: 3,
      name: 'Box 03',
      icon: 'exclamation circle',
      color: 'red'
    });
    health.push({
      type: 'box',
      index: 4,
      name: 'Box 04',
      icon: 'check circle',
      color: 'green'
    });
    health.push({
      type: 'box',
      index: 5,
      name: 'Box 05',
      icon: 'check circle',
      color: 'green'
    });
    return health;
  }

  updateCounts() {
    // Get current collection counts
    const events_count = Events.count();
    const events_count_today = Events.countToday('target_event_start_timestamp_ms');
    const box_events_count = BoxEvents.count();
    const box_events_count_today = BoxEvents.countToday('event_start_timestamp_ms');
    const measurements_count = Measurements.count();
    const measurements_count_today = Measurements.countToday('timestamp_ms');
    const opq_boxes_count = OpqBoxes.count();
    const trends_count = Trends.count();
    const trends_count_today = Trends.countToday('timestamp_ms');
    const users_count = UserProfiles.count(); // Not a base-collection class.

    const box_trend_stats = OpqBoxes.findBoxIds().map(boxId => this.getBoxTrendStat(boxId));
    const health = this.getHealthArray(); // Ensure there is only one document in the collection. We will only update this one document with current stats.

    const count = this._collection.find().count();

    if (count > 1) {
      // Remove all documents but one, which we choose arbitrarily
      const doc = this._collection.findOne();

      this._collection.remove({
        _id: {
          $ne: doc._id
        }
      });
    } else if (count < 1) {
      // Create new doc. Should only theoretically have to be done once, when we first create the collection.
      // eslint-disable-next-line max-len
      return this.define({
        events_count,
        box_events_count,
        measurements_count,
        opq_boxes_count,
        trends_count,
        users_count,
        box_trend_stats,
        health,
        events_count_today,
        box_events_count_today,
        measurements_count_today,
        trends_count_today
      });
    } // Update the one document with current collection counts.


    const systemStatsDoc = this._collection.findOne();

    return systemStatsDoc && this._collection.update(systemStatsDoc._id, {
      $set: {
        events_count,
        box_events_count,
        measurements_count,
        opq_boxes_count,
        trends_count,
        users_count,
        timestamp: new Date(),
        box_trend_stats,
        health,
        events_count_today,
        box_events_count_today,
        measurements_count_today,
        trends_count_today
      }
    });
  }

}
/**
 * Provides the singleton instance of this class.
 * @type {SystemStatsCollection}
 */


const SystemStats = new SystemStatsCollection();
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"trends":{"TrendsCollection.js":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// imports/api/trends/TrendsCollection.js                                                                              //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
module.export({
  Trends: () => Trends
});
let Meteor;
module.watch(require("meteor/meteor"), {
  Meteor(v) {
    Meteor = v;
  }

}, 0);
let Mongo;
module.watch(require("meteor/mongo"), {
  Mongo(v) {
    Mongo = v;
  }

}, 1);
let SimpleSchema;
module.watch(require("simpl-schema"), {
  default(v) {
    SimpleSchema = v;
  }

}, 2);
let check;
module.watch(require("meteor/check"), {
  check(v) {
    check = v;
  }

}, 3);
let BaseCollection;
module.watch(require("../base/BaseCollection.js"), {
  default(v) {
    BaseCollection = v;
  }

}, 4);
let OpqBoxes;
module.watch(require("../opq-boxes/OpqBoxesCollection"), {
  OpqBoxes(v) {
    OpqBoxes = v;
  }

}, 5);
let progressBarSetup;
module.watch(require("../../modules/utils"), {
  progressBarSetup(v) {
    progressBarSetup = v;
  }

}, 6);

class TrendsCollection extends BaseCollection {
  /**
   * Creates the Trends collection.
   */
  constructor() {
    super('trends', new SimpleSchema({
      _id: {
        type: Mongo.ObjectID
      },
      box_id: {
        type: String
      },
      timestamp_ms: {
        type: Number
      },
      voltage: {
        type: Object
      },
      'voltage.min': {
        type: Number
      },
      'voltage.max': {
        type: Number
      },
      'voltage.average': {
        type: Number
      },
      frequency: {
        type: Object
      },
      'frequency.min': {
        type: Number
      },
      'frequency.max': {
        type: Number
      },
      'frequency.average': {
        type: Number
      },
      thd: {
        type: Object,
        optional: true
      },
      'thd.min': {
        type: Number
      },
      'thd.max': {
        type: Number
      },
      'thd.average': {
        type: Number
      }
    }));
    this.publicationNames = {
      GET_RECENT_TRENDS: 'get_recent_trends',
      TRENDS_RECENT_MONTH: 'trends_recent_month'
    };

    if (Meteor.server) {
      this._collection.rawCollection().createIndex({
        timestamp_ms: 1,
        box_id: 1
      }, {
        background: true
      });
    }
  }
  /**
   * Defines a new Trends document.
   * @param {String} box_id - The OPQBox's id value (not Mongo ID)
   * @param {Number} timestamp_ms - The unix timestamp (millis) of the trend.
   * @param {Number} voltage - The voltage trend object.
   * @param {Number} frequency - The frequency trend object.
   * @param {Number} thd - The thd trend object.
   * @returns The newly created document ID.
   */


  define({
    box_id,
    timestamp_ms,
    voltage,
    frequency,
    thd
  }) {
    const docID = this._collection.insert({
      box_id,
      timestamp_ms,
      voltage,
      frequency,
      thd
    });

    return docID;
  }
  /**
   * Returns the oldest Trend document associated with box_id by timestamp, or null if there are no Trends for box_id.
   * @param box_id The box_id
   * @returns The Trend document, or null.
   */


  oldestTrend(box_id) {
    return this._collection.findOne({
      box_id,
      timestamp_ms: {
        $gt: 0
      }
    }, {
      sort: {
        timestamp_ms: 1
      }
    });
  }
  /**
   * Returns the newest Trend document associated with box_id by timestamp, or null if there are no Trends for box_id.
   * @param box_id The box_id
   * @returns The Trend document, or null.
   */


  newestTrend(box_id) {
    return this._collection.findOne({
      box_id
    }, {
      sort: {
        timestamp_ms: -1
      }
    });
  }
  /**
   * Returns the number of Trend documents associated with box_id.
   * @param box_id The box ID.
   * @returns The number of Trend documents with that ID.
   */


  countTrends(box_id) {
    return this._collection.find({
      box_id
    }).count();
  }
  /**
   * Returns an object representing a single Trend.
   * @param {Object} docID - The Mongo.ObjectID of the Trend.
   * @returns {Object} - An object representing a single Trend.
   */


  dumpOne(docID) {
    /* eslint-disable camelcase */
    const doc = this.findDoc(docID);
    const box_id = doc.box_id;
    const timestamp_ms = doc.timestamp_ms;
    const voltage = doc.voltage;
    const frequency = doc.frequency;
    const thd = doc.thd;
    return {
      box_id,
      timestamp_ms,
      voltage,
      frequency,
      thd
    };
    /* eslint-enable camelcase */
  }

  checkIntegrity() {
    const problems = [];
    const totalCount = this.count();
    const validationContext = this.getSchema().namedContext('trendsIntegrity');
    const pb = progressBarSetup(totalCount, 2000, `Checking ${this._collectionName} collection: `); // Get all OpqBox IDs.

    const boxIDs = OpqBoxes.find().map(doc => doc.box_id);
    this.find().forEach((doc, index) => {
      pb.updateBar(index); // Update progress bar.
      // Validate each document against the collection schema.

      validationContext.validate(doc);

      if (!validationContext.isValid()) {
        // eslint-disable-next-line max-len
        problems.push(`Trends document failed schema validation: ${doc._id} (Invalid keys: ${JSON.stringify(validationContext.invalidKeys(), null, 2)})`);
      }

      validationContext.resetValidation(); // Ensure box_id of the trend exists in opq_boxes collection.

      if (!boxIDs.includes(doc.box_id)) {
        problems.push(`Trends box_id does not exist in opq_boxes collection: ${doc.box_id} (docID: ${doc._id})`);
      }
    });
    pb.clearInterval();
    return problems;
  }
  /**
   * Loads all publications related to the Trends collection.
   */


  publish() {
    // eslint-disable-line class-methods-use-this
    if (Meteor.isServer) {
      const self = this;
      Meteor.publish(this.publicationNames.GET_RECENT_TRENDS, function ({
        numTrends
      }) {
        check(numTrends, Number);
        const trends = self.find({}, {
          sort: {
            timestamp_ms: -1
          },
          limit: numTrends
        });
        return trends;
      });
    }
  }

}
/**
 * Provides the singleton instance of this class.
 * @type {TrendsCollection}
 */


const Trends = new TrendsCollection();
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"TrendsCollectionMethods.js":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// imports/api/trends/TrendsCollectionMethods.js                                                                       //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
module.export({
  totalTrendsCount: () => totalTrendsCount,
  getMostRecentTrendMonth: () => getMostRecentTrendMonth,
  dailyTrendsInRange: () => dailyTrendsInRange,
  dailyTrends: () => dailyTrends
});
let ValidatedMethod;
module.watch(require("meteor/mdg:validated-method"), {
  ValidatedMethod(v) {
    ValidatedMethod = v;
  }

}, 0);
let SimpleSchema;
module.watch(require("simpl-schema"), {
  default(v) {
    SimpleSchema = v;
  }

}, 1);
let Moment;
module.watch(require("moment"), {
  default(v) {
    Moment = v;
  }

}, 2);

let _;

module.watch(require("lodash"), {
  default(v) {
    _ = v;
  }

}, 3);
let demapify;
module.watch(require("es6-mapify"), {
  demapify(v) {
    demapify = v;
  }

}, 4);
let Trends;
module.watch(require("./TrendsCollection"), {
  Trends(v) {
    Trends = v;
  }

}, 5);
const totalTrendsCount = new ValidatedMethod({
  name: 'Trends.totalTrendsCount',
  validate: new SimpleSchema().validator({
    clean: true
  }),

  run() {
    return Trends.find({}).count();
  }

});
const getMostRecentTrendMonth = new ValidatedMethod({
  name: 'Trends.mostRecentTrendMonth',
  validate: new SimpleSchema({}).validator({
    clean: true
  }),

  run() {
    if (!this.isSimulation) {
      const trend = Trends.findOne({}, {
        sort: {
          timestamp_ms: -1
        }
      });
      const trendMoment = Moment(trend.timestamp_ms);
      const month = trendMoment.month(); // 0-indexed month integers (January is 0)

      const year = trendMoment.year();
      return {
        box_id: trend.box_id,
        month,
        year
      };
    }

    return null;
  }

});
const dailyTrendsInRange = new ValidatedMethod({
  name: 'Trends.dailyTrendsInRange',
  validate: new SimpleSchema({
    boxIDs: {
      type: Array
    },
    'boxIDs.$': {
      type: String
    },
    startDate_ms: {
      type: Number
    },
    endDate_ms: {
      type: Number
    }
  }).validator({
    clean: true
  }),

  run({
    boxIDs,
    startDate_ms,
    endDate_ms
  }) {
    // The shape of what our daily and monthly trend summaries will look like.
    const trendSummaryShape = {
      voltage: {
        min: Number.MAX_SAFE_INTEGER,
        minDate: null,
        max: Number.MIN_SAFE_INTEGER,
        maxDate: null,
        average: 0,
        count: 0
      },
      frequency: {
        min: Number.MAX_SAFE_INTEGER,
        minDate: null,
        max: Number.MIN_SAFE_INTEGER,
        maxDate: null,
        average: 0,
        count: 0
      },
      thd: {
        min: Number.MAX_SAFE_INTEGER,
        minDate: null,
        max: Number.MIN_SAFE_INTEGER,
        maxDate: null,
        average: 0,
        count: 0
      },
      totalDocCount: 0
    }; // For each box, find the trends associated with it and
    // summarize each day's trends into an object with the
    // timestamp of the start of that day (in ms) as its key
    // i.e. { timestamp: dailyTrendData }

    return Object.assign(...boxIDs.map(boxID => {
      const associatedTrends = Trends.find({
        box_id: boxID,
        timestamp_ms: {
          $gt: startDate_ms,
          $lte: Moment(endDate_ms).endOf('day').valueOf()
        }
      }).fetch(); // New Moments are instantiated every time, because they mutate even when reassigned to a variable.

      const start = Moment(startDate_ms);
      const end = Moment(endDate_ms); // Create structure of the dailyTrend object

      const dailyTrends = new Map();

      for (let i = start.startOf('day'); i <= end.startOf('day'); i = i.add(1, 'days')) {
        dailyTrends.set(i.valueOf(), _.cloneDeep(trendSummaryShape));
      } // Input real values into the dailyTrend object


      associatedTrends.forEach(trend => {
        const trendDay_ms = Moment(trend.timestamp_ms).startOf('day').valueOf();
        const dtv = dailyTrends.get(trendDay_ms); // Daily Trend Values

        dtv.totalDocCount++; // Voltage

        if (trend.voltage) {
          dtv.voltage.count++;

          if (trend.voltage.min < dtv.voltage.min) {
            dtv.voltage.min = trend.voltage.min;
            dtv.voltage.minDate = trend.timestamp_ms;
          }

          if (trend.voltage.max > dtv.voltage.max) {
            dtv.voltage.max = trend.voltage.max;
            dtv.voltage.maxDate = trend.timestamp_ms;
          }

          dtv.voltage.average += (trend.voltage.average - dtv.voltage.average) / dtv.voltage.count;
        } // Frequency


        if (trend.frequency) {
          dtv.frequency.count++;

          if (trend.frequency.min < dtv.frequency.min) {
            dtv.frequency.min = trend.frequency.min;
            dtv.frequency.minDate = trend.timestamp_ms;
          }

          if (trend.frequency.max > dtv.frequency.max) {
            dtv.frequency.max = trend.frequency.max;
            dtv.frequency.maxDate = trend.timestamp_ms;
          }

          dtv.frequency.average += (trend.frequency.average - dtv.frequency.average) / dtv.frequency.count;
        } // THD


        if (trend.thd) {
          dtv.thd.count++;

          if (trend.thd.min < dtv.thd.min) {
            dtv.thd.min = trend.thd.min;
            dtv.thd.minDate = trend.timestamp_ms;
          }

          if (trend.thd.max > dtv.thd.max) {
            dtv.thd.max = trend.thd.max;
            dtv.thd.maxDate = trend.timestamp_ms;
          }

          dtv.thd.average += (trend.thd.average - dtv.thd.average) / dtv.thd.count;
        }
      }); // Delete fields that are empty

      dailyTrends.forEach(dtv => {
        if (dtv.voltage.count === 0) delete dtv.voltage; // eslint-disable-line no-param-reassign

        if (dtv.frequency.count === 0) delete dtv.frequency; // eslint-disable-line no-param-reassign

        if (dtv.thd.count === 0) delete dtv.thd; // eslint-disable-line no-param-reassign
      }); // Daily uptime calculations

      dailyTrends.forEach(dtv => {
        // This number is not accurate, but will be used until a better method is found.
        dtv.uptime = dtv.totalDocCount / 1440 * 100; // eslint-disable-line no-param-reassign
      }); // Calculates summary for the entire range.

      const rtv = _.cloneDeep(trendSummaryShape); // rtv = range trend value


      dailyTrends.forEach(dtv => {
        // dtv = Daily Trend Values
        // Represents the true total doc count of all trend documents parsed for this range.
        rtv.totalDocCount += dtv.totalDocCount; // Voltage

        if (dtv.voltage) {
          rtv.voltage.count++;

          if (dtv.voltage.min < rtv.voltage.min) {
            rtv.voltage.min = dtv.voltage.min;
            rtv.voltage.minDate = dtv.voltage.minDate;
          }

          if (dtv.voltage.max > rtv.voltage.max) {
            rtv.voltage.max = dtv.voltage.max;
            rtv.voltage.maxDate = dtv.voltage.maxDate;
          }

          rtv.voltage.average += (dtv.voltage.average - rtv.voltage.average) / rtv.voltage.count;
        } // Frequency


        if (dtv.frequency) {
          rtv.frequency.count++;

          if (dtv.frequency.min < rtv.frequency.min) {
            rtv.frequency.min = dtv.frequency.min;
            rtv.frequency.minDate = dtv.frequency.minDate;
          }

          if (dtv.frequency.max > rtv.frequency.max) {
            rtv.frequency.max = dtv.frequency.max;
            rtv.frequency.maxDate = dtv.frequency.maxDate;
          }

          rtv.frequency.average += (dtv.frequency.average - rtv.frequency.average) / rtv.frequency.count;
        } // THD


        if (dtv.thd) {
          rtv.thd.count++;

          if (dtv.thd.min < rtv.thd.min) {
            rtv.thd.min = dtv.thd.min;
            rtv.thd.minDate = dtv.thd.minDate;
          }

          if (dtv.thd.max > rtv.thd.max) {
            rtv.thd.max = dtv.thd.max;
            rtv.thd.maxDate = dtv.thd.maxDate;
          }

          rtv.thd.average += (dtv.thd.average - rtv.thd.average) / rtv.thd.count;
        }
      }); // Delete empty fields

      if (rtv.voltage.count === 0) delete rtv.voltage; // eslint-disable-line no-param-reassign

      if (rtv.frequency.count === 0) delete rtv.frequency; // eslint-disable-line no-param-reassign

      if (rtv.thd.count === 0) delete rtv.thd; // eslint-disable-line no-param-reassign

      return {
        [boxID]: {
          dailyTrends: demapify(dailyTrends),
          rangeTrends: rtv
        }
      };
    }));
  }

});
const dailyTrends = new ValidatedMethod({
  name: 'Trends.dailyTrends',
  validate: new SimpleSchema({
    boxIDs: {
      type: Array
    },
    'boxIDs.$': {
      type: String
    },
    startDate_ms: {
      type: Number
    },
    endDate_ms: {
      type: Number
    }
  }).validator({
    clean: true
  }),

  run({
    boxIDs,
    startDate_ms,
    endDate_ms
  }) {
    // For each box, find the trends associated with it and
    // summarize each day's trends into an object with the
    // timestamp of the start of that day (in ms) as its key
    // i.e. { timestamp: dailyTrendData }
    return Object.assign(...boxIDs.map(boxID => {
      const associatedTrends = Trends.find({
        box_id: boxID,
        timestamp_ms: {
          $gt: startDate_ms,
          $lte: Moment(endDate_ms).endOf('day').valueOf()
        }
      }).fetch(); // New Moments are instantiated every time, because they mutate even when reassigned to a variable.

      const start = Moment(startDate_ms);
      const end = Moment(endDate_ms); // Create structure of the dailyTrend object

      const dailyTrendsMap = new Map();

      for (let i = start.startOf('day'); i <= end.startOf('day'); i = i.add(1, 'days')) {
        dailyTrendsMap.set(i.valueOf(), {
          voltage: {
            min: Infinity,
            max: -Infinity,
            average: 0,
            count: 0
          },
          frequency: {
            min: Infinity,
            max: -Infinity,
            average: 0,
            count: 0
          },
          thd: {
            min: Infinity,
            max: -Infinity,
            average: 0,
            count: 0
          }
        });
      } // Input real values into the dailyTrend object


      associatedTrends.forEach(trend => {
        const trendDay_ms = Moment(trend.timestamp_ms).startOf('day').valueOf();
        const dtv = dailyTrendsMap.get(trendDay_ms); // Daily Trend Values
        // Voltage

        if (trend.voltage) {
          dtv.voltage.count++;
          if (trend.voltage.min < dtv.voltage.min) dtv.voltage.min = trend.voltage.min;
          if (trend.voltage.max > dtv.voltage.max) dtv.voltage.max = trend.voltage.max;
          dtv.voltage.average += (trend.voltage.average - dtv.voltage.average) / dtv.voltage.count;
        } // Frequency


        if (trend.frequency) {
          dtv.frequency.count++;
          if (trend.frequency.min < dtv.frequency.min) dtv.frequency.min = trend.frequency.min;
          if (trend.frequency.max > dtv.frequency.max) dtv.frequency.max = trend.frequency.max;
          dtv.frequency.average += (trend.frequency.average - dtv.frequency.average) / dtv.frequency.count;
        } // THD


        if (trend.thd) {
          dtv.thd.count++;
          if (trend.thd.min < dtv.thd.min) dtv.thd.min = trend.thd.min;
          if (trend.thd.max > dtv.thd.max) dtv.thd.max = trend.thd.max;
          dtv.thd.average += (trend.thd.average - dtv.thd.average) / dtv.thd.count;
        }
      }); // Delete fields that are empty

      dailyTrendsMap.forEach(dtv => {
        if (dtv.voltage.count === 0) delete dtv.voltage; // eslint-disable-line no-param-reassign
        else delete dtv.voltage.count; // eslint-disable-line no-param-reassign

        if (dtv.frequency.count === 0) delete dtv.frequency; // eslint-disable-line no-param-reassign
        else delete dtv.frequency.count; // eslint-disable-line no-param-reassign

        if (dtv.thd.count === 0) delete dtv.thd; // eslint-disable-line no-param-reassign
        else delete dtv.thd.count; // eslint-disable-line no-param-reassign
      });
      return {
        [boxID]: demapify(dailyTrendsMap)
      };
    }));
  }

});
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"index.js":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// imports/api/trends/index.js                                                                                         //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
module.watch(require("./TrendsCollection.js"));
module.watch(require("./TrendsCollectionMethods.js"));
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"users":{"BoxOwnersCollection.js":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// imports/api/users/BoxOwnersCollection.js                                                                            //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
module.export({
  BoxOwners: () => BoxOwners
});
let Meteor;
module.watch(require("meteor/meteor"), {
  Meteor(v) {
    Meteor = v;
  }

}, 0);
let SimpleSchema;
module.watch(require("simpl-schema"), {
  default(v) {
    SimpleSchema = v;
  }

}, 1);
let BaseCollection;
module.watch(require("../base/BaseCollection"), {
  default(v) {
    BaseCollection = v;
  }

}, 2);

/**
 * User Profiles (first and last name, role, and username (email).
 * To create a new User, call UserProfiles.define(), which both defines the profile and creates the Meteor.user.
 * Docs: https://open-power-quality.gitbooks.io/open-power-quality-manual/content/datamodel/description.html#users
 */
class BoxOwnersCollection extends BaseCollection {
  /**
   * Creates the User Profiles collection.
   */
  constructor() {
    super('BoxOwners', new SimpleSchema({
      username: String,
      boxId: String
    }));
  }
  /**
   * Defines username as an owner of boxId.
   * If username is already specified as an owner of boxID, that docID is returned.
   * Otherwise a new BoxOwners document is created and its docID is returned.
   * Note that no checking is done to see if username and/or boxId is a valid username or boxId. So, be careful.
   * Only works on the server side.
   * @param {String} username - Must be the user's email address.
   * @param {Number} boxId - The id of the box (an integer).
   * @return The docID for this ownership document.
   */
  // eslint-disable-next-line class-methods-use-this


  define({
    username,
    boxId
  }) {
    if (Meteor.isServer) {
      const existingDoc = this.findOne(username, boxId);

      if (existingDoc) {
        return existingDoc._id;
      }

      return this._collection.insert({
        username,
        boxId
      });
    } // Return undefined if executed on the client (which shouldn't ever happen.)


    return undefined;
  }
  /**
   * Returns an array of the box documents owned by username.
   * @param username The username.
   * @return { Array } An array of box documents owned by this user.
   */


  findBoxesWithOwner(username) {
    return this._collection.find({
      username
    }).fetch();
  }
  /**
   * Returns a (possibly empty) array of boxIds owned by username.
   * @param username The username
   * @return { Array } An array of boxIds owned by this user.
   */


  findBoxIdsWithOwner(username) {
    const docs = this._collection.find({
      username
    }).fetch();

    return docs ? _.map(docs, doc => doc.boxId) : [];
  }
  /**
   * Returns a (possibly empty) array of usernames who own the box.
   * @param boxId The boxId.
   * @return { Array } An array of usernames who own boxId.
   */


  findOwnersWithBoxId(boxId) {
    const docs = this._collection.find({
      boxId
    }).fetch();

    return docs ? _.map(docs, doc => doc.username) : [];
  }

  findOne(username, boxId) {
    return this._collection.findOne({
      username,
      boxId
    });
  }
  /**
   * Removes all of the documents associated with username from this collection.
   * @param username The user (owner of boxes).
   */


  removeBoxesWithOwner(username) {
    this._collection.remove({
      username
    });
  }
  /**
   * Returns an object representing a single BoxOwner document.
   * @param {Object} docID - The Mongo.ObjectID of the BoxOwner.
   * @returns {Object} - An object representing a single BoxOwner document.
   */


  dumpOne(docID) {
    const doc = this.findDoc(docID);
    const username = doc.username;
    const boxId = doc.boxId;
    return {
      username,
      boxId
    };
  }

}
/**
 * Provides the singleton instance of this class.
 */


const BoxOwners = new BoxOwnersCollection();
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"UserProfilesCollection.js":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// imports/api/users/UserProfilesCollection.js                                                                         //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
module.export({
  UserProfiles: () => UserProfiles
});
let Meteor;
module.watch(require("meteor/meteor"), {
  Meteor(v) {
    Meteor = v;
  }

}, 0);
let Accounts;
module.watch(require("meteor/accounts-base"), {
  Accounts(v) {
    Accounts = v;
  }

}, 1);
let Roles;
module.watch(require("meteor/alanning:roles"), {
  Roles(v) {
    Roles = v;
  }

}, 2);

let _;

module.watch(require("lodash"), {
  _(v) {
    _ = v;
  }

}, 3);
let SimpleSchema;
module.watch(require("simpl-schema"), {
  default(v) {
    SimpleSchema = v;
  }

}, 4);
let BaseCollection;
module.watch(require("../base/BaseCollection"), {
  default(v) {
    BaseCollection = v;
  }

}, 5);
let BoxOwners;
module.watch(require("./BoxOwnersCollection"), {
  BoxOwners(v) {
    BoxOwners = v;
  }

}, 6);

/**
 * User Profiles (first and last name, role, and username (email).
 * To create a new User, call UserProfiles.define(), which both defines the profile and creates the Meteor.user.
 * Docs: https://open-power-quality.gitbooks.io/open-power-quality-manual/content/datamodel/description.html#users
 */
class UserProfilesCollection extends BaseCollection {
  /**
   * Creates the User Profiles collection.
   */
  constructor() {
    super('UserProfiles', new SimpleSchema({
      username: String,
      firstName: String,
      lastName: String,
      role: String
    }));
  }
  /**
   * Defines a new UserProfile if username is not defined in Meteor.users, and adds the user to Meteor.users.
   * Updates an existing User Profile if username is already defined in Meteor.users.
   * @param {String} username - Must be the user's email address.
   * @param {String} password - The user's password. (Only used when adding a user to Meteor.users.)
   * @param {String} firstName - The user's first name.
   * @param {String} lastName - The user's last name.
   * @param {String} role - The role of the user: either 'admin' or 'user'.
   * @param {[Number]} boxIds - An array of Strings containing the IDs of the boxes that can be managed by this user.
   */
  // eslint-disable-next-line class-methods-use-this


  define({
    username,
    password,
    firstName,
    lastName,
    boxIds = [],
    role = 'user'
  }) {
    if (Meteor.isServer) {
      // boxIds array must contain integers.
      boxIds.forEach(boxId => {
        if (!_.isString(boxId)) {
          throw new Meteor.Error(`All boxIds must be a string: ${boxId}`);
        }
      }); // Role must be either 'user' or 'admin'.

      if (role !== 'user' && role !== 'admin') {
        throw new Meteor.Error('Invalid user role - must either be "user" or "admin"');
      } // Figure out if the user is already defined in Meteor Accounts.


      let user = Accounts.findUserByUsername(username);
      let userId = user && user._id; // Define the new user in Meteor Accounts if necessary.

      if (!userId) {
        userId = Accounts.createUser({
          username,
          email: username,
          password
        });
        user = Accounts.findUserByUsername(username);
      } // Create or modify the UserProfiles document associated with this username.


      this._collection.upsert({
        username
      }, {
        $set: {
          firstName,
          lastName,
          role
        }
      });

      const profileId = this.findOne({
        username
      })._id; // Set the role using the Roles package. This makes it easier to do Role-based decisions on client.


      if (userId) {
        Roles.addUsersToRoles(userId, role);
      } // Remove any current box ownerships, add new ownerships as specified in boxIds.


      BoxOwners.removeBoxesWithOwner(username);
      boxIds.map(boxId => BoxOwners.define({
        username,
        boxId
      })); // Return the profileID if executed on the server.

      return profileId;
    } // Return undefined if executed on the client (which shouldn't ever happen.)


    return undefined;
  }
  /**
   * Returns the profile document corresponding to username, or throws error if not found.
   * @param username
   * @returns {Object} The profile document.
   * @throws { Meteor.Error } If the profile document does not exist for this username.
   */


  findByUsername(username) {
    const profile = this._collection.findOne({
      username
    });

    if (profile) {
      return profile;
    }

    throw new Meteor.Error(`Could not find profile corresponding to ${username}`);
  }
  /**
   * Returns an object representing a single UserProfile.
   * @param {Object} docID - The Mongo.ObjectID of the User.
   * @returns {Object} - An object representing a single UserProfile.
   */


  dumpOne(docID) {
    const doc = this.findDoc(docID);
    const username = doc.username;
    const firstName = doc.firstName;
    const lastName = doc.lastName;
    const role = doc.roles;
    return {
      username,
      firstName,
      lastName,
      role
    };
  }
  /**
   * Removes the user from Meteor.users and from UserProfiles.
   * If username does not exist, then returns false.
   * Will only work on the server-side.
   * @param username A username
   * @returns True if the username exists and was deleted, false otherwise.
   */


  remove(username) {
    if (Meteor.isServer) {
      const profile = this.findOne({
        username
      });

      if (profile) {
        this._collection.remove({
          username
        });

        const user = Accounts.findUserByUsername(username);

        if (user) {
          Meteor.users.remove(user._id);
        }

        return true;
      }
    }

    return false;
  }
  /**
   * Removes all UserProfiles and associated Meteor.users.
   * This is implemented by mapping through all elements because mini-mongo does not implement the remove operation.
   * Will only work on the server side.
   * removeAll should only used for testing purposes, so it doesn't need to be efficient.
   * @returns true
   */


  removeAll() {
    if (Meteor.isServer) {
      const userProfiles = this._collection.find().fetch();

      const instance = this;

      _.forEach(userProfiles, profile => instance.remove(profile.username));
    }

    return true;
  }

}
/**
 * Provides the singleton instance of this class.
 * @type {UserProfilesCollection}
 */


const UserProfiles = new UserProfilesCollection();
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"index.js":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// imports/api/users/index.js                                                                                          //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
module.watch(require("./BoxOwnersCollection"));
module.watch(require("./UserProfilesCollection"));
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}}},"startup":{"both":{"index.js":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// imports/startup/both/index.js                                                                                       //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
module.watch(require("../../api/users"));
module.watch(require("../../api/measurements"));
module.watch(require("../../api/trends"));
module.watch(require("../../api/box-events"));
module.watch(require("../../api/events"));
module.watch(require("../../api/opq-boxes"));
module.watch(require("../../api/fs-files"));
module.watch(require("../../api/fs-chunks"));
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"server":{"index.js":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// imports/startup/server/index.js                                                                                     //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
module.watch(require("./synced-cron"));
module.watch(require("./publications"));
module.watch(require("./init-users"));
module.watch(require("./init-boxes"));
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"init-boxes.js":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// imports/startup/server/init-boxes.js                                                                                //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
let Meteor;
module.watch(require("meteor/meteor"), {
  Meteor(v) {
    Meteor = v;
  }

}, 0);
let OpqBoxes;
module.watch(require("../../api/opq-boxes/OpqBoxesCollection"), {
  OpqBoxes(v) {
    OpqBoxes = v;
  }

}, 1);

function initBoxes() {
  // Default boxes to an empty array if they are not specified in the settings file.
  const boxes = Meteor.settings.opqBoxes || [];
  console.log(`Initializing ${boxes.length} OPQ boxes.`);
  boxes.map(box => OpqBoxes.define(box));
}

Meteor.startup(() => {
  initBoxes();
});
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"init-users.js":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// imports/startup/server/init-users.js                                                                                //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
let Meteor;
module.watch(require("meteor/meteor"), {
  Meteor(v) {
    Meteor = v;
  }

}, 0);
let UserProfiles;
module.watch(require("../../api/users/UserProfilesCollection"), {
  UserProfiles(v) {
    UserProfiles = v;
  }

}, 1);

function initUsers() {
  // Default profiles to an empty array if they are not specified in the settings file.
  const profiles = Meteor.settings.userProfiles || [];
  console.log(`Initializing ${profiles.length} user profiles.`);
  profiles.map(profile => UserProfiles.define(profile));
}

Meteor.startup(() => {
  initUsers();
});
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"publications.js":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// imports/startup/server/publications.js                                                                              //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
let BoxEvents;
module.watch(require("../../api/box-events/BoxEventsCollection"), {
  BoxEvents(v) {
    BoxEvents = v;
  }

}, 0);
let BoxOwners;
module.watch(require("../../api/users/BoxOwnersCollection"), {
  BoxOwners(v) {
    BoxOwners = v;
  }

}, 1);
let Events;
module.watch(require("../../api/events/EventsCollection"), {
  Events(v) {
    Events = v;
  }

}, 2);
let Trends;
module.watch(require("../../api/trends/TrendsCollection.js"), {
  Trends(v) {
    Trends = v;
  }

}, 3);
let SystemStats;
module.watch(require("../../api/system-stats/SystemStatsCollection.js"), {
  SystemStats(v) {
    SystemStats = v;
  }

}, 4);
let OpqBoxes;
module.watch(require("../../api/opq-boxes/OpqBoxesCollection"), {
  OpqBoxes(v) {
    OpqBoxes = v;
  }

}, 5);
let Measurements;
module.watch(require("../../api/measurements/MeasurementsCollection"), {
  Measurements(v) {
    Measurements = v;
  }

}, 6);
let UserProfiles;
module.watch(require("../../api/users/UserProfilesCollection"), {
  UserProfiles(v) {
    UserProfiles = v;
  }

}, 7);
BoxEvents.publish();
BoxOwners.publish();
Events.publish();
Measurements.publish();
OpqBoxes.publish();
SystemStats.publish();
Trends.publish();
UserProfiles.publish();
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"synced-cron.js":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// imports/startup/server/synced-cron.js                                                                               //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
let Meteor;
module.watch(require("meteor/meteor"), {
  Meteor(v) {
    Meteor = v;
  }

}, 0);
let SyncedCron;
module.watch(require("meteor/percolate:synced-cron"), {
  SyncedCron(v) {
    SyncedCron = v;
  }

}, 1);
let SystemStats;
module.watch(require("../../api/system-stats/SystemStatsCollection.js"), {
  SystemStats(v) {
    SystemStats = v;
  }

}, 2);
SyncedCron.config({
  log: Meteor.settings.syncedCronLogging
});

function startupSystemStatsCronjob() {
  // Default the update interval to 60 seconds if not supplied in configuration file.
  const updateIntervalSeconds = Meteor.settings.systemStatsUpdateIntervalSeconds || 60;
  SyncedCron.add({
    name: 'Update the SystemStats collection with current collection counts',

    schedule(parser) {
      return parser.text(`every ${updateIntervalSeconds} seconds`); // Parser is a later.js parse object.
    },

    job() {
      SystemStats.updateCounts();
    }

  });
  console.log(`Starting SyncedCron to update System Stats every ${updateIntervalSeconds} seconds.`);
  SyncedCron.start();
}

Meteor.startup(() => {
  startupSystemStatsCronjob();
});
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}}},"modules":{"utils.js":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// imports/modules/utils.js                                                                                            //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
module.export({
  progressBarSetup: () => progressBarSetup,
  progressBarPrinter: () => progressBarPrinter,
  colorQuantify: () => colorQuantify,
  timeUnitString: () => timeUnitString
});
let Meteor;
module.watch(require("meteor/meteor"), {
  Meteor(v) {
    Meteor = v;
  }

}, 0);
let check;
module.watch(require("meteor/check"), {
  check(v) {
    check = v;
  }

}, 1);
let Moment;
module.watch(require("moment"), {
  default(v) {
    Moment = v;
  }

}, 2);

function progressBarSetup(total, updateRate, message) {
  let timerHandle = null;
  let currentVal = 0;
  const totalVal = total - 1; // Assuming 0 based counting.

  if (!timerHandle) {
    timerHandle = Meteor.setInterval(() => {
      progressBarPrinter(currentVal, totalVal, '=', 30, message); // eslint-disable-line no-use-before-define
    }, updateRate);
  }

  return {
    clearInterval() {
      if (timerHandle) Meteor.clearInterval(timerHandle);
      process.stdout.write('\n'); // Final newline after progressBarPrinter is done.
    },

    updateBar(newCurrent) {
      currentVal = newCurrent;
    }

  };
}

function progressBarPrinter(current, total, tickChar, maxTicks, message) {
  // Create 'empty' progress bar, internally represented as an array. Set start and end brackets of the progress bar.
  const progressBar = Array.from('.'.repeat(maxTicks + 2));
  progressBar[0] = '[';
  progressBar[progressBar.length - 1] = ']';
  const progressPercentage = current / total * 100;
  const currentBars = maxTicks * (progressPercentage / 100.0);
  progressBar.fill(tickChar, 1, currentBars + 1); // process.stdout.write('\033[F'); // ANSI code to move cursor up one line.

  process.stdout.write('\x1B[F'); // Using hex instead of octal code because of eslint parser error.

  process.stdout.write(`\n\r${message} ${progressBar.join('')} (${progressPercentage.toFixed(1)}%)`);
}

const colorQuantify = (dataValue, minValue, maxValue, colorRange) => {
  check(dataValue, Number);
  check(minValue, Number);
  check(maxValue, Number);
  check(colorRange, [String]); // DomainDifference / NumColors
  // Gives us the value that evenly splits up the dataDomain based on the given number of colors.

  const dataDomainIncrement = Math.abs(maxValue - minValue) / colorRange.length;
  let resultColor = null;

  for (let i = 0; i < colorRange.length; i++) {
    if (dataValue < minValue + dataDomainIncrement * (i + 1)) {
      resultColor = colorRange[i];
      break;
    }
  } // Takes care of case where dataValue is larger than maxValue (chooses the last color). Note that the above loop
  // will take care of the case where dataValue is smaller than minValue (chooses the first color)


  if (!resultColor) resultColor = colorRange[colorRange.length - 1];
  return resultColor;
};

const timeUnitString = (date, timeUnit) => {
  const mDate = Moment(date);
  const hour = mDate.hour(); // 0-23

  const dayOfMonth = mDate.date(); // 1-31

  const day = mDate.dayOfYear(); // 1-366

  const week = mDate.week(); // 1-52

  const month = mDate.month(); // 0-11

  const year = mDate.year(); // 4 digit year
  // All keys are appended with year to ensure uniqueness of key (in case we're given a long time range).

  let timeUnitKey;

  switch (timeUnit) {
    case 'hourOfDay':
      // Hour of day. Format: hour-day-year. E.g. 23-365-2014, 4-125-1999, etc.
      timeUnitKey = `${hour}-${day}-${year}`;
      break;

    case 'dayOfMonth':
      // Day of month. Format: dayOfMonth-month-year. E.g. 28-11-2008, 31-4-2012, etc.
      timeUnitKey = `${dayOfMonth}-${month}-${year}`;
      break;

    case 'day':
      // Day of year. Format: dayOfYear-year. E.g. 365-2002, 147-1945, etc.
      timeUnitKey = `${day}-${year}`;
      break;

    case 'week':
      // Week of year. Format: week-year. E.g. 51-2006, 4-1998, etc.
      timeUnitKey = `${week}-${year}`;
      break;

    case 'month':
      // Month of year. Format: month-year. E.g. 2-1988, 11-2014, etc.
      timeUnitKey = `${month}-${year}`;
      break;

    case 'year':
      // 4 digit year. Format: year. E.g. 1945, 1999, 2017, etc.
      timeUnitKey = year;
      break;

    default:
      break;
  }

  return timeUnitKey;
};
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}}},"server":{"main.js":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// server/main.js                                                                                                      //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
module.watch(require("../imports/startup/both/index.js"));
module.watch(require("../imports/startup/server/index.js"));
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}}},{
  "extensions": [
    ".js",
    ".json",
    ".jsx"
  ]
});
require("/server/main.js");
//# sourceURL=meteor://💻app/app/app.js
//# sourceMappingURL=data:application/json;charset=utf8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIm1ldGVvcjovL/CfkrthcHAvaW1wb3J0cy9hcGkvYmFzZS9CYXNlQ29sbGVjdGlvbi5qcyIsIm1ldGVvcjovL/CfkrthcHAvaW1wb3J0cy9hcGkvYm94LWV2ZW50cy9Cb3hFdmVudHNDb2xsZWN0aW9uLmpzIiwibWV0ZW9yOi8v8J+Su2FwcC9pbXBvcnRzL2FwaS9ib3gtZXZlbnRzL0JveEV2ZW50c0NvbGxlY3Rpb25NZXRob2RzLmpzIiwibWV0ZW9yOi8v8J+Su2FwcC9pbXBvcnRzL2FwaS9ib3gtZXZlbnRzL2luZGV4LmpzIiwibWV0ZW9yOi8v8J+Su2FwcC9pbXBvcnRzL2FwaS9ldmVudHMvRXZlbnRzQ29sbGVjdGlvbi5qcyIsIm1ldGVvcjovL/CfkrthcHAvaW1wb3J0cy9hcGkvZXZlbnRzL0V2ZW50c0NvbGxlY3Rpb25NZXRob2RzLmpzIiwibWV0ZW9yOi8v8J+Su2FwcC9pbXBvcnRzL2FwaS9ldmVudHMvaW5kZXguanMiLCJtZXRlb3I6Ly/wn5K7YXBwL2ltcG9ydHMvYXBpL2ZzLWNodW5rcy9GU0NodW5rc0NvbGxlY3Rpb24uanMiLCJtZXRlb3I6Ly/wn5K7YXBwL2ltcG9ydHMvYXBpL2ZzLWNodW5rcy9pbmRleC5qcyIsIm1ldGVvcjovL/CfkrthcHAvaW1wb3J0cy9hcGkvZnMtZmlsZXMvRlNGaWxlc0NvbGxlY3Rpb24uanMiLCJtZXRlb3I6Ly/wn5K7YXBwL2ltcG9ydHMvYXBpL2ZzLWZpbGVzL0ZTRmlsZXNDb2xsZWN0aW9uTWV0aG9kcy5qcyIsIm1ldGVvcjovL/CfkrthcHAvaW1wb3J0cy9hcGkvZnMtZmlsZXMvaW5kZXguanMiLCJtZXRlb3I6Ly/wn5K7YXBwL2ltcG9ydHMvYXBpL21lYXN1cmVtZW50cy9NZWFzdXJlbWVudHNDb2xsZWN0aW9uLmpzIiwibWV0ZW9yOi8v8J+Su2FwcC9pbXBvcnRzL2FwaS9tZWFzdXJlbWVudHMvTWVhc3VyZW1lbnRzQ29sbGVjdGlvbk1ldGhvZHMuanMiLCJtZXRlb3I6Ly/wn5K7YXBwL2ltcG9ydHMvYXBpL21lYXN1cmVtZW50cy9pbmRleC5qcyIsIm1ldGVvcjovL/CfkrthcHAvaW1wb3J0cy9hcGkvb3BxLWJveGVzL09wcUJveGVzQ29sbGVjdGlvbi5qcyIsIm1ldGVvcjovL/CfkrthcHAvaW1wb3J0cy9hcGkvb3BxLWJveGVzL09wcUJveGVzQ29sbGVjdGlvbk1ldGhvZHMuanMiLCJtZXRlb3I6Ly/wn5K7YXBwL2ltcG9ydHMvYXBpL29wcS1ib3hlcy9pbmRleC5qcyIsIm1ldGVvcjovL/CfkrthcHAvaW1wb3J0cy9hcGkvc3lzdGVtLXN0YXRzL1N5c3RlbVN0YXRzQ29sbGVjdGlvbi5qcyIsIm1ldGVvcjovL/CfkrthcHAvaW1wb3J0cy9hcGkvdHJlbmRzL1RyZW5kc0NvbGxlY3Rpb24uanMiLCJtZXRlb3I6Ly/wn5K7YXBwL2ltcG9ydHMvYXBpL3RyZW5kcy9UcmVuZHNDb2xsZWN0aW9uTWV0aG9kcy5qcyIsIm1ldGVvcjovL/CfkrthcHAvaW1wb3J0cy9hcGkvdHJlbmRzL2luZGV4LmpzIiwibWV0ZW9yOi8v8J+Su2FwcC9pbXBvcnRzL2FwaS91c2Vycy9Cb3hPd25lcnNDb2xsZWN0aW9uLmpzIiwibWV0ZW9yOi8v8J+Su2FwcC9pbXBvcnRzL2FwaS91c2Vycy9Vc2VyUHJvZmlsZXNDb2xsZWN0aW9uLmpzIiwibWV0ZW9yOi8v8J+Su2FwcC9pbXBvcnRzL2FwaS91c2Vycy9pbmRleC5qcyIsIm1ldGVvcjovL/CfkrthcHAvaW1wb3J0cy9zdGFydHVwL2JvdGgvaW5kZXguanMiLCJtZXRlb3I6Ly/wn5K7YXBwL2ltcG9ydHMvc3RhcnR1cC9zZXJ2ZXIvaW5kZXguanMiLCJtZXRlb3I6Ly/wn5K7YXBwL2ltcG9ydHMvc3RhcnR1cC9zZXJ2ZXIvaW5pdC1ib3hlcy5qcyIsIm1ldGVvcjovL/CfkrthcHAvaW1wb3J0cy9zdGFydHVwL3NlcnZlci9pbml0LXVzZXJzLmpzIiwibWV0ZW9yOi8v8J+Su2FwcC9pbXBvcnRzL3N0YXJ0dXAvc2VydmVyL3B1YmxpY2F0aW9ucy5qcyIsIm1ldGVvcjovL/CfkrthcHAvaW1wb3J0cy9zdGFydHVwL3NlcnZlci9zeW5jZWQtY3Jvbi5qcyIsIm1ldGVvcjovL/CfkrthcHAvaW1wb3J0cy9tb2R1bGVzL3V0aWxzLmpzIiwibWV0ZW9yOi8v8J+Su2FwcC9zZXJ2ZXIvbWFpbi5qcyJdLCJuYW1lcyI6WyJNZXRlb3IiLCJtb2R1bGUiLCJ3YXRjaCIsInJlcXVpcmUiLCJ2IiwiTW9uZ28iLCJTaW1wbGVTY2hlbWEiLCJkZWZhdWx0IiwiXyIsIk1vbWVudCIsIkJhc2VDb2xsZWN0aW9uIiwiY29uc3RydWN0b3IiLCJjb2xsZWN0aW9uTmFtZSIsInNjaGVtYSIsIkVycm9yIiwiX2NvbGxlY3Rpb25OYW1lIiwiX3NjaGVtYSIsIl9jb2xsZWN0aW9uIiwiQ29sbGVjdGlvbiIsImlkR2VuZXJhdGlvbiIsImF0dGFjaFNjaGVtYSIsImdldFNjaGVtYSIsImNvdW50IiwiZmluZCIsImNvdW50VG9kYXkiLCJ0aW1lRmllbGQiLCJzdGFydFRvZGF5Iiwic3RhcnRPZiIsInZhbHVlT2YiLCJxdWVyeSIsIiRndGUiLCJzZWxlY3RvciIsIm9wdGlvbnMiLCJmaW5kT25lIiwiaXNEZWZpbmVkIiwibmFtZSIsIl9pZCIsInVwZGF0ZSIsIm1vZGlmaWVyIiwicHVibGlzaCIsImlzU2VydmVyIiwiZ2V0UHVibGljYXRpb25OYW1lIiwiZHVtcE9uZSIsImRvY0lEIiwiZHVtcEFsbCIsImNvbnRlbnRzIiwibWFwIiwiZG9jIiwiZmluZERvYyIsImNoZWNrSW50ZWdyaXR5IiwicmVzdG9yZU9uZSIsImR1bXBPYmplY3QiLCJkZWZpbmUiLCJyZXN0b3JlQWxsIiwiZHVtcE9iamVjdHMiLCJlYWNoIiwicmVtb3ZlQWxsIiwiaXRlbXMiLCJmZXRjaCIsImluc3RhbmNlIiwiZm9yRWFjaCIsImkiLCJyZW1vdmUiLCJleHBvcnREZWZhdWx0IiwiZXhwb3J0IiwiQm94RXZlbnRzIiwiRXZlbnRzIiwicHJvZ3Jlc3NCYXJTZXR1cCIsIkJveEV2ZW50c0NvbGxlY3Rpb24iLCJ0eXBlIiwiT2JqZWN0SUQiLCJldmVudF9pZCIsIk51bWJlciIsImJveF9pZCIsIlN0cmluZyIsImV2ZW50X3N0YXJ0X3RpbWVzdGFtcF9tcyIsImV2ZW50X2VuZF90aW1lc3RhbXBfbXMiLCJ3aW5kb3dfdGltZXN0YW1wc19tcyIsInRoZCIsIml0aWMiLCJsb2NhdGlvbiIsIk9iamVjdCIsIm9wdGlvbmFsIiwiZGF0YV9mc19maWxlbmFtZSIsInB1YmxpY2F0aW9uTmFtZXMiLCJFVkVOVF9EQVRBIiwic2VydmVyIiwicmF3Q29sbGVjdGlvbiIsImNyZWF0ZUluZGV4IiwiYmFja2dyb3VuZCIsImV2ZW50X3N0YXJ0IiwiZXZlbnRfZW5kIiwid2luZG93X3RpbWVzdGFtcHMiLCJpbnNlcnQiLCJwcm9ibGVtcyIsInRvdGFsQ291bnQiLCJ2YWxpZGF0aW9uQ29udGV4dCIsIm5hbWVkQ29udGV4dCIsInBiIiwiaW5kZXgiLCJ1cGRhdGVCYXIiLCJ2YWxpZGF0ZSIsImlzVmFsaWQiLCJwdXNoIiwiSlNPTiIsInN0cmluZ2lmeSIsImludmFsaWRLZXlzIiwicmVzZXRWYWxpZGF0aW9uIiwiY2xlYXJJbnRlcnZhbCIsInRvdGFsQm94RXZlbnRzQ291bnQiLCJnZXRCb3hFdmVudCIsIlZhbGlkYXRlZE1ldGhvZCIsInZhbGlkYXRvciIsImNsZWFuIiwicnVuIiwiaXNTaW11bGF0aW9uIiwiYm94RXZlbnQiLCJjaGVjayIsIk1hdGNoIiwiRXZlbnRzQ29sbGVjdGlvbiIsImRlc2NyaXB0aW9uIiwiYm94ZXNfdHJpZ2dlcmVkIiwiYm94ZXNfcmVjZWl2ZWQiLCJ0YXJnZXRfZXZlbnRfc3RhcnRfdGltZXN0YW1wX21zIiwidGFyZ2V0X2V2ZW50X2VuZF90aW1lc3RhbXBfbXMiLCJsYXRlbmNpZXNfbXMiLCJBcnJheSIsImV2ZW50VHlwZXMiLCJGUkVRVUVOQ1lfU0FHX1RZUEUiLCJGUkVRVUVOQ1lfU1dFTExfVFlQRSIsIlZPTFRBR0VfU0FHX1RZUEUiLCJWT0xUQUdFX1NXRUxMX1RZUEUiLCJUSERfVFlQRSIsIk9USEVSX1RZUEUiLCJHRVRfRVZFTlRTIiwiR0VUX1JFQ0VOVF9FVkVOVFMiLCJzZWxmIiwic3RhcnRUaW1lIiwiZW5kVGltZSIsIk1heWJlIiwicXVlcnlDb25zdHJ1Y3RvcnMiLCJnZXRFdmVudHMiLCJudW1FdmVudHMiLCJleGNsdWRlT3RoZXIiLCIkbmUiLCJldmVudHMiLCJzb3J0IiwibGltaXQiLCIkbHRlIiwidG90YWxFdmVudHNDb3VudCIsImV2ZW50c0NvdW50TWFwIiwiZ2V0RXZlbnRCeUV2ZW50SUQiLCJnZXRNb3N0UmVjZW50RXZlbnQiLCJkZW1hcGlmeSIsInRpbWVVbml0U3RyaW5nIiwidGltZVVuaXQiLCJldmVudE1ldGFEYXRhIiwiZXZlbnRDb3VudE1hcCIsIk1hcCIsImV2ZW50IiwidGltZVVuaXRLZXkiLCJoYXMiLCJzZXQiLCJnZXQiLCJtb3N0UmVjZW50RXZlbnQiLCJGU0NodW5rcyIsIkZTRmlsZXMiLCJGU0NodW5rc0NvbGxlY3Rpb24iLCJmaWxlc19pZCIsIm4iLCJkYXRhIiwiVWludDhBcnJheSIsImZzRmlsZSIsIkZTRmlsZXNDb2xsZWN0aW9uIiwiZmlsZW5hbWUiLCJsZW5ndGgiLCJjaHVua1NpemUiLCJ1cGxvYWREYXRlIiwiRGF0ZSIsIm1kNSIsIm1ldGFkYXRhIiwiZ2V0RXZlbnREYXRhIiwiZmlsZSIsImNodW5rcyIsImludDE2Q2h1bmtzIiwidG90YWxTaXplIiwiY2h1bmsiLCJ1OCIsInMxNiIsIkludDE2QXJyYXkiLCJidWZmZXIiLCJjb21iaW5lZEludDE2Q2h1bmtzIiwib2Zmc2V0IiwiZnJvbSIsIk1lYXN1cmVtZW50cyIsIk9wcUJveGVzIiwiTWVhc3VyZW1lbnRzQ29sbGVjdGlvbiIsInRpbWVzdGFtcF9tcyIsInZvbHRhZ2UiLCJmcmVxdWVuY3kiLCJleHBpcmVBdCIsIlJFQ0VOVF9NRUFTVVJFTUVOVFMiLCJib3hJRHMiLCJpbmNsdWRlcyIsInN0YXJ0VGltZVNlY29uZHNBZ28iLCJib3hJRCIsInN0YXJ0VGltZU1zIiwibm93IiwicHVibGlzaGVkTWVhc3VyZW1lbnRzTWFwIiwiaW5pdCIsIm1lYXN1cmVtZW50c0hhbmRsZSIsImZpZWxkcyIsInBvbGxpbmdJbnRlcnZhbE1zIiwib2JzZXJ2ZUNoYW5nZXMiLCJhZGRlZCIsImlkIiwidGltZXN0YW1wIiwicmVtb3ZlZCIsImRlbGV0ZSIsInJlYWR5Iiwib25TdG9wIiwic3RvcCIsInRvdGFsTWVhc3VyZW1lbnRzQ291bnQiLCJjaGVja0JveFN0YXR1cyIsImFjdGl2ZUJveElEcyIsImdldEFjdGl2ZUJveElkcyIsImdldEV2ZW50TWVhc3VyZW1lbnRzQnlNZXRhRGF0YUlkIiwiZ2V0RXZlbnRNZWFzdXJlbWVudHMiLCJkeWdyYXBoTWVyZ2VEYXRhc2V0cyIsIm9uZU1pbnV0ZUFnbyIsInN1YnRyYWN0IiwibWVhc3VyZW1lbnRzIiwidW5pcSIsInJlY2VudE1lYXN1cmVtZW50cyIsInBsdWNrIiwiYSIsImIiLCJldmVudE1ldGFEYXRhSWQiLCJldmVudE1lYXN1cmVtZW50cyIsImZpcnN0TWVhc3VyZW1lbnRUaW1lc3RhbXAiLCJsYXN0TWVhc3VyZW1lbnRUaW1lc3RhbXAiLCJldmVudER1cmF0aW9uTXMiLCJwcmVjZWRpbmdUaW1lc3RhbXAiLCJwcm9jZWVkaW5nVGltZXN0YW1wIiwicHJlY2VkaW5nTWVhc3VyZW1lbnRzIiwicHJvY2VlZGluZ01lYXN1cmVtZW50cyIsImNvbnNvbGUiLCJsb2ciLCJkdXJhdGlvbiIsInhGaWVsZE5hbWUiLCJ5RmllbGROYW1lIiwiZGF0YXNldHMiLCJtZXJnZWREYXRhIiwibnVtRGF0YXNldHMiLCJkYXRhc2V0Iiwid3JpdGVJbmRleCIsIngiLCJ5IiwiYXJyIiwibmV3QXJyIiwiZmlsbCIsIm1lcmdlZERhdGFzZXQiLCJrZXlzIiwia2V5IiwiT3BxQm94ZXNDb2xsZWN0aW9uIiwidW5wbHVnZ2VkIiwiQm9vbGVhbiIsImNhbGlicmF0aW9uX2NvbnN0YW50IiwibG9jYXRpb25zIiwiYmxhY2tib3giLCJuZXdMb2NzIiwibWFrZUxvY2F0aW9uQXJyYXkiLCJ1cHNlcnQiLCIkc2V0IiwidW5kZWZpbmVkIiwibW9tZW50VGltZXN0YW1wIiwidGltZV9zdGFtcF9tcyIsImZpbmRCb3giLCJib3hEb2MiLCJmaW5kQm94SWRzIiwiZG9jcyIsInRvdGFsT3BxQm94ZXNDb3VudCIsImdldEJveENhbGlicmF0aW9uQ29uc3RhbnQiLCJnZXRCb3hJRHMiLCJvcHFCb3giLCJvcHFCb3hlcyIsImJveCIsIlN5c3RlbVN0YXRzIiwiVHJlbmRzIiwiVXNlclByb2ZpbGVzIiwiU3lzdGVtU3RhdHNDb2xsZWN0aW9uIiwiZXZlbnRzX2NvdW50IiwiZXZlbnRzX2NvdW50X3RvZGF5IiwiYm94X2V2ZW50c19jb3VudCIsImJveF9ldmVudHNfY291bnRfdG9kYXkiLCJtZWFzdXJlbWVudHNfY291bnQiLCJtZWFzdXJlbWVudHNfY291bnRfdG9kYXkiLCJ0cmVuZHNfY291bnQiLCJ0cmVuZHNfY291bnRfdG9kYXkiLCJvcHFfYm94ZXNfY291bnQiLCJ1c2Vyc19jb3VudCIsImJveF90cmVuZF9zdGF0cyIsImhlYWx0aCIsImdldEJveFRyZW5kU3RhdCIsImJveElkIiwiZmlyc3RUcmVuZERvYyIsIm9sZGVzdFRyZW5kIiwiZmlyc3RUcmVuZCIsImxhc3RUcmVuZERvYyIsIm5ld2VzdFRyZW5kIiwibGFzdFRyZW5kIiwidG90YWxUcmVuZHMiLCJjb3VudFRyZW5kcyIsImdldEhlYWx0aEFycmF5IiwiaWNvbiIsImNvbG9yIiwidXBkYXRlQ291bnRzIiwic3lzdGVtU3RhdHNEb2MiLCJUcmVuZHNDb2xsZWN0aW9uIiwiR0VUX1JFQ0VOVF9UUkVORFMiLCJUUkVORFNfUkVDRU5UX01PTlRIIiwiJGd0IiwibnVtVHJlbmRzIiwidHJlbmRzIiwidG90YWxUcmVuZHNDb3VudCIsImdldE1vc3RSZWNlbnRUcmVuZE1vbnRoIiwiZGFpbHlUcmVuZHNJblJhbmdlIiwiZGFpbHlUcmVuZHMiLCJ0cmVuZCIsInRyZW5kTW9tZW50IiwibW9udGgiLCJ5ZWFyIiwic3RhcnREYXRlX21zIiwiZW5kRGF0ZV9tcyIsInRyZW5kU3VtbWFyeVNoYXBlIiwibWluIiwiTUFYX1NBRkVfSU5URUdFUiIsIm1pbkRhdGUiLCJtYXgiLCJNSU5fU0FGRV9JTlRFR0VSIiwibWF4RGF0ZSIsImF2ZXJhZ2UiLCJ0b3RhbERvY0NvdW50IiwiYXNzaWduIiwiYXNzb2NpYXRlZFRyZW5kcyIsImVuZE9mIiwic3RhcnQiLCJlbmQiLCJhZGQiLCJjbG9uZURlZXAiLCJ0cmVuZERheV9tcyIsImR0diIsInVwdGltZSIsInJ0diIsInJhbmdlVHJlbmRzIiwiZGFpbHlUcmVuZHNNYXAiLCJJbmZpbml0eSIsIkJveE93bmVycyIsIkJveE93bmVyc0NvbGxlY3Rpb24iLCJ1c2VybmFtZSIsImV4aXN0aW5nRG9jIiwiZmluZEJveGVzV2l0aE93bmVyIiwiZmluZEJveElkc1dpdGhPd25lciIsImZpbmRPd25lcnNXaXRoQm94SWQiLCJyZW1vdmVCb3hlc1dpdGhPd25lciIsIkFjY291bnRzIiwiUm9sZXMiLCJVc2VyUHJvZmlsZXNDb2xsZWN0aW9uIiwiZmlyc3ROYW1lIiwibGFzdE5hbWUiLCJyb2xlIiwicGFzc3dvcmQiLCJib3hJZHMiLCJpc1N0cmluZyIsInVzZXIiLCJmaW5kVXNlckJ5VXNlcm5hbWUiLCJ1c2VySWQiLCJjcmVhdGVVc2VyIiwiZW1haWwiLCJwcm9maWxlSWQiLCJhZGRVc2Vyc1RvUm9sZXMiLCJmaW5kQnlVc2VybmFtZSIsInByb2ZpbGUiLCJyb2xlcyIsInVzZXJzIiwidXNlclByb2ZpbGVzIiwiaW5pdEJveGVzIiwiYm94ZXMiLCJzZXR0aW5ncyIsInN0YXJ0dXAiLCJpbml0VXNlcnMiLCJwcm9maWxlcyIsIlN5bmNlZENyb24iLCJjb25maWciLCJzeW5jZWRDcm9uTG9nZ2luZyIsInN0YXJ0dXBTeXN0ZW1TdGF0c0Nyb25qb2IiLCJ1cGRhdGVJbnRlcnZhbFNlY29uZHMiLCJzeXN0ZW1TdGF0c1VwZGF0ZUludGVydmFsU2Vjb25kcyIsInNjaGVkdWxlIiwicGFyc2VyIiwidGV4dCIsImpvYiIsInByb2dyZXNzQmFyUHJpbnRlciIsImNvbG9yUXVhbnRpZnkiLCJ0b3RhbCIsInVwZGF0ZVJhdGUiLCJtZXNzYWdlIiwidGltZXJIYW5kbGUiLCJjdXJyZW50VmFsIiwidG90YWxWYWwiLCJzZXRJbnRlcnZhbCIsInByb2Nlc3MiLCJzdGRvdXQiLCJ3cml0ZSIsIm5ld0N1cnJlbnQiLCJjdXJyZW50IiwidGlja0NoYXIiLCJtYXhUaWNrcyIsInByb2dyZXNzQmFyIiwicmVwZWF0IiwicHJvZ3Jlc3NQZXJjZW50YWdlIiwiY3VycmVudEJhcnMiLCJqb2luIiwidG9GaXhlZCIsImRhdGFWYWx1ZSIsIm1pblZhbHVlIiwibWF4VmFsdWUiLCJjb2xvclJhbmdlIiwiZGF0YURvbWFpbkluY3JlbWVudCIsIk1hdGgiLCJhYnMiLCJyZXN1bHRDb2xvciIsImRhdGUiLCJtRGF0ZSIsImhvdXIiLCJkYXlPZk1vbnRoIiwiZGF5IiwiZGF5T2ZZZWFyIiwid2VlayJdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7QUFBQSxJQUFJQSxNQUFKO0FBQVdDLE9BQU9DLEtBQVAsQ0FBYUMsUUFBUSxlQUFSLENBQWIsRUFBc0M7QUFBQ0gsU0FBT0ksQ0FBUCxFQUFTO0FBQUNKLGFBQU9JLENBQVA7QUFBUzs7QUFBcEIsQ0FBdEMsRUFBNEQsQ0FBNUQ7QUFBK0QsSUFBSUMsS0FBSjtBQUFVSixPQUFPQyxLQUFQLENBQWFDLFFBQVEsY0FBUixDQUFiLEVBQXFDO0FBQUNFLFFBQU1ELENBQU4sRUFBUTtBQUFDQyxZQUFNRCxDQUFOO0FBQVE7O0FBQWxCLENBQXJDLEVBQXlELENBQXpEO0FBQTRELElBQUlFLFlBQUo7QUFBaUJMLE9BQU9DLEtBQVAsQ0FBYUMsUUFBUSxjQUFSLENBQWIsRUFBcUM7QUFBQ0ksVUFBUUgsQ0FBUixFQUFVO0FBQUNFLG1CQUFhRixDQUFiO0FBQWU7O0FBQTNCLENBQXJDLEVBQWtFLENBQWxFOztBQUFxRSxJQUFJSSxDQUFKOztBQUFNUCxPQUFPQyxLQUFQLENBQWFDLFFBQVEsUUFBUixDQUFiLEVBQStCO0FBQUNJLFVBQVFILENBQVIsRUFBVTtBQUFDSSxRQUFFSixDQUFGO0FBQUk7O0FBQWhCLENBQS9CLEVBQWlELENBQWpEO0FBQW9ELElBQUlLLE1BQUo7QUFBV1IsT0FBT0MsS0FBUCxDQUFhQyxRQUFRLFFBQVIsQ0FBYixFQUErQjtBQUFDSSxVQUFRSCxDQUFSLEVBQVU7QUFBQ0ssYUFBT0wsQ0FBUDtBQUFTOztBQUFyQixDQUEvQixFQUFzRCxDQUF0RDs7QUFPM1M7OztBQUdBLE1BQU1NLGNBQU4sQ0FBcUI7QUFFbkI7Ozs7OztBQU1BQyxjQUFZQyxjQUFaLEVBQTRCQyxNQUE1QixFQUFvQztBQUNsQyxRQUFJLE9BQU9ELGNBQVAsS0FBMEIsUUFBOUIsRUFBd0MsTUFBTSxJQUFJWixPQUFPYyxLQUFYLENBQWlCLGtDQUFqQixDQUFOO0FBQ3hDLFFBQUksRUFBRUQsa0JBQWtCUCxZQUFwQixDQUFKLEVBQXVDLE1BQU0sSUFBSU4sT0FBT2MsS0FBWCxDQUFpQix5Q0FBakIsQ0FBTjtBQUV2QyxTQUFLQyxlQUFMLEdBQXVCSCxjQUF2QjtBQUNBLFNBQUtJLE9BQUwsR0FBZUgsTUFBZjtBQUNBLFNBQUtJLFdBQUwsR0FBbUIsSUFBSVosTUFBTWEsVUFBVixDQUFxQk4sY0FBckIsRUFBcUM7QUFBRU8sb0JBQWM7QUFBaEIsS0FBckMsQ0FBbkI7O0FBQ0EsU0FBS0YsV0FBTCxDQUFpQkcsWUFBakIsQ0FBOEJQLE1BQTlCO0FBQ0Q7QUFFRDs7Ozs7O0FBSUFRLGNBQVk7QUFDVixXQUFPLEtBQUtMLE9BQVo7QUFDRDtBQUVEOzs7Ozs7QUFJQU0sVUFBUTtBQUNOLFdBQU8sS0FBS0wsV0FBTCxDQUFpQk0sSUFBakIsR0FBd0JELEtBQXhCLEVBQVA7QUFDRDtBQUVEOzs7Ozs7OztBQU1BRSxhQUFXQyxTQUFYLEVBQXNCO0FBQ3BCLFVBQU1DLGFBQWFqQixTQUFTa0IsT0FBVCxDQUFpQixLQUFqQixFQUF3QkMsT0FBeEIsRUFBbkI7QUFDQSxVQUFNQyxRQUFRLEVBQWQ7QUFDQUEsVUFBTUosU0FBTixJQUFtQjtBQUFFSyxZQUFNSjtBQUFSLEtBQW5CO0FBQ0EsV0FBTyxLQUFLVCxXQUFMLENBQWlCTSxJQUFqQixDQUFzQk0sS0FBdEIsRUFBNkJQLEtBQTdCLEVBQVA7QUFFRDtBQUVEOzs7Ozs7Ozs7QUFPQUMsT0FBS1EsV0FBVyxFQUFoQixFQUFvQkMsVUFBVSxFQUE5QixFQUFrQztBQUNoQyxXQUFPLEtBQUtmLFdBQUwsQ0FBaUJNLElBQWpCLENBQXNCUSxRQUF0QixFQUFnQ0MsT0FBaEMsQ0FBUDtBQUNEO0FBRUQ7Ozs7Ozs7Ozs7QUFRQUMsVUFBUUYsV0FBVyxFQUFuQixFQUF1QkMsVUFBVSxFQUFqQyxFQUFxQztBQUNuQyxXQUFPLEtBQUtmLFdBQUwsQ0FBaUJnQixPQUFqQixDQUF5QkYsUUFBekIsRUFBbUNDLE9BQW5DLENBQVA7QUFDRDtBQUVEOzs7Ozs7O0FBS0FFLFlBQVVDLElBQVYsRUFBZ0I7QUFDZCxXQUNFLENBQUMsQ0FBQyxLQUFLbEIsV0FBTCxDQUFpQmdCLE9BQWpCLENBQXlCRSxJQUF6QixDQUFGLElBQ0EsQ0FBQyxDQUFDLEtBQUtsQixXQUFMLENBQWlCZ0IsT0FBakIsQ0FBeUI7QUFBRUU7QUFBRixLQUF6QixDQURGLElBRUEsQ0FBQyxDQUFDLEtBQUtsQixXQUFMLENBQWlCZ0IsT0FBakIsQ0FBeUI7QUFBRUcsV0FBS0Q7QUFBUCxLQUF6QixDQUhKO0FBSUQ7QUFFRDs7Ozs7Ozs7O0FBT0FFLFNBQU9OLFdBQVcsRUFBbEIsRUFBc0JPLFdBQVcsRUFBakMsRUFBcUNOLFVBQVUsRUFBL0MsRUFBbUQ7QUFDakQsV0FBTyxLQUFLZixXQUFMLENBQWlCb0IsTUFBakIsQ0FBd0JOLFFBQXhCLEVBQWtDTyxRQUFsQyxFQUE0Q04sT0FBNUMsQ0FBUDtBQUNEO0FBRUQ7Ozs7OztBQUlBTyxZQUFVO0FBQ1IsUUFBSXZDLE9BQU93QyxRQUFYLEVBQXFCO0FBQ25CeEMsYUFBT3VDLE9BQVAsQ0FBZSxLQUFLeEIsZUFBcEIsRUFBcUMsTUFBTSxLQUFLRSxXQUFMLENBQWlCTSxJQUFqQixFQUEzQztBQUNEO0FBQ0Y7QUFFRDs7Ozs7OztBQUtBa0IsdUJBQXFCO0FBQ25CLFdBQU8sS0FBSzFCLGVBQVo7QUFDRDtBQUVEOzs7Ozs7OztBQU1BMkIsVUFBUUMsS0FBUixFQUFlO0FBQUU7QUFDZixVQUFNLElBQUkzQyxPQUFPYyxLQUFYLENBQWtCLGdEQUErQyxLQUFLQyxlQUFnQixFQUF0RixDQUFOO0FBQ0Q7QUFFRDs7Ozs7Ozs7O0FBT0E2QixZQUFVO0FBQ1IsV0FBTztBQUFFVCxZQUFNLEtBQUtwQixlQUFiO0FBQThCOEIsZ0JBQVUsS0FBS3RCLElBQUwsR0FBWXVCLEdBQVosQ0FBZ0JDLE9BQU8sS0FBS0wsT0FBTCxDQUFhSyxJQUFJWCxHQUFqQixDQUF2QjtBQUF4QyxLQUFQO0FBQ0Q7QUFFRDs7Ozs7OztBQUtBWSxVQUFRTCxLQUFSLEVBQWU7QUFDYixVQUFNSSxNQUFNLEtBQUtkLE9BQUwsQ0FBYTtBQUFFRyxXQUFLTztBQUFQLEtBQWIsRUFBNkIsRUFBN0IsQ0FBWjs7QUFDQSxRQUFJLENBQUNJLEdBQUwsRUFBVTtBQUNSLFlBQU0sSUFBSS9DLE9BQU9jLEtBQVgsQ0FBa0IsdUNBQXNDNkIsS0FBTSxtQkFBa0IsS0FBSzVCLGVBQWdCLEdBQXJHLENBQU47QUFDRDs7QUFDRCxXQUFPZ0MsR0FBUDtBQUNEO0FBRUQ7Ozs7Ozs7QUFLQUUsbUJBQWlCO0FBQUU7QUFDakIsV0FBTyxDQUFDLDREQUFELENBQVA7QUFDRDtBQUVEOzs7Ozs7QUFJQUMsYUFBV0MsVUFBWCxFQUF1QjtBQUNyQixRQUFJLE9BQU8sS0FBS0MsTUFBWixLQUF1QixVQUEzQixFQUF1QztBQUNyQyxhQUFPLEtBQUtBLE1BQUwsQ0FBWUQsVUFBWixDQUFQO0FBQ0Q7O0FBQ0QsV0FBTyxJQUFQO0FBQ0Q7QUFFRDs7Ozs7O0FBSUFFLGFBQVdDLFdBQVgsRUFBd0I7QUFDdEI5QyxNQUFFK0MsSUFBRixDQUFPRCxXQUFQLEVBQW9CSCxjQUFjLEtBQUtELFVBQUwsQ0FBZ0JDLFVBQWhCLENBQWxDO0FBQ0Q7QUFFRDs7Ozs7Ozs7O0FBT0FLLGNBQVk7QUFDVixVQUFNQyxRQUFRLEtBQUt4QyxXQUFMLENBQWlCTSxJQUFqQixHQUF3Qm1DLEtBQXhCLEVBQWQ7O0FBQ0EsVUFBTUMsV0FBVyxJQUFqQjs7QUFDQW5ELE1BQUVvRCxPQUFGLENBQVVILEtBQVYsRUFBa0JJLENBQUQsSUFBTztBQUN0QkYsZUFBU0csTUFBVCxDQUFnQkQsRUFBRXpCLEdBQWxCO0FBQ0QsS0FGRDs7QUFHQSxXQUFPLElBQVA7QUFDRDtBQUVEOzs7Ozs7QUFJQTBCLFNBQU9uQixLQUFQLEVBQWM7QUFDWixTQUFLMUIsV0FBTCxDQUFpQjZDLE1BQWpCLENBQXdCbkIsS0FBeEI7QUFDRDs7QUFyTWtCOztBQVZyQjFDLE9BQU84RCxhQUFQLENBa05lckQsY0FsTmYsRTs7Ozs7Ozs7Ozs7QUNBQVQsT0FBTytELE1BQVAsQ0FBYztBQUFDQyxhQUFVLE1BQUlBO0FBQWYsQ0FBZDtBQUF5QyxJQUFJakUsTUFBSjtBQUFXQyxPQUFPQyxLQUFQLENBQWFDLFFBQVEsZUFBUixDQUFiLEVBQXNDO0FBQUNILFNBQU9JLENBQVAsRUFBUztBQUFDSixhQUFPSSxDQUFQO0FBQVM7O0FBQXBCLENBQXRDLEVBQTRELENBQTVEO0FBQStELElBQUlDLEtBQUo7QUFBVUosT0FBT0MsS0FBUCxDQUFhQyxRQUFRLGNBQVIsQ0FBYixFQUFxQztBQUFDRSxRQUFNRCxDQUFOLEVBQVE7QUFBQ0MsWUFBTUQsQ0FBTjtBQUFROztBQUFsQixDQUFyQyxFQUF5RCxDQUF6RDtBQUE0RCxJQUFJRSxZQUFKO0FBQWlCTCxPQUFPQyxLQUFQLENBQWFDLFFBQVEsY0FBUixDQUFiLEVBQXFDO0FBQUNJLFVBQVFILENBQVIsRUFBVTtBQUFDRSxtQkFBYUYsQ0FBYjtBQUFlOztBQUEzQixDQUFyQyxFQUFrRSxDQUFsRTtBQUFxRSxJQUFJTSxjQUFKO0FBQW1CVCxPQUFPQyxLQUFQLENBQWFDLFFBQVEsMkJBQVIsQ0FBYixFQUFrRDtBQUFDSSxVQUFRSCxDQUFSLEVBQVU7QUFBQ00scUJBQWVOLENBQWY7QUFBaUI7O0FBQTdCLENBQWxELEVBQWlGLENBQWpGO0FBQW9GLElBQUk4RCxNQUFKO0FBQVdqRSxPQUFPQyxLQUFQLENBQWFDLFFBQVEsNEJBQVIsQ0FBYixFQUFtRDtBQUFDK0QsU0FBTzlELENBQVAsRUFBUztBQUFDOEQsYUFBTzlELENBQVA7QUFBUzs7QUFBcEIsQ0FBbkQsRUFBeUUsQ0FBekU7QUFBNEUsSUFBSStELGdCQUFKO0FBQXFCbEUsT0FBT0MsS0FBUCxDQUFhQyxRQUFRLHFCQUFSLENBQWIsRUFBNEM7QUFBQ2dFLG1CQUFpQi9ELENBQWpCLEVBQW1CO0FBQUMrRCx1QkFBaUIvRCxDQUFqQjtBQUFtQjs7QUFBeEMsQ0FBNUMsRUFBc0YsQ0FBdEY7O0FBT2xlOzs7O0FBSUEsTUFBTWdFLG1CQUFOLFNBQWtDMUQsY0FBbEMsQ0FBaUQ7QUFFL0M7OztBQUdBQyxnQkFBYztBQUNaLFVBQU0sWUFBTixFQUFvQixJQUFJTCxZQUFKLENBQWlCO0FBQ25DOEIsV0FBSztBQUFFaUMsY0FBTWhFLE1BQU1pRTtBQUFkLE9BRDhCO0FBRW5DQyxnQkFBVUMsTUFGeUI7QUFHbkNDLGNBQVFDLE1BSDJCO0FBSW5DQyxnQ0FBMEJILE1BSlM7QUFLbkNJLDhCQUF3QkosTUFMVztBQU1uQ0ssNEJBQXNCLENBQUNMLE1BQUQsQ0FOYTtBQU1IO0FBQ2hDTSxXQUFLTixNQVA4QjtBQVFuQ08sWUFBTUwsTUFSNkI7QUFTbkNNLGdCQUFVO0FBQUVYLGNBQU1ZLE1BQVI7QUFBZ0JDLGtCQUFVO0FBQTFCLE9BVHlCO0FBVW5DLDZCQUF1QjtBQUFFYixjQUFNRyxNQUFSO0FBQWdCVSxrQkFBVTtBQUExQixPQVZZO0FBV25DLDBCQUFvQjtBQUFFYixjQUFNRyxNQUFSO0FBQWdCVSxrQkFBVTtBQUExQixPQVhlO0FBWW5DQyx3QkFBa0JULE1BWmlCLENBWVQ7O0FBWlMsS0FBakIsQ0FBcEI7QUFlQSxTQUFLVSxnQkFBTCxHQUF3QjtBQUN0QkMsa0JBQVk7QUFEVSxLQUF4Qjs7QUFHQSxRQUFJckYsT0FBT3NGLE1BQVgsRUFBbUI7QUFDakIsV0FBS3JFLFdBQUwsQ0FBaUJzRSxhQUFqQixHQUFpQ0MsV0FBakMsQ0FBNkM7QUFBRWIsa0NBQTBCLENBQTVCO0FBQStCRixnQkFBUTtBQUF2QyxPQUE3QyxFQUF5RjtBQUFFZ0Isb0JBQVk7QUFBZCxPQUF6RjtBQUNEO0FBQ0Y7QUFFRDs7Ozs7Ozs7Ozs7Ozs7O0FBYUFyQyxTQUFPO0FBQUVtQixZQUFGO0FBQVlFLFVBQVo7QUFBb0JpQixlQUFwQjtBQUFpQ0MsYUFBakM7QUFBNENDLHFCQUE1QztBQUErRGQsT0FBL0Q7QUFBb0VDLFFBQXBFO0FBQTBFQyxZQUExRTtBQUFvRkc7QUFBcEYsR0FBUCxFQUErRztBQUM3RyxVQUFNeEMsUUFBUSxLQUFLMUIsV0FBTCxDQUFpQjRFLE1BQWpCLENBQXdCO0FBQ3BDdEIsY0FEb0M7QUFDMUJFLFlBRDBCO0FBQ2xCaUIsaUJBRGtCO0FBQ0xDLGVBREs7QUFDTUMsdUJBRE47QUFDeUJkLFNBRHpCO0FBQzhCQyxVQUQ5QjtBQUNvQ0MsY0FEcEM7QUFDOENHO0FBRDlDLEtBQXhCLENBQWQ7O0FBR0EsV0FBT3hDLEtBQVA7QUFDRDtBQUVEOzs7Ozs7O0FBS0FELFVBQVFDLEtBQVIsRUFBZTtBQUNiO0FBQ0EsVUFBTUksTUFBTSxLQUFLQyxPQUFMLENBQWFMLEtBQWIsQ0FBWjtBQUNBLFVBQU00QixXQUFXeEIsSUFBSXdCLFFBQXJCO0FBQ0EsVUFBTUUsU0FBUzFCLElBQUkwQixNQUFuQjtBQUNBLFVBQU1pQixjQUFjM0MsSUFBSTJDLFdBQXhCO0FBQ0EsVUFBTUMsWUFBWTVDLElBQUk0QyxTQUF0QjtBQUNBLFVBQU1DLG9CQUFvQjdDLElBQUk2QyxpQkFBOUI7QUFDQSxVQUFNZCxNQUFNL0IsSUFBSStCLEdBQWhCO0FBQ0EsVUFBTUMsT0FBT2hDLElBQUlnQyxJQUFqQjtBQUNBLFVBQU1DLFdBQVdqQyxJQUFJaUMsUUFBckI7QUFDQSxVQUFNRyxtQkFBbUJwQyxJQUFJb0MsZ0JBQTdCO0FBRUEsV0FBTztBQUFFWixjQUFGO0FBQVlFLFlBQVo7QUFBb0JpQixpQkFBcEI7QUFBaUNDLGVBQWpDO0FBQTRDQyx1QkFBNUM7QUFBK0RkLFNBQS9EO0FBQW9FQyxVQUFwRTtBQUEwRUMsY0FBMUU7QUFBb0ZHO0FBQXBGLEtBQVA7QUFDQTtBQUNEOztBQUVEbEMsbUJBQWlCO0FBQ2YsVUFBTTZDLFdBQVcsRUFBakI7QUFDQSxVQUFNQyxhQUFhLEtBQUt6RSxLQUFMLEVBQW5CO0FBQ0EsVUFBTTBFLG9CQUFvQixLQUFLM0UsU0FBTCxHQUFpQjRFLFlBQWpCLENBQThCLG9CQUE5QixDQUExQjtBQUNBLFVBQU1DLEtBQUsvQixpQkFBaUI0QixVQUFqQixFQUE2QixJQUE3QixFQUFvQyxZQUFXLEtBQUtoRixlQUFnQixlQUFwRSxDQUFYO0FBRUEsU0FBS1EsSUFBTCxHQUFZcUMsT0FBWixDQUFvQixDQUFDYixHQUFELEVBQU1vRCxLQUFOLEtBQWdCO0FBQ2xDRCxTQUFHRSxTQUFILENBQWFELEtBQWIsRUFEa0MsQ0FDYjtBQUVyQjs7QUFDQUgsd0JBQWtCSyxRQUFsQixDQUEyQnRELEdBQTNCOztBQUNBLFVBQUksQ0FBQ2lELGtCQUFrQk0sT0FBbEIsRUFBTCxFQUFrQztBQUNoQztBQUNBUixpQkFBU1MsSUFBVCxDQUFlLCtDQUE4Q3hELElBQUlYLEdBQUksbUJBQWtCb0UsS0FBS0MsU0FBTCxDQUFlVCxrQkFBa0JVLFdBQWxCLEVBQWYsRUFBZ0QsSUFBaEQsRUFBc0QsQ0FBdEQsQ0FBeUQsR0FBaEo7QUFDRDs7QUFDRFYsd0JBQWtCVyxlQUFsQixHQVRrQyxDQVdsQzs7QUFDQSxVQUFJekMsT0FBTzNDLElBQVAsQ0FBWTtBQUFFZ0Qsa0JBQVV4QixJQUFJd0I7QUFBaEIsT0FBWixFQUF3Q2pELEtBQXhDLEtBQWtELENBQXRELEVBQXlEO0FBQ3ZEO0FBQ0F3RSxpQkFBU1MsSUFBVCxDQUFlLDREQUEyRHhELElBQUlYLEdBQUksZUFBY1csSUFBSXdCLFFBQVMsR0FBN0c7QUFDRDtBQUNGLEtBaEJEO0FBa0JBMkIsT0FBR1UsYUFBSDtBQUNBLFdBQU9kLFFBQVA7QUFDRDtBQUVEOzs7OztBQUdBdkQsWUFBVTtBQUFFO0FBQ1YsUUFBSXZDLE9BQU93QyxRQUFYLEVBQXFCLENBQUU7QUFDdEI7QUFDRjs7QUF6RzhDO0FBNEdqRDs7Ozs7O0FBSU8sTUFBTXlCLFlBQVksSUFBSUcsbUJBQUosRUFBbEIsQzs7Ozs7Ozs7Ozs7QUMzSFBuRSxPQUFPK0QsTUFBUCxDQUFjO0FBQUM2Qyx1QkFBb0IsTUFBSUEsbUJBQXpCO0FBQTZDQyxlQUFZLE1BQUlBO0FBQTdELENBQWQ7QUFBeUYsSUFBSTlHLE1BQUo7QUFBV0MsT0FBT0MsS0FBUCxDQUFhQyxRQUFRLGVBQVIsQ0FBYixFQUFzQztBQUFDSCxTQUFPSSxDQUFQLEVBQVM7QUFBQ0osYUFBT0ksQ0FBUDtBQUFTOztBQUFwQixDQUF0QyxFQUE0RCxDQUE1RDtBQUErRCxJQUFJMkcsZUFBSjtBQUFvQjlHLE9BQU9DLEtBQVAsQ0FBYUMsUUFBUSw2QkFBUixDQUFiLEVBQW9EO0FBQUM0RyxrQkFBZ0IzRyxDQUFoQixFQUFrQjtBQUFDMkcsc0JBQWdCM0csQ0FBaEI7QUFBa0I7O0FBQXRDLENBQXBELEVBQTRGLENBQTVGO0FBQStGLElBQUlFLFlBQUo7QUFBaUJMLE9BQU9DLEtBQVAsQ0FBYUMsUUFBUSxjQUFSLENBQWIsRUFBcUM7QUFBQ0ksVUFBUUgsQ0FBUixFQUFVO0FBQUNFLG1CQUFhRixDQUFiO0FBQWU7O0FBQTNCLENBQXJDLEVBQWtFLENBQWxFO0FBQXFFLElBQUk2RCxTQUFKO0FBQWNoRSxPQUFPQyxLQUFQLENBQWFDLFFBQVEsMEJBQVIsQ0FBYixFQUFpRDtBQUFDOEQsWUFBVTdELENBQVYsRUFBWTtBQUFDNkQsZ0JBQVU3RCxDQUFWO0FBQVk7O0FBQTFCLENBQWpELEVBQTZFLENBQTdFO0FBS25YLE1BQU15RyxzQkFBc0IsSUFBSUUsZUFBSixDQUFvQjtBQUNyRDVFLFFBQU0sK0JBRCtDO0FBRXJEa0UsWUFBVSxJQUFJL0YsWUFBSixHQUFtQjBHLFNBQW5CLENBQTZCO0FBQUVDLFdBQU87QUFBVCxHQUE3QixDQUYyQzs7QUFHckRDLFFBQU07QUFDSixXQUFPakQsVUFBVTFDLElBQVYsQ0FBZSxFQUFmLEVBQW1CRCxLQUFuQixFQUFQO0FBQ0Q7O0FBTG9ELENBQXBCLENBQTVCO0FBUUEsTUFBTXdGLGNBQWMsSUFBSUMsZUFBSixDQUFvQjtBQUM3QzVFLFFBQU0sdUJBRHVDO0FBRTdDa0UsWUFBVSxJQUFJL0YsWUFBSixDQUFpQjtBQUN6QmlFLGNBQVU7QUFBRUYsWUFBTUc7QUFBUixLQURlO0FBRXpCQyxZQUFRO0FBQUVKLFlBQU1LO0FBQVI7QUFGaUIsR0FBakIsRUFHUHNDLFNBSE8sQ0FHRztBQUFFQyxXQUFPO0FBQVQsR0FISCxDQUZtQzs7QUFNN0NDLE1BQUk7QUFBRTNDLFlBQUY7QUFBWUU7QUFBWixHQUFKLEVBQTBCO0FBQ3hCLFFBQUksQ0FBQyxLQUFLMEMsWUFBVixFQUF3QjtBQUN0QixZQUFNQyxXQUFXbkQsVUFBVWhDLE9BQVYsQ0FBa0I7QUFBRXNDLGdCQUFGO0FBQVlFO0FBQVosT0FBbEIsRUFBd0MsRUFBeEMsQ0FBakIsQ0FEc0IsQ0FFdEI7O0FBQ0EsVUFBSSxDQUFDMkMsUUFBTCxFQUFlLE1BQU0sSUFBSXBILE9BQU9jLEtBQVgsQ0FBaUIsOEJBQWpCLEVBQWtELHdDQUF1Q3lELFFBQVMsYUFBWUUsTUFBTyxFQUFySCxDQUFOO0FBQ2YsYUFBTzJDLFFBQVA7QUFDRDs7QUFDRCxXQUFPLElBQVA7QUFDRDs7QUFkNEMsQ0FBcEIsQ0FBcEIsQzs7Ozs7Ozs7Ozs7QUNiUG5ILE9BQU9DLEtBQVAsQ0FBYUMsUUFBUSwwQkFBUixDQUFiO0FBQWtERixPQUFPQyxLQUFQLENBQWFDLFFBQVEsaUNBQVIsQ0FBYixFOzs7Ozs7Ozs7OztBQ0FsREYsT0FBTytELE1BQVAsQ0FBYztBQUFDRSxVQUFPLE1BQUlBO0FBQVosQ0FBZDtBQUFtQyxJQUFJbEUsTUFBSjtBQUFXQyxPQUFPQyxLQUFQLENBQWFDLFFBQVEsZUFBUixDQUFiLEVBQXNDO0FBQUNILFNBQU9JLENBQVAsRUFBUztBQUFDSixhQUFPSSxDQUFQO0FBQVM7O0FBQXBCLENBQXRDLEVBQTRELENBQTVEO0FBQStELElBQUlDLEtBQUo7QUFBVUosT0FBT0MsS0FBUCxDQUFhQyxRQUFRLGNBQVIsQ0FBYixFQUFxQztBQUFDRSxRQUFNRCxDQUFOLEVBQVE7QUFBQ0MsWUFBTUQsQ0FBTjtBQUFROztBQUFsQixDQUFyQyxFQUF5RCxDQUF6RDtBQUE0RCxJQUFJaUgsS0FBSixFQUFVQyxLQUFWO0FBQWdCckgsT0FBT0MsS0FBUCxDQUFhQyxRQUFRLGNBQVIsQ0FBYixFQUFxQztBQUFDa0gsUUFBTWpILENBQU4sRUFBUTtBQUFDaUgsWUFBTWpILENBQU47QUFBUSxHQUFsQjs7QUFBbUJrSCxRQUFNbEgsQ0FBTixFQUFRO0FBQUNrSCxZQUFNbEgsQ0FBTjtBQUFROztBQUFwQyxDQUFyQyxFQUEyRSxDQUEzRTtBQUE4RSxJQUFJRSxZQUFKO0FBQWlCTCxPQUFPQyxLQUFQLENBQWFDLFFBQVEsY0FBUixDQUFiLEVBQXFDO0FBQUNJLFVBQVFILENBQVIsRUFBVTtBQUFDRSxtQkFBYUYsQ0FBYjtBQUFlOztBQUEzQixDQUFyQyxFQUFrRSxDQUFsRTtBQUFxRSxJQUFJTSxjQUFKO0FBQW1CVCxPQUFPQyxLQUFQLENBQWFDLFFBQVEsMkJBQVIsQ0FBYixFQUFrRDtBQUFDSSxVQUFRSCxDQUFSLEVBQVU7QUFBQ00scUJBQWVOLENBQWY7QUFBaUI7O0FBQTdCLENBQWxELEVBQWlGLENBQWpGO0FBQW9GLElBQUkrRCxnQkFBSjtBQUFxQmxFLE9BQU9DLEtBQVAsQ0FBYUMsUUFBUSxxQkFBUixDQUFiLEVBQTRDO0FBQUNnRSxtQkFBaUIvRCxDQUFqQixFQUFtQjtBQUFDK0QsdUJBQWlCL0QsQ0FBakI7QUFBbUI7O0FBQXhDLENBQTVDLEVBQXNGLENBQXRGOztBQU9uZTs7OztBQUlBLE1BQU1tSCxnQkFBTixTQUErQjdHLGNBQS9CLENBQThDO0FBRTVDOzs7QUFHQUMsZ0JBQWM7QUFDWixVQUFNLFFBQU4sRUFBZ0IsSUFBSUwsWUFBSixDQUFpQjtBQUMvQjhCLFdBQUs7QUFBRWlDLGNBQU1oRSxNQUFNaUU7QUFBZCxPQUQwQjtBQUUvQkMsZ0JBQVVDLE1BRnFCO0FBRy9CSCxZQUFNSyxNQUh5QjtBQUkvQjhDLG1CQUFhOUMsTUFKa0I7QUFLL0IrQyx1QkFBaUIsQ0FBQy9DLE1BQUQsQ0FMYztBQU0vQmdELHNCQUFnQixDQUFDaEQsTUFBRCxDQU5lO0FBTy9CaUQsdUNBQWlDbkQsTUFQRjtBQVEvQm9ELHFDQUErQnBELE1BUkE7QUFTL0JxRCxvQkFBYztBQUFFeEQsY0FBTXlELEtBQVI7QUFBZTVDLGtCQUFVO0FBQXpCLE9BVGlCO0FBVS9CLHdCQUFrQlY7QUFWYSxLQUFqQixDQUFoQjtBQWFBLFNBQUt1RCxVQUFMLEdBQWtCLENBQUMsZUFBRCxFQUFrQixpQkFBbEIsRUFBcUMsYUFBckMsRUFBb0QsZUFBcEQsRUFBcUUsS0FBckUsRUFBNEUsT0FBNUUsQ0FBbEI7QUFDQSxTQUFLQyxrQkFBTCxHQUEwQixlQUExQjtBQUNBLFNBQUtDLG9CQUFMLEdBQTRCLGlCQUE1QjtBQUNBLFNBQUtDLGdCQUFMLEdBQXdCLGFBQXhCO0FBQ0EsU0FBS0Msa0JBQUwsR0FBMEIsZUFBMUI7QUFDQSxTQUFLQyxRQUFMLEdBQWdCLEtBQWhCO0FBQ0EsU0FBS0MsVUFBTCxHQUFrQixPQUFsQjtBQUVBLFNBQUtqRCxnQkFBTCxHQUF3QjtBQUN0QmtELGtCQUFZLFlBRFU7QUFFdEJDLHlCQUFtQjtBQUZHLEtBQXhCOztBQUlBLFFBQUl2SSxPQUFPc0YsTUFBWCxFQUFtQjtBQUNqQixXQUFLckUsV0FBTCxDQUFpQnNFLGFBQWpCLEdBQWlDQyxXQUFqQyxDQUE2QztBQUFFbUMseUNBQWlDO0FBQW5DLE9BQTdDLEVBQXFGO0FBQUVsQyxvQkFBWTtBQUFkLE9BQXJGO0FBQ0Q7QUFDRjtBQUVEOzs7Ozs7Ozs7OztBQVNBckMsU0FBTztBQUFFbUIsWUFBRjtBQUFZRixRQUFaO0FBQWtCbUQsZUFBbEI7QUFBK0JDLG1CQUEvQjtBQUFnREMsa0JBQWhEO0FBQWdFQyxtQ0FBaEU7QUFDTEMsaUNBREs7QUFDMEJDO0FBRDFCLEdBQVAsRUFDaUQ7QUFDL0MsVUFBTWxGLFFBQVEsS0FBSzFCLFdBQUwsQ0FBaUI0RSxNQUFqQixDQUF3QjtBQUFFdEIsY0FBRjtBQUFZRixVQUFaO0FBQWtCbUQsaUJBQWxCO0FBQStCQyxxQkFBL0I7QUFBZ0RDLG9CQUFoRDtBQUNwQ0MscUNBRG9DO0FBQ0hDLG1DQURHO0FBQzRCQztBQUQ1QixLQUF4QixDQUFkOztBQUVBLFdBQU9sRixLQUFQO0FBQ0Q7QUFFRDs7Ozs7OztBQUtBRCxVQUFRQyxLQUFSLEVBQWU7QUFDYjtBQUNBLFVBQU1JLE1BQU0sS0FBS0MsT0FBTCxDQUFhTCxLQUFiLENBQVo7QUFDQSxVQUFNNEIsV0FBV3hCLElBQUl3QixRQUFyQjtBQUNBLFVBQU1GLE9BQU90QixJQUFJc0IsSUFBakI7QUFDQSxVQUFNbUQsY0FBY3pFLElBQUl5RSxXQUF4QjtBQUNBLFVBQU1DLGtCQUFrQjFFLElBQUkwRSxlQUE1QjtBQUNBLFVBQU1DLGlCQUFpQjNFLElBQUkyRSxjQUEzQjtBQUNBLFVBQU1DLGtDQUFrQzVFLElBQUk0RSwrQkFBNUM7QUFDQSxVQUFNQyxnQ0FBZ0M3RSxJQUFJNkUsNkJBQTFDO0FBQ0EsVUFBTUMsZUFBZTlFLElBQUk4RSxZQUF6QjtBQUVBLFdBQU87QUFBRXRELGNBQUY7QUFBWUYsVUFBWjtBQUFrQm1ELGlCQUFsQjtBQUErQkMscUJBQS9CO0FBQWdEQyxvQkFBaEQ7QUFDTEMscUNBREs7QUFDNEJDLG1DQUQ1QjtBQUMyREM7QUFEM0QsS0FBUDtBQUVBO0FBQ0Q7O0FBRUQ1RSxtQkFBaUI7QUFDZixVQUFNNkMsV0FBVyxFQUFqQjtBQUNBLFVBQU1DLGFBQWEsS0FBS3pFLEtBQUwsRUFBbkI7QUFDQSxVQUFNMEUsb0JBQW9CLEtBQUszRSxTQUFMLEdBQWlCNEUsWUFBakIsQ0FBOEIsaUJBQTlCLENBQTFCO0FBQ0EsVUFBTUMsS0FBSy9CLGlCQUFpQjRCLFVBQWpCLEVBQTZCLElBQTdCLEVBQW9DLFlBQVcsS0FBS2hGLGVBQWdCLGVBQXBFLENBQVg7QUFFQSxTQUFLUSxJQUFMLEdBQVlxQyxPQUFaLENBQW9CLENBQUNiLEdBQUQsRUFBTW9ELEtBQU4sS0FBZ0I7QUFDbENELFNBQUdFLFNBQUgsQ0FBYUQsS0FBYixFQURrQyxDQUNiO0FBRXJCOztBQUNBSCx3QkFBa0JLLFFBQWxCLENBQTJCdEQsR0FBM0I7O0FBQ0EsVUFBSSxDQUFDaUQsa0JBQWtCTSxPQUFsQixFQUFMLEVBQWtDO0FBQ2hDO0FBQ0FSLGlCQUFTUyxJQUFULENBQWUsNkNBQTRDeEQsSUFBSVgsR0FBSSxtQkFBa0JvRSxLQUFLQyxTQUFMLENBQWVULGtCQUFrQlUsV0FBbEIsRUFBZixFQUFnRCxJQUFoRCxFQUFzRCxDQUF0RCxDQUF5RCxHQUE5STtBQUNEOztBQUNEVix3QkFBa0JXLGVBQWxCO0FBQ0QsS0FWRDtBQVlBVCxPQUFHVSxhQUFIO0FBQ0EsV0FBT2QsUUFBUDtBQUNEO0FBR0Q7Ozs7O0FBR0F2RCxZQUFVO0FBQ1IsUUFBSXZDLE9BQU93QyxRQUFYLEVBQXFCO0FBQ25CLFlBQU1nRyxPQUFPLElBQWI7QUFFQXhJLGFBQU91QyxPQUFQLENBQWUsS0FBSzZDLGdCQUFMLENBQXNCa0QsVUFBckMsRUFBaUQsVUFBVTtBQUFFRyxpQkFBRjtBQUFhQztBQUFiLE9BQVYsRUFBa0M7QUFDakZyQixjQUFNb0IsU0FBTixFQUFpQm5CLE1BQU1xQixLQUFOLENBQVluRSxNQUFaLENBQWpCO0FBQ0E2QyxjQUFNcUIsT0FBTixFQUFlcEIsTUFBTXFCLEtBQU4sQ0FBWW5FLE1BQVosQ0FBZjtBQUVBLGNBQU16QyxXQUFXeUcsS0FBS0ksaUJBQUwsR0FBeUJDLFNBQXpCLENBQW1DO0FBQUVKLG1CQUFGO0FBQWFDO0FBQWIsU0FBbkMsQ0FBakI7QUFDQSxlQUFPRixLQUFLakgsSUFBTCxDQUFVUSxRQUFWLENBQVA7QUFDRCxPQU5EO0FBUUEvQixhQUFPdUMsT0FBUCxDQUFlLEtBQUs2QyxnQkFBTCxDQUFzQm1ELGlCQUFyQyxFQUF3RCxVQUFVO0FBQUVPLGlCQUFGO0FBQWFDO0FBQWIsT0FBVixFQUF1QztBQUM3RjFCLGNBQU15QixTQUFOLEVBQWlCdEUsTUFBakI7QUFDQSxjQUFNM0MsUUFBUWtILGVBQWU7QUFBRTFFLGdCQUFNO0FBQUUyRSxpQkFBSztBQUFQO0FBQVIsU0FBZixHQUE0QyxFQUExRDtBQUNBLGNBQU1DLFNBQVNULEtBQUtqSCxJQUFMLENBQVVNLEtBQVYsRUFBaUI7QUFBRXFILGdCQUFNO0FBQUV2Qiw2Q0FBaUMsQ0FBQztBQUFwQyxXQUFSO0FBQWlEd0IsaUJBQU9MO0FBQXhELFNBQWpCLENBQWY7QUFDQSxlQUFPRyxNQUFQO0FBQ0QsT0FMRDtBQU1EO0FBQ0Y7O0FBRURMLHNCQUFvQjtBQUFFO0FBQ3BCLFdBQU87QUFDTEMsZ0JBQVU7QUFBRUosaUJBQUY7QUFBYUM7QUFBYixPQUFWLEVBQWtDO0FBQ2hDckIsY0FBTW9CLFNBQU4sRUFBaUJuQixNQUFNcUIsS0FBTixDQUFZbkUsTUFBWixDQUFqQjtBQUNBNkMsY0FBTXFCLE9BQU4sRUFBZXBCLE1BQU1xQixLQUFOLENBQVluRSxNQUFaLENBQWY7QUFFQSxjQUFNekMsV0FBVyxFQUFqQjtBQUNBLFlBQUkwRyxTQUFKLEVBQWUxRyxTQUFTNEYsK0JBQVQsR0FBMkM7QUFBRTdGLGdCQUFNMkc7QUFBUixTQUEzQztBQUNmLFlBQUlDLE9BQUosRUFBYTNHLFNBQVM2Riw2QkFBVCxHQUF5QztBQUFFd0IsZ0JBQU1WO0FBQVIsU0FBekM7QUFFYixlQUFPM0csUUFBUDtBQUNEOztBQVZJLEtBQVA7QUFZRDs7QUF0STJDO0FBeUk5Qzs7Ozs7O0FBSU8sTUFBTW1DLFNBQVMsSUFBSXFELGdCQUFKLEVBQWYsQzs7Ozs7Ozs7Ozs7QUN4SlB0SCxPQUFPK0QsTUFBUCxDQUFjO0FBQUNxRixvQkFBaUIsTUFBSUEsZ0JBQXRCO0FBQXVDQyxrQkFBZSxNQUFJQSxjQUExRDtBQUF5RUMscUJBQWtCLE1BQUlBLGlCQUEvRjtBQUFpSEMsc0JBQW1CLE1BQUlBO0FBQXhJLENBQWQ7QUFBMkssSUFBSXpDLGVBQUo7QUFBb0I5RyxPQUFPQyxLQUFQLENBQWFDLFFBQVEsNkJBQVIsQ0FBYixFQUFvRDtBQUFDNEcsa0JBQWdCM0csQ0FBaEIsRUFBa0I7QUFBQzJHLHNCQUFnQjNHLENBQWhCO0FBQWtCOztBQUF0QyxDQUFwRCxFQUE0RixDQUE1RjtBQUErRixJQUFJRSxZQUFKO0FBQWlCTCxPQUFPQyxLQUFQLENBQWFDLFFBQVEsY0FBUixDQUFiLEVBQXFDO0FBQUNJLFVBQVFILENBQVIsRUFBVTtBQUFDRSxtQkFBYUYsQ0FBYjtBQUFlOztBQUEzQixDQUFyQyxFQUFrRSxDQUFsRTtBQUFxRSxJQUFJcUosUUFBSjtBQUFheEosT0FBT0MsS0FBUCxDQUFhQyxRQUFRLFlBQVIsQ0FBYixFQUFtQztBQUFDc0osV0FBU3JKLENBQVQsRUFBVztBQUFDcUosZUFBU3JKLENBQVQ7QUFBVzs7QUFBeEIsQ0FBbkMsRUFBNkQsQ0FBN0Q7QUFBZ0UsSUFBSThELE1BQUo7QUFBV2pFLE9BQU9DLEtBQVAsQ0FBYUMsUUFBUSx1QkFBUixDQUFiLEVBQThDO0FBQUMrRCxTQUFPOUQsQ0FBUCxFQUFTO0FBQUM4RCxhQUFPOUQsQ0FBUDtBQUFTOztBQUFwQixDQUE5QyxFQUFvRSxDQUFwRTtBQUF1RSxJQUFJc0osY0FBSjtBQUFtQnpKLE9BQU9DLEtBQVAsQ0FBYUMsUUFBUSx3QkFBUixDQUFiLEVBQStDO0FBQUN1SixpQkFBZXRKLENBQWYsRUFBaUI7QUFBQ3NKLHFCQUFldEosQ0FBZjtBQUFpQjs7QUFBcEMsQ0FBL0MsRUFBcUYsQ0FBckY7QUFPL2hCLE1BQU1pSixtQkFBbUIsSUFBSXRDLGVBQUosQ0FBb0I7QUFDbEQ1RSxRQUFNLHlCQUQ0QztBQUVsRGtFLFlBQVUsSUFBSS9GLFlBQUosR0FBbUIwRyxTQUFuQixDQUE2QjtBQUFFQyxXQUFPO0FBQVQsR0FBN0IsQ0FGd0M7O0FBR2xEQyxRQUFNO0FBQ0osV0FBT2hELE9BQU8zQyxJQUFQLENBQVksRUFBWixFQUFnQkQsS0FBaEIsRUFBUDtBQUNEOztBQUxpRCxDQUFwQixDQUF6QjtBQVFBLE1BQU1nSSxpQkFBaUIsSUFBSXZDLGVBQUosQ0FBb0I7QUFDaEQ1RSxRQUFNLHVCQUQwQztBQUVoRGtFLFlBQVUsSUFBSS9GLFlBQUosQ0FBaUI7QUFDekJxSixjQUFVO0FBQUV0RixZQUFNSztBQUFSLEtBRGU7QUFFekIrRCxlQUFXO0FBQUVwRSxZQUFNRztBQUFSLEtBRmM7QUFHekJrRSxhQUFTO0FBQUVyRSxZQUFNRyxNQUFSO0FBQWdCVSxnQkFBVTtBQUExQjtBQUhnQixHQUFqQixFQUlQOEIsU0FKTyxDQUlHO0FBQUVDLFdBQU87QUFBVCxHQUpILENBRnNDOztBQU9oREMsTUFBSTtBQUFFeUMsWUFBRjtBQUFZbEIsYUFBWjtBQUF1QkM7QUFBdkIsR0FBSixFQUFzQztBQUNwQztBQUNBLFVBQU0zRyxXQUFXbUMsT0FBTzBFLGlCQUFQLEdBQTJCQyxTQUEzQixDQUFxQztBQUFFSixlQUFGO0FBQWFDO0FBQWIsS0FBckMsQ0FBakI7QUFDQSxVQUFNa0IsZ0JBQWdCMUYsT0FBTzNDLElBQVAsQ0FBWVEsUUFBWixDQUF0QjtBQUVBLFVBQU04SCxnQkFBZ0IsSUFBSUMsR0FBSixFQUF0QjtBQUNBRixrQkFBY2hHLE9BQWQsQ0FBc0JtRyxTQUFTO0FBQzdCLFlBQU1DLGNBQWNOLGVBQWVLLE1BQU1wQywrQkFBckIsRUFBc0RnQyxRQUF0RCxDQUFwQjs7QUFDQSxVQUFJRSxjQUFjSSxHQUFkLENBQWtCRCxXQUFsQixDQUFKLEVBQW9DO0FBQ2xDSCxzQkFBY0ssR0FBZCxDQUFrQkYsV0FBbEIsRUFBK0JILGNBQWNNLEdBQWQsQ0FBa0JILFdBQWxCLElBQWlDLENBQWhFO0FBQ0QsT0FGRCxNQUVPO0FBQ0xILHNCQUFjSyxHQUFkLENBQWtCRixXQUFsQixFQUErQixDQUEvQjtBQUNEO0FBQ0YsS0FQRDtBQVNBLFdBQU9QLFNBQVNJLGFBQVQsQ0FBUDtBQUNEOztBQXZCK0MsQ0FBcEIsQ0FBdkI7QUEwQkEsTUFBTU4sb0JBQW9CLElBQUl4QyxlQUFKLENBQW9CO0FBQ25ENUUsUUFBTSwwQkFENkM7QUFFbkRrRSxZQUFVLElBQUkvRixZQUFKLENBQWlCO0FBQ3pCaUUsY0FBVTtBQUFFRixZQUFNRztBQUFSO0FBRGUsR0FBakIsRUFFUHdDLFNBRk8sQ0FFRztBQUFFQyxXQUFPO0FBQVQsR0FGSCxDQUZ5Qzs7QUFLbkRDLE1BQUk7QUFBRTNDO0FBQUYsR0FBSixFQUFrQjtBQUNoQixVQUFNcUYsZ0JBQWdCMUYsT0FBT2pDLE9BQVAsQ0FBZTtBQUFFc0M7QUFBRixLQUFmLEVBQTZCLEVBQTdCLENBQXRCO0FBQ0EsV0FBT3FGLGFBQVA7QUFDRDs7QUFSa0QsQ0FBcEIsQ0FBMUI7QUFXQSxNQUFNSixxQkFBcUIsSUFBSXpDLGVBQUosQ0FBb0I7QUFDcEQ1RSxRQUFNLDJCQUQ4QztBQUVwRGtFLFlBQVUsSUFBSS9GLFlBQUosQ0FBaUIsRUFBakIsRUFBcUIwRyxTQUFyQixDQUErQjtBQUFFQyxXQUFPO0FBQVQsR0FBL0IsQ0FGMEM7O0FBR3BEQyxRQUFNO0FBQ0osVUFBTWtELGtCQUFrQmxHLE9BQU9qQyxPQUFQLENBQWUsRUFBZixFQUFtQjtBQUFFaUgsWUFBTTtBQUFFdkIseUNBQWlDLENBQUM7QUFBcEM7QUFBUixLQUFuQixDQUF4QjtBQUNBLFdBQU95QyxlQUFQO0FBQ0Q7O0FBTm1ELENBQXBCLENBQTNCLEM7Ozs7Ozs7Ozs7O0FDcERQbkssT0FBT0MsS0FBUCxDQUFhQyxRQUFRLHVCQUFSLENBQWI7QUFBK0NGLE9BQU9DLEtBQVAsQ0FBYUMsUUFBUSw4QkFBUixDQUFiLEU7Ozs7Ozs7Ozs7O0FDQS9DRixPQUFPK0QsTUFBUCxDQUFjO0FBQUNxRyxZQUFTLE1BQUlBO0FBQWQsQ0FBZDtBQUF1QyxJQUFJckssTUFBSjtBQUFXQyxPQUFPQyxLQUFQLENBQWFDLFFBQVEsZUFBUixDQUFiLEVBQXNDO0FBQUNILFNBQU9JLENBQVAsRUFBUztBQUFDSixhQUFPSSxDQUFQO0FBQVM7O0FBQXBCLENBQXRDLEVBQTRELENBQTVEO0FBQStELElBQUlDLEtBQUo7QUFBVUosT0FBT0MsS0FBUCxDQUFhQyxRQUFRLGNBQVIsQ0FBYixFQUFxQztBQUFDRSxRQUFNRCxDQUFOLEVBQVE7QUFBQ0MsWUFBTUQsQ0FBTjtBQUFROztBQUFsQixDQUFyQyxFQUF5RCxDQUF6RDtBQUE0RCxJQUFJRSxZQUFKO0FBQWlCTCxPQUFPQyxLQUFQLENBQWFDLFFBQVEsY0FBUixDQUFiLEVBQXFDO0FBQUNJLFVBQVFILENBQVIsRUFBVTtBQUFDRSxtQkFBYUYsQ0FBYjtBQUFlOztBQUEzQixDQUFyQyxFQUFrRSxDQUFsRTtBQUFxRSxJQUFJTSxjQUFKO0FBQW1CVCxPQUFPQyxLQUFQLENBQWFDLFFBQVEsMkJBQVIsQ0FBYixFQUFrRDtBQUFDSSxVQUFRSCxDQUFSLEVBQVU7QUFBQ00scUJBQWVOLENBQWY7QUFBaUI7O0FBQTdCLENBQWxELEVBQWlGLENBQWpGO0FBQW9GLElBQUlrSyxPQUFKO0FBQVlySyxPQUFPQyxLQUFQLENBQWFDLFFBQVEsK0JBQVIsQ0FBYixFQUFzRDtBQUFDbUssVUFBUWxLLENBQVIsRUFBVTtBQUFDa0ssY0FBUWxLLENBQVI7QUFBVTs7QUFBdEIsQ0FBdEQsRUFBOEUsQ0FBOUU7QUFBaUYsSUFBSStELGdCQUFKO0FBQXFCbEUsT0FBT0MsS0FBUCxDQUFhQyxRQUFRLHFCQUFSLENBQWIsRUFBNEM7QUFBQ2dFLG1CQUFpQi9ELENBQWpCLEVBQW1CO0FBQUMrRCx1QkFBaUIvRCxDQUFqQjtBQUFtQjs7QUFBeEMsQ0FBNUMsRUFBc0YsQ0FBdEY7O0FBT3RlOzs7O0FBSUEsTUFBTW1LLGtCQUFOLFNBQWlDN0osY0FBakMsQ0FBZ0Q7QUFFOUM7OztBQUdBQyxnQkFBYztBQUNaLFVBQU0sV0FBTixFQUFtQixJQUFJTCxZQUFKLENBQWlCO0FBQ2xDOEIsV0FBSztBQUFFaUMsY0FBTWhFLE1BQU1pRTtBQUFkLE9BRDZCO0FBRWxDa0csZ0JBQVU7QUFBRW5HLGNBQU1oRSxNQUFNaUU7QUFBZCxPQUZ3QjtBQUdsQ21HLFNBQUdqRyxNQUgrQjtBQUlsQ2tHLFlBQU1DO0FBSjRCLEtBQWpCLENBQW5CO0FBT0EsU0FBS3ZGLGdCQUFMLEdBQXdCLEVBQXhCO0FBRUQ7QUFFRDs7Ozs7Ozs7O0FBT0FoQyxTQUFPO0FBQUVvSCxZQUFGO0FBQVlDLEtBQVo7QUFBZUM7QUFBZixHQUFQLEVBQThCO0FBQzVCLFVBQU0vSCxRQUFRLEtBQUsxQixXQUFMLENBQWlCNEUsTUFBakIsQ0FBd0I7QUFBRTJFLGNBQUY7QUFBWUMsT0FBWjtBQUFlQztBQUFmLEtBQXhCLENBQWQ7O0FBQ0EsV0FBTy9ILEtBQVA7QUFDRDtBQUVEOzs7Ozs7O0FBS0FELFVBQVFDLEtBQVIsRUFBZTtBQUNiO0FBQ0EsVUFBTUksTUFBTSxLQUFLQyxPQUFMLENBQWFMLEtBQWIsQ0FBWjtBQUNBLFVBQU02SCxXQUFXekgsSUFBSXlILFFBQXJCO0FBQ0EsVUFBTUMsSUFBSTFILElBQUkwSCxDQUFkO0FBQ0EsVUFBTUMsT0FBTzNILElBQUkySCxJQUFqQjtBQUVBLFdBQU87QUFBRUYsY0FBRjtBQUFZQyxPQUFaO0FBQWVDO0FBQWYsS0FBUDtBQUNBO0FBQ0Q7O0FBRUR6SCxtQkFBaUI7QUFDZixVQUFNNkMsV0FBVyxFQUFqQjtBQUNBLFVBQU1DLGFBQWEsS0FBS3pFLEtBQUwsRUFBbkI7QUFDQSxVQUFNMEUsb0JBQW9CLEtBQUszRSxTQUFMLEdBQWlCNEUsWUFBakIsQ0FBOEIsa0JBQTlCLENBQTFCO0FBQ0EsVUFBTUMsS0FBSy9CLGlCQUFpQjRCLFVBQWpCLEVBQTZCLElBQTdCLEVBQW9DLFlBQVcsS0FBS2hGLGVBQWdCLGVBQXBFLENBQVg7QUFFQSxTQUFLUSxJQUFMLEdBQVlxQyxPQUFaLENBQW9CLENBQUNiLEdBQUQsRUFBTW9ELEtBQU4sS0FBZ0I7QUFDbENELFNBQUdFLFNBQUgsQ0FBYUQsS0FBYixFQURrQyxDQUNiO0FBRXJCOztBQUNBSCx3QkFBa0JLLFFBQWxCLENBQTJCdEQsR0FBM0I7O0FBQ0EsVUFBSSxDQUFDaUQsa0JBQWtCTSxPQUFsQixFQUFMLEVBQWtDO0FBQ2hDO0FBQ0FSLGlCQUFTUyxJQUFULENBQWUsZ0RBQStDeEQsSUFBSVgsR0FBSSxtQkFBa0JvRSxLQUFLQyxTQUFMLENBQWVULGtCQUFrQlUsV0FBbEIsRUFBZixFQUFnRCxJQUFoRCxFQUFzRCxDQUF0RCxDQUF5RCxHQUFqSjtBQUNEOztBQUNEVix3QkFBa0JXLGVBQWxCLEdBVGtDLENBV2xDOztBQUNBLFlBQU1pRSxTQUFTTixRQUFRckksT0FBUixDQUFnQjtBQUFFRyxhQUFLVyxJQUFJeUg7QUFBWCxPQUFoQixDQUFmOztBQUNBLFVBQUksQ0FBQ0ksTUFBTCxFQUFhO0FBQ1g5RSxpQkFBU1MsSUFBVCxDQUFlLGdFQUErRHhELElBQUlYLEdBQUksRUFBdEY7QUFDRDtBQUNGLEtBaEJEO0FBa0JBOEQsT0FBR1UsYUFBSDtBQUNBLFdBQU9kLFFBQVA7QUFDRDtBQUVEOzs7OztBQUdBdkQsWUFBVTtBQUFFO0FBQ1YsUUFBSXZDLE9BQU93QyxRQUFYLEVBQXFCLENBQUU7QUFDdEI7QUFDRjs7QUEvRTZDO0FBa0ZoRDs7Ozs7O0FBSU8sTUFBTTZILFdBQVcsSUFBSUUsa0JBQUosRUFBakIsQzs7Ozs7Ozs7Ozs7QUNqR1B0SyxPQUFPQyxLQUFQLENBQWFDLFFBQVEseUJBQVIsQ0FBYixFOzs7Ozs7Ozs7OztBQ0FBRixPQUFPK0QsTUFBUCxDQUFjO0FBQUNzRyxXQUFRLE1BQUlBO0FBQWIsQ0FBZDtBQUFxQyxJQUFJdEssTUFBSjtBQUFXQyxPQUFPQyxLQUFQLENBQWFDLFFBQVEsZUFBUixDQUFiLEVBQXNDO0FBQUNILFNBQU9JLENBQVAsRUFBUztBQUFDSixhQUFPSSxDQUFQO0FBQVM7O0FBQXBCLENBQXRDLEVBQTRELENBQTVEO0FBQStELElBQUlDLEtBQUo7QUFBVUosT0FBT0MsS0FBUCxDQUFhQyxRQUFRLGNBQVIsQ0FBYixFQUFxQztBQUFDRSxRQUFNRCxDQUFOLEVBQVE7QUFBQ0MsWUFBTUQsQ0FBTjtBQUFROztBQUFsQixDQUFyQyxFQUF5RCxDQUF6RDtBQUE0RCxJQUFJRSxZQUFKO0FBQWlCTCxPQUFPQyxLQUFQLENBQWFDLFFBQVEsY0FBUixDQUFiLEVBQXFDO0FBQUNJLFVBQVFILENBQVIsRUFBVTtBQUFDRSxtQkFBYUYsQ0FBYjtBQUFlOztBQUEzQixDQUFyQyxFQUFrRSxDQUFsRTtBQUFxRSxJQUFJTSxjQUFKO0FBQW1CVCxPQUFPQyxLQUFQLENBQWFDLFFBQVEsMkJBQVIsQ0FBYixFQUFrRDtBQUFDSSxVQUFRSCxDQUFSLEVBQVU7QUFBQ00scUJBQWVOLENBQWY7QUFBaUI7O0FBQTdCLENBQWxELEVBQWlGLENBQWpGO0FBQW9GLElBQUk4RCxNQUFKO0FBQVdqRSxPQUFPQyxLQUFQLENBQWFDLFFBQVEsNEJBQVIsQ0FBYixFQUFtRDtBQUFDK0QsU0FBTzlELENBQVAsRUFBUztBQUFDOEQsYUFBTzlELENBQVA7QUFBUzs7QUFBcEIsQ0FBbkQsRUFBeUUsQ0FBekU7QUFBNEUsSUFBSTZELFNBQUo7QUFBY2hFLE9BQU9DLEtBQVAsQ0FBYUMsUUFBUSxtQ0FBUixDQUFiLEVBQTBEO0FBQUM4RCxZQUFVN0QsQ0FBVixFQUFZO0FBQUM2RCxnQkFBVTdELENBQVY7QUFBWTs7QUFBMUIsQ0FBMUQsRUFBc0YsQ0FBdEY7QUFBeUYsSUFBSStELGdCQUFKO0FBQXFCbEUsT0FBT0MsS0FBUCxDQUFhQyxRQUFRLHFCQUFSLENBQWIsRUFBNEM7QUFBQ2dFLG1CQUFpQi9ELENBQWpCLEVBQW1CO0FBQUMrRCx1QkFBaUIvRCxDQUFqQjtBQUFtQjs7QUFBeEMsQ0FBNUMsRUFBc0YsQ0FBdEY7O0FBUXJrQjs7OztBQUlBLE1BQU15SyxpQkFBTixTQUFnQ25LLGNBQWhDLENBQStDO0FBRTdDOzs7QUFHQUMsZ0JBQWM7QUFDWixVQUFNLFVBQU4sRUFBa0IsSUFBSUwsWUFBSixDQUFpQjtBQUNqQzhCLFdBQUs7QUFBRWlDLGNBQU1oRSxNQUFNaUU7QUFBZCxPQUQ0QjtBQUVqQ3dHLGdCQUFVcEcsTUFGdUI7QUFHakNxRyxjQUFRO0FBQUUxRyxjQUFNRztBQUFSLE9BSHlCO0FBSWpDd0csaUJBQVc7QUFBRTNHLGNBQU1HO0FBQVIsT0FKc0I7QUFLakN5RyxrQkFBWTtBQUFFNUcsY0FBTTZHO0FBQVIsT0FMcUI7QUFNakNDLFdBQUs7QUFBRTlHLGNBQU1LO0FBQVIsT0FONEI7QUFPakMwRyxnQkFBVTtBQUFFL0csY0FBTVk7QUFBUixPQVB1QjtBQVFqQywyQkFBcUI7QUFBRVosY0FBTUc7QUFBUixPQVJZO0FBU2pDLHlCQUFtQjtBQUFFSCxjQUFNSztBQUFSO0FBVGMsS0FBakIsQ0FBbEI7QUFZQSxTQUFLVSxnQkFBTCxHQUF3QixFQUF4QjtBQUVEO0FBRUQ7Ozs7Ozs7Ozs7OztBQVVBaEMsU0FBTztBQUFFMEgsWUFBRjtBQUFZQyxVQUFaO0FBQW9CQyxhQUFwQjtBQUErQkMsY0FBL0I7QUFBMkNFLE9BQTNDO0FBQWdEQztBQUFoRCxHQUFQLEVBQW1FO0FBQ2pFLFVBQU16SSxRQUFRLEtBQUsxQixXQUFMLENBQWlCNEUsTUFBakIsQ0FBd0I7QUFBRWlGLGNBQUY7QUFBWUMsWUFBWjtBQUFvQkMsZUFBcEI7QUFBK0JDLGdCQUEvQjtBQUEyQ0UsU0FBM0M7QUFBZ0RDO0FBQWhELEtBQXhCLENBQWQ7O0FBQ0EsV0FBT3pJLEtBQVA7QUFDRDtBQUVEOzs7Ozs7O0FBS0FELFVBQVFDLEtBQVIsRUFBZTtBQUNiO0FBQ0EsVUFBTUksTUFBTSxLQUFLQyxPQUFMLENBQWFMLEtBQWIsQ0FBWjtBQUNBLFVBQU1tSSxXQUFXL0gsSUFBSStILFFBQXJCO0FBQ0EsVUFBTUMsU0FBU2hJLElBQUlnSSxNQUFuQjtBQUNBLFVBQU1DLFlBQVlqSSxJQUFJaUksU0FBdEI7QUFDQSxVQUFNQyxhQUFhbEksSUFBSWtJLFVBQXZCO0FBQ0EsVUFBTUUsTUFBTXBJLElBQUlvSSxHQUFoQjtBQUNBLFVBQU1DLFdBQVdySSxJQUFJcUksUUFBckI7QUFFQSxXQUFPO0FBQUVOLGNBQUY7QUFBWUMsWUFBWjtBQUFvQkMsZUFBcEI7QUFBK0JDLGdCQUEvQjtBQUEyQ0UsU0FBM0M7QUFBZ0RDO0FBQWhELEtBQVA7QUFDQTtBQUNEOztBQUVEbkksbUJBQWlCO0FBQ2YsVUFBTTZDLFdBQVcsRUFBakI7QUFDQSxVQUFNQyxhQUFhLEtBQUt6RSxLQUFMLEVBQW5CO0FBQ0EsVUFBTTBFLG9CQUFvQixLQUFLM0UsU0FBTCxHQUFpQjRFLFlBQWpCLENBQThCLGtCQUE5QixDQUExQjtBQUNBLFVBQU1DLEtBQUsvQixpQkFBaUI0QixVQUFqQixFQUE2QixJQUE3QixFQUFvQyxZQUFXLEtBQUtoRixlQUFnQixlQUFwRSxDQUFYO0FBRUEsU0FBS1EsSUFBTCxHQUFZcUMsT0FBWixDQUFvQixDQUFDYixHQUFELEVBQU1vRCxLQUFOLEtBQWdCO0FBQ2xDRCxTQUFHRSxTQUFILENBQWFELEtBQWIsRUFEa0MsQ0FDYjtBQUVyQjs7QUFDQUgsd0JBQWtCSyxRQUFsQixDQUEyQnRELEdBQTNCOztBQUNBLFVBQUksQ0FBQ2lELGtCQUFrQk0sT0FBbEIsRUFBTCxFQUFrQztBQUNoQztBQUNBUixpQkFBU1MsSUFBVCxDQUFlLCtDQUE4Q3hELElBQUlYLEdBQUksbUJBQWtCb0UsS0FBS0MsU0FBTCxDQUFlVCxrQkFBa0JVLFdBQWxCLEVBQWYsRUFBZ0QsSUFBaEQsRUFBc0QsQ0FBdEQsQ0FBeUQsR0FBaEo7QUFDRDs7QUFDRFYsd0JBQWtCVyxlQUFsQjtBQUVBLFlBQU1vRCxRQUFRN0YsT0FBT2pDLE9BQVAsQ0FBZTtBQUFFc0Msa0JBQVV4QixJQUFJcUksUUFBSixDQUFhN0c7QUFBekIsT0FBZixDQUFkLENBWGtDLENBWWxDOztBQUNBLFVBQUksQ0FBQ3dGLEtBQUwsRUFBWTtBQUNWakUsaUJBQVNTLElBQVQsQ0FBZSxtRUFBa0V4RCxJQUFJWCxHQUFJLEVBQXpGO0FBQ0QsT0FmaUMsQ0FpQmxDOzs7QUFDQSxZQUFNZ0YsV0FBV25ELFVBQVVoQyxPQUFWLENBQWtCO0FBQUVzQyxrQkFBVXhCLElBQUlxSSxRQUFKLENBQWE3RyxRQUF6QjtBQUFtQ0UsZ0JBQVExQixJQUFJcUksUUFBSixDQUFhM0c7QUFBeEQsT0FBbEIsQ0FBakI7O0FBQ0EsVUFBSSxDQUFDMkMsUUFBTCxFQUFlO0FBQ2I7QUFDQXRCLGlCQUFTUyxJQUFULENBQWUsbUdBQWtHeEQsSUFBSVgsR0FBSSxFQUF6SDtBQUNEO0FBQ0YsS0F2QkQ7QUF5QkE4RCxPQUFHVSxhQUFIO0FBQ0EsV0FBT2QsUUFBUDtBQUNEO0FBRUQ7Ozs7O0FBR0F2RCxZQUFVO0FBQUU7QUFDVixRQUFJdkMsT0FBT3dDLFFBQVgsRUFBcUIsQ0FBRTtBQUN0QjtBQUNGOztBQWpHNEM7QUFvRy9DOzs7Ozs7QUFJTyxNQUFNOEgsVUFBVSxJQUFJTyxpQkFBSixFQUFoQixDOzs7Ozs7Ozs7OztBQ3BIUDVLLE9BQU8rRCxNQUFQLENBQWM7QUFBQ3FILGdCQUFhLE1BQUlBO0FBQWxCLENBQWQ7QUFBK0MsSUFBSXRFLGVBQUo7QUFBb0I5RyxPQUFPQyxLQUFQLENBQWFDLFFBQVEsNkJBQVIsQ0FBYixFQUFvRDtBQUFDNEcsa0JBQWdCM0csQ0FBaEIsRUFBa0I7QUFBQzJHLHNCQUFnQjNHLENBQWhCO0FBQWtCOztBQUF0QyxDQUFwRCxFQUE0RixDQUE1RjtBQUErRixJQUFJRSxZQUFKO0FBQWlCTCxPQUFPQyxLQUFQLENBQWFDLFFBQVEsY0FBUixDQUFiLEVBQXFDO0FBQUNJLFVBQVFILENBQVIsRUFBVTtBQUFDRSxtQkFBYUYsQ0FBYjtBQUFlOztBQUEzQixDQUFyQyxFQUFrRSxDQUFsRTtBQUFxRSxJQUFJa0ssT0FBSjtBQUFZckssT0FBT0MsS0FBUCxDQUFhQyxRQUFRLHFCQUFSLENBQWIsRUFBNEM7QUFBQ21LLFVBQVFsSyxDQUFSLEVBQVU7QUFBQ2tLLGNBQVFsSyxDQUFSO0FBQVU7O0FBQXRCLENBQTVDLEVBQW9FLENBQXBFO0FBQXVFLElBQUlpSyxRQUFKO0FBQWFwSyxPQUFPQyxLQUFQLENBQWFDLFFBQVEsaUNBQVIsQ0FBYixFQUF3RDtBQUFDa0ssV0FBU2pLLENBQVQsRUFBVztBQUFDaUssZUFBU2pLLENBQVQ7QUFBVzs7QUFBeEIsQ0FBeEQsRUFBa0YsQ0FBbEY7QUFLalYsTUFBTWlMLGVBQWUsSUFBSXRFLGVBQUosQ0FBb0I7QUFDOUM1RSxRQUFNLHNCQUR3QztBQUU5Q2tFLFlBQVUsSUFBSS9GLFlBQUosQ0FBaUI7QUFDekJ3SyxjQUFVO0FBQUV6RyxZQUFNSztBQUFSO0FBRGUsR0FBakIsRUFFUHNDLFNBRk8sQ0FFRztBQUFFQyxXQUFPO0FBQVQsR0FGSCxDQUZvQzs7QUFLOUNDLE1BQUk7QUFBRTREO0FBQUYsR0FBSixFQUFrQjtBQUNoQixRQUFJLENBQUMsS0FBSzNELFlBQVYsRUFBd0I7QUFDdEI7QUFDQSxZQUFNbUUsT0FBT2hCLFFBQVFySSxPQUFSLENBQWdCO0FBQUU2STtBQUFGLE9BQWhCLENBQWI7QUFDQSxZQUFNUyxTQUFTbEIsU0FBUzlJLElBQVQsQ0FBYztBQUFFaUosa0JBQVVjLEtBQUtsSjtBQUFqQixPQUFkLEVBQXNDO0FBQUU4RyxjQUFNO0FBQUV1QixhQUFHO0FBQUw7QUFBUixPQUF0QyxFQUEwRC9HLEtBQTFELEVBQWYsQ0FIc0IsQ0FLdEI7QUFDQTs7QUFDQSxZQUFNOEgsY0FBYyxFQUFwQixDQVBzQixDQU9FOztBQUN4QixVQUFJQyxZQUFZLENBQWhCO0FBQ0FGLGFBQU8zSCxPQUFQLENBQWU4SCxTQUFTO0FBQ3RCLGNBQU1DLEtBQUssSUFBSWhCLFVBQUosQ0FBZWUsTUFBTWhCLElBQXJCLENBQVg7QUFDQSxjQUFNa0IsTUFBTSxJQUFJQyxVQUFKLENBQWVGLEdBQUdHLE1BQWxCLENBQVo7QUFDQU4sb0JBQVlqRixJQUFaLENBQWlCcUYsR0FBakI7QUFDQUgscUJBQWFHLElBQUliLE1BQWpCO0FBQ0QsT0FMRCxFQVRzQixDQWdCdEI7O0FBQ0EsWUFBTWdCLHNCQUFzQixJQUFJRixVQUFKLENBQWVKLFNBQWYsQ0FBNUI7QUFDQSxVQUFJTyxTQUFTLENBQWI7QUFDQVIsa0JBQVk1SCxPQUFaLENBQXFCOEgsS0FBRCxJQUFXO0FBQzdCSyw0QkFBb0I3QixHQUFwQixDQUF3QndCLEtBQXhCLEVBQStCTSxNQUEvQjtBQUNBQSxrQkFBVU4sTUFBTVgsTUFBaEI7QUFDRCxPQUhEO0FBS0EsYUFBT2pELE1BQU1tRSxJQUFOLENBQVdGLG1CQUFYLENBQVAsQ0F4QnNCLENBd0JrQjtBQUN6Qzs7QUFDRCxXQUFPLElBQVA7QUFDRDs7QUFqQzZDLENBQXBCLENBQXJCLEM7Ozs7Ozs7Ozs7O0FDTFA5TCxPQUFPQyxLQUFQLENBQWFDLFFBQVEsd0JBQVIsQ0FBYjtBQUFnREYsT0FBT0MsS0FBUCxDQUFhQyxRQUFRLCtCQUFSLENBQWIsRTs7Ozs7Ozs7Ozs7QUNBaERGLE9BQU8rRCxNQUFQLENBQWM7QUFBQ2tJLGdCQUFhLE1BQUlBO0FBQWxCLENBQWQ7QUFBK0MsSUFBSWxNLE1BQUo7QUFBV0MsT0FBT0MsS0FBUCxDQUFhQyxRQUFRLGVBQVIsQ0FBYixFQUFzQztBQUFDSCxTQUFPSSxDQUFQLEVBQVM7QUFBQ0osYUFBT0ksQ0FBUDtBQUFTOztBQUFwQixDQUF0QyxFQUE0RCxDQUE1RDtBQUErRCxJQUFJQyxLQUFKO0FBQVVKLE9BQU9DLEtBQVAsQ0FBYUMsUUFBUSxjQUFSLENBQWIsRUFBcUM7QUFBQ0UsUUFBTUQsQ0FBTixFQUFRO0FBQUNDLFlBQU1ELENBQU47QUFBUTs7QUFBbEIsQ0FBckMsRUFBeUQsQ0FBekQ7QUFBNEQsSUFBSWlILEtBQUo7QUFBVXBILE9BQU9DLEtBQVAsQ0FBYUMsUUFBUSxjQUFSLENBQWIsRUFBcUM7QUFBQ2tILFFBQU1qSCxDQUFOLEVBQVE7QUFBQ2lILFlBQU1qSCxDQUFOO0FBQVE7O0FBQWxCLENBQXJDLEVBQXlELENBQXpEO0FBQTRELElBQUlFLFlBQUo7QUFBaUJMLE9BQU9DLEtBQVAsQ0FBYUMsUUFBUSxjQUFSLENBQWIsRUFBcUM7QUFBQ0ksVUFBUUgsQ0FBUixFQUFVO0FBQUNFLG1CQUFhRixDQUFiO0FBQWU7O0FBQTNCLENBQXJDLEVBQWtFLENBQWxFO0FBQXFFLElBQUlNLGNBQUo7QUFBbUJULE9BQU9DLEtBQVAsQ0FBYUMsUUFBUSwyQkFBUixDQUFiLEVBQWtEO0FBQUNJLFVBQVFILENBQVIsRUFBVTtBQUFDTSxxQkFBZU4sQ0FBZjtBQUFpQjs7QUFBN0IsQ0FBbEQsRUFBaUYsQ0FBakY7QUFBb0YsSUFBSStMLFFBQUo7QUFBYWxNLE9BQU9DLEtBQVAsQ0FBYUMsUUFBUSxpQ0FBUixDQUFiLEVBQXdEO0FBQUNnTSxXQUFTL0wsQ0FBVCxFQUFXO0FBQUMrTCxlQUFTL0wsQ0FBVDtBQUFXOztBQUF4QixDQUF4RCxFQUFrRixDQUFsRjtBQUFxRixJQUFJK0QsZ0JBQUo7QUFBcUJsRSxPQUFPQyxLQUFQLENBQWFDLFFBQVEscUJBQVIsQ0FBYixFQUE0QztBQUFDZ0UsbUJBQWlCL0QsQ0FBakIsRUFBbUI7QUFBQytELHVCQUFpQi9ELENBQWpCO0FBQW1COztBQUF4QyxDQUE1QyxFQUFzRixDQUF0Rjs7QUFRempCLE1BQU1nTSxzQkFBTixTQUFxQzFMLGNBQXJDLENBQW9EO0FBRWxEOzs7QUFHQUMsZ0JBQWM7QUFDWixVQUFNLGNBQU4sRUFBc0IsSUFBSUwsWUFBSixDQUFpQjtBQUNyQzhCLFdBQUs7QUFBRWlDLGNBQU1oRSxNQUFNaUU7QUFBZCxPQURnQztBQUVyQ0csY0FBUTtBQUFFSixjQUFNSztBQUFSLE9BRjZCO0FBR3JDMkgsb0JBQWM7QUFBRWhJLGNBQU1HO0FBQVIsT0FIdUI7QUFJckM4SCxlQUFTO0FBQUVqSSxjQUFNRztBQUFSLE9BSjRCO0FBS3JDK0gsaUJBQVc7QUFBRWxJLGNBQU1HO0FBQVIsT0FMMEI7QUFNckNNLFdBQUs7QUFBRVQsY0FBTUcsTUFBUjtBQUFnQlUsa0JBQVU7QUFBMUIsT0FOZ0M7QUFPckNzSCxnQkFBVTtBQUFFbkksY0FBTTZHO0FBQVI7QUFQMkIsS0FBakIsQ0FBdEI7QUFVQSxTQUFLOUYsZ0JBQUwsR0FBd0I7QUFDdEJxSCwyQkFBcUI7QUFEQyxLQUF4Qjs7QUFHQSxRQUFJek0sT0FBT3NGLE1BQVgsRUFBbUI7QUFDakIsV0FBS3JFLFdBQUwsQ0FBaUJzRSxhQUFqQixHQUFpQ0MsV0FBakMsQ0FBNkM7QUFBRTZHLHNCQUFjLENBQWhCO0FBQW1CNUgsZ0JBQVE7QUFBM0IsT0FBN0MsRUFBNkU7QUFBRWdCLG9CQUFZO0FBQWQsT0FBN0U7QUFDRDtBQUNGO0FBRUQ7Ozs7Ozs7Ozs7O0FBU0FyQyxTQUFPO0FBQUVxQixVQUFGO0FBQVU0SCxnQkFBVjtBQUF3QkMsV0FBeEI7QUFBaUNDLGFBQWpDO0FBQTRDekg7QUFBNUMsR0FBUCxFQUEwRDtBQUN4RCxVQUFNbkMsUUFBUSxLQUFLMUIsV0FBTCxDQUFpQjRFLE1BQWpCLENBQXdCO0FBQUVwQixZQUFGO0FBQVU0SCxrQkFBVjtBQUF3QkMsYUFBeEI7QUFBaUNDLGVBQWpDO0FBQTRDekg7QUFBNUMsS0FBeEIsQ0FBZDs7QUFDQSxXQUFPbkMsS0FBUDtBQUNEO0FBRUQ7Ozs7Ozs7QUFLQUQsVUFBUUMsS0FBUixFQUFlO0FBQ2I7QUFDQSxVQUFNSSxNQUFNLEtBQUtDLE9BQUwsQ0FBYUwsS0FBYixDQUFaO0FBQ0EsVUFBTThCLFNBQVMxQixJQUFJMEIsTUFBbkI7QUFDQSxVQUFNNEgsZUFBZXRKLElBQUlzSixZQUF6QjtBQUNBLFVBQU1DLFVBQVV2SixJQUFJdUosT0FBcEI7QUFDQSxVQUFNQyxZQUFZeEosSUFBSXdKLFNBQXRCO0FBQ0EsVUFBTXpILE1BQU0vQixJQUFJK0IsR0FBaEI7QUFFQSxXQUFPO0FBQUVMLFlBQUY7QUFBVTRILGtCQUFWO0FBQXdCQyxhQUF4QjtBQUFpQ0MsZUFBakM7QUFBNEN6SDtBQUE1QyxLQUFQO0FBQ0E7QUFDRDs7QUFFRDdCLG1CQUFpQjtBQUNmLFVBQU02QyxXQUFXLEVBQWpCO0FBQ0EsVUFBTUMsYUFBYSxLQUFLekUsS0FBTCxFQUFuQjtBQUNBLFVBQU0wRSxvQkFBb0IsS0FBSzNFLFNBQUwsR0FBaUI0RSxZQUFqQixDQUE4Qix1QkFBOUIsQ0FBMUI7QUFDQSxVQUFNQyxLQUFLL0IsaUJBQWlCNEIsVUFBakIsRUFBNkIsSUFBN0IsRUFBb0MsWUFBVyxLQUFLaEYsZUFBZ0IsZUFBcEUsQ0FBWCxDQUplLENBTWY7O0FBQ0EsVUFBTTJMLFNBQVNQLFNBQVM1SyxJQUFULEdBQWdCdUIsR0FBaEIsQ0FBb0JDLE9BQU9BLElBQUkwQixNQUEvQixDQUFmO0FBRUEsU0FBS2xELElBQUwsR0FBWXFDLE9BQVosQ0FBb0IsQ0FBQ2IsR0FBRCxFQUFNb0QsS0FBTixLQUFnQjtBQUNsQ0QsU0FBR0UsU0FBSCxDQUFhRCxLQUFiLEVBRGtDLENBQ2I7QUFFckI7O0FBQ0FILHdCQUFrQkssUUFBbEIsQ0FBMkJ0RCxHQUEzQjs7QUFDQSxVQUFJLENBQUNpRCxrQkFBa0JNLE9BQWxCLEVBQUwsRUFBa0M7QUFDaEM7QUFDQVIsaUJBQVNTLElBQVQsQ0FBZSxtREFBa0R4RCxJQUFJWCxHQUFJLG1CQUFrQm9FLEtBQUtDLFNBQUwsQ0FBZVQsa0JBQWtCVSxXQUFsQixFQUFmLEVBQWdELElBQWhELEVBQXNELENBQXRELENBQXlELEdBQXBKO0FBQ0Q7O0FBQ0RWLHdCQUFrQlcsZUFBbEIsR0FUa0MsQ0FXbEM7O0FBQ0EsVUFBSSxDQUFDK0YsT0FBT0MsUUFBUCxDQUFnQjVKLElBQUkwQixNQUFwQixDQUFMLEVBQWtDO0FBQ2hDcUIsaUJBQVNTLElBQVQsQ0FBZSwrREFBOER4RCxJQUFJMEIsTUFBTyxZQUFXMUIsSUFBSVgsR0FBSSxHQUEzRztBQUNEO0FBQ0YsS0FmRDtBQWlCQThELE9BQUdVLGFBQUg7QUFDQSxXQUFPZCxRQUFQO0FBQ0Q7QUFFRDs7Ozs7OztBQUtBdkQsWUFBVTtBQUFFO0FBQ1YsUUFBSXZDLE9BQU93QyxRQUFYLEVBQXFCO0FBQ25CLFlBQU1nRyxPQUFPLElBQWI7QUFDQXhJLGFBQU91QyxPQUFQLENBQWUsS0FBSzZDLGdCQUFMLENBQXNCcUgsbUJBQXJDLEVBQTBELFVBQVVHLG1CQUFWLEVBQStCQyxLQUEvQixFQUFzQztBQUM5RnhGLGNBQU11RixtQkFBTixFQUEyQnBJLE1BQTNCO0FBQ0E2QyxjQUFNd0YsS0FBTixFQUFhbkksTUFBYjtBQUVBLGNBQU1mLFdBQVcsSUFBakI7QUFFQSxjQUFNbUosY0FBYzVCLEtBQUs2QixHQUFMLEtBQWNILHNCQUFzQixJQUF4RCxDQU44RixDQU85Rjs7QUFDQSxjQUFNSSwyQkFBMkIsSUFBSWxELEdBQUosRUFBakMsQ0FSOEYsQ0FRbEQ7O0FBRTVDLGNBQU0vSCxXQUFZOEssS0FBRCxHQUFVO0FBQ3pCcEksa0JBQVFvSSxLQURpQjtBQUV6QlIsd0JBQWM7QUFBRXZLLGtCQUFNZ0w7QUFBUjtBQUZXLFNBQVYsR0FHYjtBQUFFVCx3QkFBYztBQUFFdkssa0JBQU1nTDtBQUFSO0FBQWhCLFNBSEo7QUFLQSxZQUFJRyxPQUFPLElBQVg7QUFDQSxjQUFNQyxxQkFBcUIxRSxLQUFLakgsSUFBTCxDQUFVUSxRQUFWLEVBQW9CO0FBQzdDb0wsa0JBQVE7QUFBRS9LLGlCQUFLLENBQVA7QUFBVWlLLDBCQUFjLENBQXhCO0FBQTJCQyxxQkFBUyxDQUFwQztBQUF1Q0MsdUJBQVcsQ0FBbEQ7QUFBcUQ5SCxvQkFBUTtBQUE3RCxXQURxQztBQUU3QzJJLDZCQUFtQjtBQUYwQixTQUFwQixFQUd4QkMsY0FId0IsQ0FHVDtBQUNoQkMsaUJBQU8sVUFBVUMsRUFBVixFQUFjSixNQUFkLEVBQXNCO0FBQzNCSCxxQ0FBeUI5QyxHQUF6QixDQUE2QmlELE9BQU9kLFlBQXBDLEVBQWtEa0IsRUFBbEQ7QUFDQTVKLHFCQUFTMkosS0FBVCxDQUFlLGNBQWYsRUFBK0JDLEVBQS9CLEVBQW1DSixNQUFuQzs7QUFFQSxnQkFBSSxDQUFDRixJQUFMLEVBQVc7QUFDVCxvQkFBTXhFLFlBQVl5QyxLQUFLNkIsR0FBTCxLQUFjSCxzQkFBc0IsSUFBdEQsQ0FEUyxDQUVUOztBQUNBSSx1Q0FBeUJwSixPQUF6QixDQUFpQyxDQUFDeEIsR0FBRCxFQUFNb0wsU0FBTixLQUFvQjtBQUNuRCxvQkFBSUEsWUFBWS9FLFNBQWhCLEVBQTJCO0FBQ3pCOUUsMkJBQVM4SixPQUFULENBQWlCLGNBQWpCLEVBQWlDckwsR0FBakM7QUFDQTRLLDJDQUF5QlUsTUFBekIsQ0FBZ0NGLFNBQWhDO0FBQ0Q7QUFDRixlQUxEO0FBTUQ7QUFDRjtBQWZlLFNBSFMsQ0FBM0I7QUFvQkFQLGVBQU8sS0FBUDtBQUNBdEosaUJBQVNnSyxLQUFUO0FBQ0FoSyxpQkFBU2lLLE1BQVQsQ0FBZ0IsWUFBWTtBQUMxQlYsNkJBQW1CVyxJQUFuQjtBQUNELFNBRkQ7QUFHRCxPQXpDRDtBQTBDRDtBQUNGOztBQXpJaUQ7QUE0SXBEOzs7Ozs7QUFJTyxNQUFNM0IsZUFBZSxJQUFJRSxzQkFBSixFQUFyQixDOzs7Ozs7Ozs7OztBQ3hKUG5NLE9BQU8rRCxNQUFQLENBQWM7QUFBQzhKLDBCQUF1QixNQUFJQSxzQkFBNUI7QUFBbURDLGtCQUFlLE1BQUlBLGNBQXRFO0FBQXFGQyxnQkFBYSxNQUFJQSxZQUF0RztBQUFtSEMsbUJBQWdCLE1BQUlBLGVBQXZJO0FBQXVKQyxvQ0FBaUMsTUFBSUEsZ0NBQTVMO0FBQTZOQyx3QkFBcUIsTUFBSUEsb0JBQXRQO0FBQTJRQyx3QkFBcUIsTUFBSUE7QUFBcFMsQ0FBZDtBQUF5VSxJQUFJL04sS0FBSjtBQUFVSixPQUFPQyxLQUFQLENBQWFDLFFBQVEsY0FBUixDQUFiLEVBQXFDO0FBQUNFLFFBQU1ELENBQU4sRUFBUTtBQUFDQyxZQUFNRCxDQUFOO0FBQVE7O0FBQWxCLENBQXJDLEVBQXlELENBQXpEOztBQUE0RCxJQUFJSSxDQUFKOztBQUFNUCxPQUFPQyxLQUFQLENBQWFDLFFBQVEsUUFBUixDQUFiLEVBQStCO0FBQUNJLFVBQVFILENBQVIsRUFBVTtBQUFDSSxRQUFFSixDQUFGO0FBQUk7O0FBQWhCLENBQS9CLEVBQWlELENBQWpEO0FBQW9ELElBQUlLLE1BQUo7QUFBV1IsT0FBT0MsS0FBUCxDQUFhQyxRQUFRLFFBQVIsQ0FBYixFQUErQjtBQUFDSSxVQUFRSCxDQUFSLEVBQVU7QUFBQ0ssYUFBT0wsQ0FBUDtBQUFTOztBQUFyQixDQUEvQixFQUFzRCxDQUF0RDtBQUF5RCxJQUFJMkcsZUFBSjtBQUFvQjlHLE9BQU9DLEtBQVAsQ0FBYUMsUUFBUSw2QkFBUixDQUFiLEVBQW9EO0FBQUM0RyxrQkFBZ0IzRyxDQUFoQixFQUFrQjtBQUFDMkcsc0JBQWdCM0csQ0FBaEI7QUFBa0I7O0FBQXRDLENBQXBELEVBQTRGLENBQTVGO0FBQStGLElBQUlFLFlBQUo7QUFBaUJMLE9BQU9DLEtBQVAsQ0FBYUMsUUFBUSxjQUFSLENBQWIsRUFBcUM7QUFBQ0ksVUFBUUgsQ0FBUixFQUFVO0FBQUNFLG1CQUFhRixDQUFiO0FBQWU7O0FBQTNCLENBQXJDLEVBQWtFLENBQWxFO0FBQXFFLElBQUk4TCxZQUFKO0FBQWlCak0sT0FBT0MsS0FBUCxDQUFhQyxRQUFRLDZCQUFSLENBQWIsRUFBb0Q7QUFBQytMLGVBQWE5TCxDQUFiLEVBQWU7QUFBQzhMLG1CQUFhOUwsQ0FBYjtBQUFlOztBQUFoQyxDQUFwRCxFQUFzRixDQUF0RjtBQUF5RixJQUFJOEQsTUFBSjtBQUFXakUsT0FBT0MsS0FBUCxDQUFhQyxRQUFRLCtCQUFSLENBQWIsRUFBc0Q7QUFBQytELFNBQU85RCxDQUFQLEVBQVM7QUFBQzhELGFBQU85RCxDQUFQO0FBQVM7O0FBQXBCLENBQXRELEVBQTRFLENBQTVFO0FBUXAwQixNQUFNME4seUJBQXlCLElBQUkvRyxlQUFKLENBQW9CO0FBQ3hENUUsUUFBTSxxQ0FEa0Q7QUFFeERrRSxZQUFVLElBQUkvRixZQUFKLEdBQW1CMEcsU0FBbkIsQ0FBNkI7QUFBRUMsV0FBTztBQUFULEdBQTdCLENBRjhDOztBQUd4REMsUUFBTTtBQUNKLFdBQU9nRixhQUFhM0ssSUFBYixDQUFrQixFQUFsQixFQUFzQkQsS0FBdEIsRUFBUDtBQUNEOztBQUx1RCxDQUFwQixDQUEvQjtBQVFBLE1BQU15TSxpQkFBaUIsSUFBSWhILGVBQUosQ0FBb0I7QUFDaEQ1RSxRQUFNLDZCQUQwQztBQUVoRGtFLFlBQVUsSUFBSS9GLFlBQUosQ0FBaUI7QUFDekJtRSxZQUFRO0FBQUVKLFlBQU1LO0FBQVI7QUFEaUIsR0FBakIsRUFFUHNDLFNBRk8sQ0FFRztBQUFFQyxXQUFPO0FBQVQsR0FGSCxDQUZzQzs7QUFLaERDLE1BQUk7QUFBRXpDO0FBQUYsR0FBSixFQUFnQjtBQUNkLFFBQUksQ0FBQyxLQUFLMEMsWUFBVixFQUF3QjtBQUN0QixZQUFNa0gsZUFBZTVOLFNBQVM2TixRQUFULENBQWtCLEVBQWxCLEVBQXNCLFNBQXRCLEVBQWlDMU0sT0FBakMsRUFBckI7QUFDQSxZQUFNMk0sZUFBZXJDLGFBQWFqSyxPQUFiLENBQXFCO0FBQUV3QyxjQUFGO0FBQVU0SCxzQkFBYztBQUFFdkssZ0JBQU11TTtBQUFSO0FBQXhCLE9BQXJCLENBQXJCO0FBQ0EsYUFBTyxDQUFDLENBQUNFLFlBQVQ7QUFDRDs7QUFDRCxXQUFPLElBQVA7QUFDRDs7QUFaK0MsQ0FBcEIsQ0FBdkI7QUFlQSxNQUFNUCxlQUFlLElBQUlqSCxlQUFKLENBQW9CO0FBQzlDNUUsUUFBTSwyQkFEd0M7QUFFOUNrRSxZQUFVLElBQUkvRixZQUFKLEdBQW1CMEcsU0FBbkIsQ0FBNkI7QUFBRUMsV0FBTztBQUFULEdBQTdCLENBRm9DOztBQUc5Q0MsUUFBTTtBQUNKLFFBQUksQ0FBQyxLQUFLQyxZQUFWLEVBQXdCO0FBQ3RCLFlBQU1rSCxlQUFlNU4sU0FBUzZOLFFBQVQsQ0FBa0IsRUFBbEIsRUFBc0IsU0FBdEIsRUFBaUMxTSxPQUFqQyxFQUFyQjtBQUNBLFlBQU0yTSxlQUFlckMsYUFBYTNLLElBQWIsQ0FBa0I7QUFBRThLLHNCQUFjO0FBQUV2SyxnQkFBTXVNO0FBQVI7QUFBaEIsT0FBbEIsRUFBNEQzSyxLQUE1RCxFQUFyQjs7QUFDQSxVQUFJNkssYUFBYXhELE1BQWIsR0FBc0IsQ0FBMUIsRUFBNkI7QUFDM0IsZUFBT3ZLLEVBQUVnTyxJQUFGLENBQU9oTyxFQUFFc0MsR0FBRixDQUFNeUwsWUFBTixFQUFvQixRQUFwQixDQUFQLENBQVA7QUFDRDtBQUNGOztBQUNELFdBQU8sSUFBUDtBQUNEOztBQVo2QyxDQUFwQixDQUFyQjtBQWVBLE1BQU1OLGtCQUFrQixJQUFJbEgsZUFBSixDQUFvQjtBQUNqRDVFLFFBQU0sOEJBRDJDO0FBRWpEa0UsWUFBVSxJQUFJL0YsWUFBSixDQUFpQjtBQUN6QndNLGlCQUFhO0FBQUV6SSxZQUFNRztBQUFSO0FBRFksR0FBakIsRUFFUHdDLFNBRk8sQ0FFRztBQUFFQyxXQUFPO0FBQVQsR0FGSCxDQUZ1Qzs7QUFLakRDLE1BQUk7QUFBRTRGO0FBQUYsR0FBSixFQUFxQjtBQUNuQixVQUFNMkIscUJBQXFCdkMsYUFBYTNLLElBQWIsQ0FBa0I7QUFDM0M4SyxvQkFBYztBQUFFdkssY0FBTWdMO0FBQVI7QUFENkIsS0FBbEIsRUFFeEI7QUFDREssY0FBUTtBQUFFMUksZ0JBQVE7QUFBVjtBQURQLEtBRndCLEVBSXhCZixLQUp3QixFQUEzQixDQURtQixDQU9uQjs7QUFDQSxXQUFRK0ssbUJBQW1CMUQsTUFBbkIsR0FBNEIsQ0FBN0IsR0FDSHZLLEVBQUVnTyxJQUFGLENBQU9oTyxFQUFFa08sS0FBRixDQUFRRCxrQkFBUixFQUE0QixRQUE1QixDQUFQLEVBQThDdkYsSUFBOUMsQ0FBbUQsQ0FBQ3lGLENBQUQsRUFBSUMsQ0FBSixLQUFVRCxJQUFJQyxDQUFqRSxDQURHLEdBRUgsSUFGSjtBQUdEOztBQWhCZ0QsQ0FBcEIsQ0FBeEI7QUFtQkEsTUFBTVYsbUNBQW1DLElBQUluSCxlQUFKLENBQW9CO0FBQ2xFNUUsUUFBTSwrQ0FENEQ7QUFFbEVrRSxZQUFVLElBQUkvRixZQUFKLENBQWlCO0FBQ3pCdU8scUJBQWlCO0FBQUV4SyxZQUFNaEUsTUFBTWlFO0FBQWQ7QUFEUSxHQUFqQixFQUVQMEMsU0FGTyxDQUVHO0FBQUVDLFdBQU87QUFBVCxHQUZILENBRndEOztBQUtsRUMsTUFBSTtBQUFFMkg7QUFBRixHQUFKLEVBQXlCO0FBQ3ZCLFFBQUksQ0FBQyxLQUFLMUgsWUFBVixFQUF3QjtBQUN0QixZQUFNeUMsZ0JBQWdCMUYsT0FBT2pDLE9BQVAsQ0FBZTtBQUFFRyxhQUFLeU07QUFBUCxPQUFmLENBQXRCO0FBRUEsWUFBTUMsb0JBQW9CNUMsYUFBYTNLLElBQWIsQ0FBa0I7QUFDMUNrRCxnQkFBUW1GLGNBQWNuQyxlQUFkLENBQThCLENBQTlCLENBRGtDO0FBQ0E7QUFDMUM0RSxzQkFBYztBQUFFdkssZ0JBQU04SCxjQUFjbEUsV0FBdEI7QUFBbUMwRCxnQkFBTVEsY0FBY2pFO0FBQXZEO0FBRjRCLE9BQWxCLEVBR3ZCO0FBQ0R1RCxjQUFNO0FBQUV2RCxxQkFBVztBQUFiO0FBREwsT0FIdUIsRUFLdkJqQyxLQUx1QixFQUExQjtBQU9BLFlBQU1xTCw0QkFBNEJELGtCQUFrQixDQUFsQixFQUFxQnpDLFlBQXZEO0FBQ0EsWUFBTTJDLDJCQUEyQkYsa0JBQWtCQSxrQkFBa0IvRCxNQUFsQixHQUEyQixDQUE3QyxFQUFnRHNCLFlBQWpGLENBWHNCLENBYXRCOztBQUNBLFlBQU00QyxrQkFBbUJyRixjQUFjakUsU0FBZCxHQUEwQmlFLGNBQWNsRSxXQUFqRTtBQUNBLFlBQU13SixxQkFBcUJ0RixjQUFjbEUsV0FBZCxHQUE2QnVKLGtCQUFrQixHQUExRTtBQUNBLFlBQU1FLHNCQUFzQnZGLGNBQWNqRSxTQUFkLEdBQTJCc0osa0JBQWtCLEdBQXpFO0FBRUEsWUFBTUcsd0JBQXdCbEQsYUFBYTNLLElBQWIsQ0FBa0I7QUFDOUNrRCxnQkFBUW1GLGNBQWNuQyxlQUFkLENBQThCLENBQTlCLENBRHNDO0FBRTlDNEUsc0JBQWM7QUFBRXZLLGdCQUFNb04sa0JBQVI7QUFBNEI5RixnQkFBTTJGO0FBQWxDO0FBRmdDLE9BQWxCLEVBRzNCLEVBSDJCLEVBR3ZCckwsS0FIdUIsRUFBOUI7QUFLQSxZQUFNMkwseUJBQXlCbkQsYUFBYTNLLElBQWIsQ0FBa0I7QUFDL0NrRCxnQkFBUW1GLGNBQWNuQyxlQUFkLENBQThCLENBQTlCLENBRHVDO0FBRS9DNEUsc0JBQWM7QUFBRXZLLGdCQUFNa04sd0JBQVI7QUFBa0M1RixnQkFBTStGO0FBQXhDO0FBRmlDLE9BQWxCLEVBRzVCLEVBSDRCLEVBR3hCekwsS0FId0IsRUFBL0I7QUFLQSxhQUFPO0FBQUVvTCx5QkFBRjtBQUFxQk0sNkJBQXJCO0FBQTRDQztBQUE1QyxPQUFQO0FBQ0Q7O0FBRUQsV0FBTyxJQUFQO0FBQ0Q7O0FBdENpRSxDQUFwQixDQUF6QztBQXlDQSxNQUFNbEIsdUJBQXVCLElBQUlwSCxlQUFKLENBQW9CO0FBQ3RENUUsUUFBTSxtQ0FEZ0Q7QUFFdERrRSxZQUFVLElBQUkvRixZQUFKLENBQWlCO0FBQ3pCbUUsWUFBUTtBQUFFSixZQUFNRyxNQUFSO0FBQWdCVSxnQkFBVTtBQUExQixLQURpQjtBQUNpQjtBQUMxQ3VELGVBQVc7QUFBRXBFLFlBQU1HLE1BQVI7QUFBZ0JVLGdCQUFVO0FBQTFCLEtBRmM7QUFHekJ3RCxhQUFTO0FBQUVyRSxZQUFNRyxNQUFSO0FBQWdCVSxnQkFBVTtBQUExQjtBQUhnQixHQUFqQixFQUlQOEIsU0FKTyxDQUlHO0FBQUVDLFdBQU87QUFBVCxHQUpILENBRjRDOztBQU90REMsTUFBSTtBQUFFekMsVUFBRjtBQUFVZ0UsYUFBVjtBQUFxQkM7QUFBckIsR0FBSixFQUFvQztBQUNsQyxRQUFJLENBQUMsS0FBS3ZCLFlBQVYsRUFBd0I7QUFDdEJtSSxjQUFRQyxHQUFSLENBQVk5SyxNQUFaLEVBQW9CZ0UsU0FBcEIsRUFBK0JDLE9BQS9CO0FBQ0EsWUFBTW9HLG9CQUFvQjVDLGFBQWEzSyxJQUFiLENBQWtCO0FBQzFDa0QsY0FEMEM7QUFFMUM0SCxzQkFBYztBQUFFdkssZ0JBQU0yRyxTQUFSO0FBQW1CVyxnQkFBTVY7QUFBekI7QUFGNEIsT0FBbEIsRUFHdkI7QUFDRFEsY0FBTTtBQUFFbUQsd0JBQWM7QUFBaEI7QUFETCxPQUh1QixFQUt2QjNJLEtBTHVCLEVBQTFCO0FBT0EsWUFBTXFMLDRCQUE0QkQsa0JBQWtCLENBQWxCLEVBQXFCekMsWUFBdkQ7QUFDQSxZQUFNMkMsMkJBQTJCRixrQkFBa0JBLGtCQUFrQi9ELE1BQWxCLEdBQTJCLENBQTdDLEVBQWdEc0IsWUFBakYsQ0FWc0IsQ0FZdEI7O0FBQ0EsWUFBTW1ELFdBQVk5RyxVQUFVRCxTQUE1QjtBQUNBLFlBQU15RyxxQkFBcUJ6RyxZQUFhK0csV0FBVyxJQUFuRDtBQUNBLFlBQU1MLHNCQUFzQnpHLFVBQVc4RyxXQUFXLElBQWxEO0FBRUEsWUFBTUosd0JBQXdCbEQsYUFBYTNLLElBQWIsQ0FBa0I7QUFDOUNrRCxjQUQ4QztBQUU5QzRILHNCQUFjO0FBQUV2SyxnQkFBTW9OLGtCQUFSO0FBQTRCOUYsZ0JBQU0yRjtBQUFsQztBQUZnQyxPQUFsQixFQUczQixFQUgyQixFQUd2QnJMLEtBSHVCLEVBQTlCO0FBS0EsWUFBTTJMLHlCQUF5Qm5ELGFBQWEzSyxJQUFiLENBQWtCO0FBQy9Da0QsY0FEK0M7QUFFL0M0SCxzQkFBYztBQUFFdkssZ0JBQU1rTix3QkFBUjtBQUFrQzVGLGdCQUFNK0Y7QUFBeEM7QUFGaUMsT0FBbEIsRUFHNUIsRUFINEIsRUFHeEJ6TCxLQUh3QixFQUEvQjtBQUtBLGFBQU87QUFBRW9MLHlCQUFGO0FBQXFCTSw2QkFBckI7QUFBNENDO0FBQTVDLE9BQVA7QUFDRDs7QUFDRCxXQUFPLElBQVA7QUFDRDs7QUF0Q3FELENBQXBCLENBQTdCOztBQXlDQSxNQUFNakIsdUJBQXVCLENBQUNxQixVQUFELEVBQWFDLFVBQWIsRUFBeUIsR0FBR0MsUUFBNUIsS0FBeUM7QUFDM0UsUUFBTUMsYUFBYSxJQUFJOUYsR0FBSixFQUFuQjtBQUNBLFFBQU0rRixjQUFjRixTQUFTNUUsTUFBN0I7QUFFQTRFLFdBQVMvTCxPQUFULENBQWlCLENBQUNrTSxPQUFELEVBQVUzSixLQUFWLEtBQW9CO0FBQ25DO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxVQUFNNEosYUFBYTVKLEtBQW5CO0FBQ0EySixZQUFRbE0sT0FBUixDQUFnQjhHLFFBQVE7QUFDdEIsWUFBTXNGLElBQUl0RixLQUFLK0UsVUFBTCxDQUFWO0FBQ0EsWUFBTVEsSUFBSXZGLEtBQUtnRixVQUFMLENBQVY7O0FBRUEsVUFBSUUsV0FBVzNGLEdBQVgsQ0FBZStGLENBQWYsQ0FBSixFQUF1QjtBQUNyQjtBQUNBLGNBQU1FLE1BQU1OLFdBQVd6RixHQUFYLENBQWU2RixDQUFmLENBQVo7QUFDQUUsWUFBSUgsVUFBSixJQUFrQkUsQ0FBbEI7QUFDQUwsbUJBQVcxRixHQUFYLENBQWU4RixDQUFmLEVBQWtCRSxHQUFsQjtBQUNELE9BTEQsTUFLTztBQUNMO0FBQ0EsY0FBTUMsU0FBUyxJQUFJckksS0FBSixDQUFVK0gsV0FBVixFQUF1Qk8sSUFBdkIsQ0FBNEIsSUFBNUIsQ0FBZjtBQUNBRCxlQUFPSixVQUFQLElBQXFCRSxDQUFyQixDQUhLLENBR21COztBQUN4QkwsbUJBQVcxRixHQUFYLENBQWU4RixDQUFmLEVBQWtCRyxNQUFsQjtBQUNEO0FBQ0YsS0FmRDtBQWdCRCxHQTdCRDtBQStCQSxRQUFNRSxnQkFBZ0J2SSxNQUFNbUUsSUFBTixDQUFXMkQsV0FBV1UsSUFBWCxFQUFYLEVBQThCeE4sR0FBOUIsQ0FBa0N5TixPQUFPLENBQUNBLEdBQUQsRUFBTSxHQUFHWCxXQUFXekYsR0FBWCxDQUFlb0csR0FBZixDQUFULENBQXpDLENBQXRCLENBbkMyRSxDQXFDM0U7O0FBQ0FGLGdCQUFjbkgsSUFBZCxDQUFtQixDQUFDeUYsQ0FBRCxFQUFJQyxDQUFKLEtBQVVELEVBQUUsQ0FBRixJQUFPQyxFQUFFLENBQUYsQ0FBcEM7QUFFQSxTQUFPeUIsYUFBUDtBQUNELENBekNNLEM7Ozs7Ozs7Ozs7O0FDbkpQcFEsT0FBT0MsS0FBUCxDQUFhQyxRQUFRLDZCQUFSLENBQWI7QUFBcURGLE9BQU9DLEtBQVAsQ0FBYUMsUUFBUSxvQ0FBUixDQUFiLEU7Ozs7Ozs7Ozs7O0FDQXJERixPQUFPK0QsTUFBUCxDQUFjO0FBQUNtSSxZQUFTLE1BQUlBO0FBQWQsQ0FBZDtBQUF1QyxJQUFJN0wsWUFBSjtBQUFpQkwsT0FBT0MsS0FBUCxDQUFhQyxRQUFRLGNBQVIsQ0FBYixFQUFxQztBQUFDSSxVQUFRSCxDQUFSLEVBQVU7QUFBQ0UsbUJBQWFGLENBQWI7QUFBZTs7QUFBM0IsQ0FBckMsRUFBa0UsQ0FBbEU7QUFBcUUsSUFBSUosTUFBSjtBQUFXQyxPQUFPQyxLQUFQLENBQWFDLFFBQVEsZUFBUixDQUFiLEVBQXNDO0FBQUNILFNBQU9JLENBQVAsRUFBUztBQUFDSixhQUFPSSxDQUFQO0FBQVM7O0FBQXBCLENBQXRDLEVBQTRELENBQTVEO0FBQStELElBQUlLLE1BQUo7QUFBV1IsT0FBT0MsS0FBUCxDQUFhQyxRQUFRLFFBQVIsQ0FBYixFQUErQjtBQUFDSSxVQUFRSCxDQUFSLEVBQVU7QUFBQ0ssYUFBT0wsQ0FBUDtBQUFTOztBQUFyQixDQUEvQixFQUFzRCxDQUF0RDtBQUF5RCxJQUFJTSxjQUFKO0FBQW1CVCxPQUFPQyxLQUFQLENBQWFDLFFBQVEsMkJBQVIsQ0FBYixFQUFrRDtBQUFDSSxVQUFRSCxDQUFSLEVBQVU7QUFBQ00scUJBQWVOLENBQWY7QUFBaUI7O0FBQTdCLENBQWxELEVBQWlGLENBQWpGO0FBQW9GLElBQUkrRCxnQkFBSjtBQUFxQmxFLE9BQU9DLEtBQVAsQ0FBYUMsUUFBUSxxQkFBUixDQUFiLEVBQTRDO0FBQUNnRSxtQkFBaUIvRCxDQUFqQixFQUFtQjtBQUFDK0QsdUJBQWlCL0QsQ0FBakI7QUFBbUI7O0FBQXhDLENBQTVDLEVBQXNGLENBQXRGOztBQU92WTs7OztBQUlBLE1BQU1vUSxrQkFBTixTQUFpQzlQLGNBQWpDLENBQWdEO0FBRTlDOzs7QUFHQUMsZ0JBQWM7QUFDWixVQUFNLFdBQU4sRUFBbUIsSUFBSUwsWUFBSixDQUFpQjtBQUNsQ21FLGNBQVFDLE1BRDBCO0FBRWxDdkMsWUFBTTtBQUFFa0MsY0FBTUssTUFBUjtBQUFnQlEsa0JBQVU7QUFBMUIsT0FGNEI7QUFHbENzQyxtQkFBYTtBQUFFbkQsY0FBTUssTUFBUjtBQUFnQlEsa0JBQVU7QUFBMUIsT0FIcUI7QUFJbEN1TCxpQkFBVztBQUFFcE0sY0FBTXFNLE9BQVI7QUFBaUJ4TCxrQkFBVTtBQUEzQixPQUp1QjtBQUtsQ3lMLDRCQUFzQm5NLE1BTFk7QUFNbENvTSxpQkFBVztBQUFFdk0sY0FBTXlEO0FBQVIsT0FOdUI7QUFPbEMscUJBQWU7QUFBRXpELGNBQU1ZLE1BQVI7QUFBZ0I0TCxrQkFBVTtBQUExQjtBQVBtQixLQUFqQixDQUFuQjtBQVNEO0FBRUQ7Ozs7Ozs7Ozs7Ozs7O0FBWUF6TixTQUFPO0FBQUVxQixVQUFGO0FBQVV0QyxRQUFWO0FBQWdCcUYsZUFBaEI7QUFBNkJtSix3QkFBN0I7QUFBbURDLGFBQW5EO0FBQThESCxnQkFBWTtBQUExRSxHQUFQLEVBQTBGO0FBQ3hGLFFBQUl6USxPQUFPd0MsUUFBWCxFQUFxQjtBQUNuQjtBQUNBLFlBQU1zTyxVQUFVLEtBQUtDLGlCQUFMLENBQXVCSCxTQUF2QixDQUFoQjs7QUFDQSxXQUFLM1AsV0FBTCxDQUFpQitQLE1BQWpCLENBQ0U7QUFBRXZNO0FBQUYsT0FERixFQUVFO0FBQUV3TSxjQUFNO0FBQUU5TyxjQUFGO0FBQVFxRixxQkFBUjtBQUFxQm1KLDhCQUFyQjtBQUEyQ0MscUJBQVdFLE9BQXREO0FBQStETDtBQUEvRDtBQUFSLE9BRkY7O0FBSUEsWUFBTTlOLFFBQVEsS0FBS1YsT0FBTCxDQUFhO0FBQUV3QztBQUFGLE9BQWIsRUFBeUJyQyxHQUF2Qzs7QUFDQSxhQUFPTyxLQUFQO0FBQ0Q7O0FBQ0QsV0FBT3VPLFNBQVA7QUFDRDtBQUVEOzs7Ozs7OztBQU1BSCxvQkFBa0JILFNBQWxCLEVBQTZCO0FBQzNCLFdBQU9BLFVBQVU5TixHQUFWLENBQWNrQyxZQUFZO0FBQy9CLFlBQU1tTSxrQkFBa0IxUSxPQUFPdUUsU0FBU29NLGFBQWhCLENBQXhCOztBQUNBLFVBQUlELGdCQUFnQjdLLE9BQWhCLEVBQUosRUFBK0I7QUFDN0J0QixpQkFBU29NLGFBQVQsR0FBeUJELGdCQUFnQnZQLE9BQWhCLEVBQXpCLENBRDZCLENBQ3VCO0FBQ3JEOztBQUNELGFBQU9vRCxRQUFQO0FBQ0QsS0FOTSxDQUFQO0FBT0Q7QUFFRDs7Ozs7Ozs7QUFNQXFNLFVBQVE1TSxNQUFSLEVBQWdCO0FBQ2QsVUFBTTZNLFNBQVMsS0FBS3JRLFdBQUwsQ0FBaUJnQixPQUFqQixDQUF5QjtBQUFFd0M7QUFBRixLQUF6QixDQUFmOztBQUNBLFFBQUk2TSxNQUFKLEVBQVk7QUFDVixhQUFPQSxNQUFQO0FBQ0Q7O0FBQ0QsVUFBTSxJQUFJdFIsT0FBT2MsS0FBWCxDQUFrQix5QkFBd0IyRCxNQUFPLEVBQWpELENBQU47QUFDRDtBQUVEOzs7Ozs7QUFJQThNLGVBQWE7QUFDWCxVQUFNQyxPQUFPLEtBQUt2USxXQUFMLENBQWlCTSxJQUFqQixDQUFzQixFQUF0QixFQUEwQm1DLEtBQTFCLEVBQWI7O0FBQ0EsV0FBUThOLElBQUQsR0FBU2hSLEVBQUVzQyxHQUFGLENBQU0wTyxJQUFOLEVBQVl6TyxPQUFPQSxJQUFJMEIsTUFBdkIsQ0FBVCxHQUEwQyxFQUFqRDtBQUNEO0FBRUQ7Ozs7Ozs7QUFLQS9CLFVBQVFDLEtBQVIsRUFBZTtBQUNiO0FBQ0EsVUFBTUksTUFBTSxLQUFLQyxPQUFMLENBQWFMLEtBQWIsQ0FBWjtBQUNBLFVBQU04QixTQUFTMUIsSUFBSTBCLE1BQW5CO0FBQ0EsVUFBTXRDLE9BQU9ZLElBQUlaLElBQWpCO0FBQ0EsVUFBTXFGLGNBQWN6RSxJQUFJeUUsV0FBeEI7QUFDQSxVQUFNbUosdUJBQXVCNU4sSUFBSTROLG9CQUFqQztBQUNBLFVBQU1DLFlBQVk3TixJQUFJNk4sU0FBdEI7QUFFQSxXQUFPO0FBQUVuTSxZQUFGO0FBQVV0QyxVQUFWO0FBQWdCcUYsaUJBQWhCO0FBQTZCbUosMEJBQTdCO0FBQW1EQztBQUFuRCxLQUFQO0FBQ0E7QUFDRDs7QUFFRDNOLG1CQUFpQjtBQUNmLFVBQU02QyxXQUFXLEVBQWpCO0FBQ0EsVUFBTUMsYUFBYSxLQUFLekUsS0FBTCxFQUFuQjtBQUNBLFVBQU0wRSxvQkFBb0IsS0FBSzNFLFNBQUwsR0FBaUI0RSxZQUFqQixDQUE4QixtQkFBOUIsQ0FBMUI7QUFDQSxVQUFNQyxLQUFLL0IsaUJBQWlCNEIsVUFBakIsRUFBNkIsSUFBN0IsRUFBb0MsWUFBVyxLQUFLaEYsZUFBZ0IsZUFBcEUsQ0FBWDtBQUVBLFNBQUtRLElBQUwsR0FBWXFDLE9BQVosQ0FBb0IsQ0FBQ2IsR0FBRCxFQUFNb0QsS0FBTixLQUFnQjtBQUNsQ0QsU0FBR0UsU0FBSCxDQUFhRCxLQUFiLEVBRGtDLENBQ2I7QUFFckI7O0FBQ0FILHdCQUFrQkssUUFBbEIsQ0FBMkJ0RCxHQUEzQjs7QUFDQSxVQUFJLENBQUNpRCxrQkFBa0JNLE9BQWxCLEVBQUwsRUFBa0M7QUFDaEM7QUFDQVIsaUJBQVNTLElBQVQsQ0FBZSw2Q0FBNEN4RCxJQUFJWCxHQUFJLG1CQUFrQm9FLEtBQUtDLFNBQUwsQ0FBZVQsa0JBQWtCVSxXQUFsQixFQUFmLEVBQWdELElBQWhELEVBQXNELENBQXRELENBQXlELEdBQTlJO0FBQ0Q7O0FBQ0RWLHdCQUFrQlcsZUFBbEIsR0FUa0MsQ0FXbEM7O0FBQ0EsVUFBSSxLQUFLcEYsSUFBTCxDQUFVO0FBQUVrRCxnQkFBUTFCLElBQUkwQjtBQUFkLE9BQVYsRUFBa0NuRCxLQUFsQyxLQUE0QyxDQUFoRCxFQUFtRHdFLFNBQVNTLElBQVQsQ0FBZSxnQ0FBK0J4RCxJQUFJMEIsTUFBTyxFQUF6RCxFQVpqQixDQWNsQztBQUNBOztBQUNBLFVBQUkxQixJQUFJWixJQUFKLElBQVksS0FBS1osSUFBTCxDQUFVO0FBQUVZLGNBQU1ZLElBQUlaO0FBQVosT0FBVixFQUE4QmIsS0FBOUIsS0FBd0MsQ0FBeEQsRUFBMkR3RSxTQUFTUyxJQUFULENBQWUsOEJBQTZCeEQsSUFBSVosSUFBSyxFQUFyRDtBQUM1RCxLQWpCRDtBQW1CQStELE9BQUdVLGFBQUg7QUFDQSxXQUFPZCxRQUFQO0FBQ0Q7O0FBL0g2QztBQWtJaEQ7Ozs7OztBQUlPLE1BQU1xRyxXQUFXLElBQUlxRSxrQkFBSixFQUFqQixDOzs7Ozs7Ozs7OztBQ2pKUHZRLE9BQU8rRCxNQUFQLENBQWM7QUFBQ3lOLHNCQUFtQixNQUFJQSxrQkFBeEI7QUFBMkNDLDZCQUEwQixNQUFJQSx5QkFBekU7QUFBbUdDLGFBQVUsTUFBSUE7QUFBakgsQ0FBZDtBQUEySSxJQUFJNUssZUFBSjtBQUFvQjlHLE9BQU9DLEtBQVAsQ0FBYUMsUUFBUSw2QkFBUixDQUFiLEVBQW9EO0FBQUM0RyxrQkFBZ0IzRyxDQUFoQixFQUFrQjtBQUFDMkcsc0JBQWdCM0csQ0FBaEI7QUFBa0I7O0FBQXRDLENBQXBELEVBQTRGLENBQTVGO0FBQStGLElBQUlFLFlBQUo7QUFBaUJMLE9BQU9DLEtBQVAsQ0FBYUMsUUFBUSxjQUFSLENBQWIsRUFBcUM7QUFBQ0ksVUFBUUgsQ0FBUixFQUFVO0FBQUNFLG1CQUFhRixDQUFiO0FBQWU7O0FBQTNCLENBQXJDLEVBQWtFLENBQWxFO0FBQXFFLElBQUkrTCxRQUFKO0FBQWFsTSxPQUFPQyxLQUFQLENBQWFDLFFBQVEsc0JBQVIsQ0FBYixFQUE2QztBQUFDZ00sV0FBUy9MLENBQVQsRUFBVztBQUFDK0wsZUFBUy9MLENBQVQ7QUFBVzs7QUFBeEIsQ0FBN0MsRUFBdUUsQ0FBdkU7QUFJMVYsTUFBTXFSLHFCQUFxQixJQUFJMUssZUFBSixDQUFvQjtBQUNwRDVFLFFBQU0sNkJBRDhDO0FBRXBEa0UsWUFBVSxJQUFJL0YsWUFBSixHQUFtQjBHLFNBQW5CLENBQTZCO0FBQUVDLFdBQU87QUFBVCxHQUE3QixDQUYwQzs7QUFHcERDLFFBQU07QUFDSixXQUFPaUYsU0FBUzVLLElBQVQsQ0FBYyxFQUFkLEVBQWtCRCxLQUFsQixFQUFQO0FBQ0Q7O0FBTG1ELENBQXBCLENBQTNCO0FBUUEsTUFBTW9RLDRCQUE0QixJQUFJM0ssZUFBSixDQUFvQjtBQUMzRDVFLFFBQU0sb0NBRHFEO0FBRTNEa0UsWUFBVSxJQUFJL0YsWUFBSixDQUFpQjtBQUN6Qm1FLFlBQVE7QUFBRUosWUFBTUs7QUFBUjtBQURpQixHQUFqQixFQUVQc0MsU0FGTyxDQUVHO0FBQUVDLFdBQU87QUFBVCxHQUZILENBRmlEOztBQUszREMsTUFBSTtBQUFFekM7QUFBRixHQUFKLEVBQWdCO0FBQ2QsUUFBSSxDQUFDLEtBQUswQyxZQUFWLEVBQXdCO0FBQ3RCLFlBQU15SyxTQUFTekYsU0FBU2xLLE9BQVQsQ0FBaUI7QUFBRXdDO0FBQUYsT0FBakIsQ0FBZjtBQUNBLGFBQVFtTixNQUFELEdBQVdBLE9BQU9qQixvQkFBbEIsR0FBeUMsSUFBaEQ7QUFDRDs7QUFDRCxXQUFPLElBQVA7QUFDRDs7QUFYMEQsQ0FBcEIsQ0FBbEM7QUFjQSxNQUFNZ0IsWUFBWSxJQUFJNUssZUFBSixDQUFvQjtBQUMzQzVFLFFBQU0sb0JBRHFDO0FBRTNDa0UsWUFBVSxJQUFJL0YsWUFBSixDQUFpQixFQUFqQixFQUFxQjBHLFNBQXJCLENBQStCO0FBQUVDLFdBQU87QUFBVCxHQUEvQixDQUZpQzs7QUFHM0NDLFFBQU07QUFDSixRQUFJLENBQUMsS0FBS0MsWUFBVixFQUF3QjtBQUN0QixZQUFNMEssV0FBVzFGLFNBQVM1SyxJQUFULENBQWMsRUFBZCxDQUFqQjtBQUNBLFlBQU1tTCxTQUFTbUYsU0FBUy9PLEdBQVQsQ0FBYWdQLE9BQU9BLElBQUlyTixNQUF4QixDQUFmO0FBQ0EsYUFBT2lJLE1BQVA7QUFDRDs7QUFDRCxXQUFPLElBQVA7QUFDRDs7QUFWMEMsQ0FBcEIsQ0FBbEIsQzs7Ozs7Ozs7Ozs7QUMxQlB6TSxPQUFPQyxLQUFQLENBQWFDLFFBQVEseUJBQVIsQ0FBYjtBQUFpREYsT0FBT0MsS0FBUCxDQUFhQyxRQUFRLGdDQUFSLENBQWIsRTs7Ozs7Ozs7Ozs7QUNBakRGLE9BQU8rRCxNQUFQLENBQWM7QUFBQytOLGVBQVksTUFBSUE7QUFBakIsQ0FBZDtBQUE2QyxJQUFJelIsWUFBSjtBQUFpQkwsT0FBT0MsS0FBUCxDQUFhQyxRQUFRLGNBQVIsQ0FBYixFQUFxQztBQUFDSSxVQUFRSCxDQUFSLEVBQVU7QUFBQ0UsbUJBQWFGLENBQWI7QUFBZTs7QUFBM0IsQ0FBckMsRUFBa0UsQ0FBbEU7QUFBcUUsSUFBSU0sY0FBSjtBQUFtQlQsT0FBT0MsS0FBUCxDQUFhQyxRQUFRLDJCQUFSLENBQWIsRUFBa0Q7QUFBQ0ksVUFBUUgsQ0FBUixFQUFVO0FBQUNNLHFCQUFlTixDQUFmO0FBQWlCOztBQUE3QixDQUFsRCxFQUFpRixDQUFqRjtBQUFvRixJQUFJOEQsTUFBSjtBQUFXakUsT0FBT0MsS0FBUCxDQUFhQyxRQUFRLCtCQUFSLENBQWIsRUFBc0Q7QUFBQytELFNBQU85RCxDQUFQLEVBQVM7QUFBQzhELGFBQU85RCxDQUFQO0FBQVM7O0FBQXBCLENBQXRELEVBQTRFLENBQTVFO0FBQStFLElBQUk2RCxTQUFKO0FBQWNoRSxPQUFPQyxLQUFQLENBQWFDLFFBQVEsc0NBQVIsQ0FBYixFQUE2RDtBQUFDOEQsWUFBVTdELENBQVYsRUFBWTtBQUFDNkQsZ0JBQVU3RCxDQUFWO0FBQVk7O0FBQTFCLENBQTdELEVBQXlGLENBQXpGO0FBQTRGLElBQUk4TCxZQUFKO0FBQWlCak0sT0FBT0MsS0FBUCxDQUFhQyxRQUFRLDJDQUFSLENBQWIsRUFBa0U7QUFBQytMLGVBQWE5TCxDQUFiLEVBQWU7QUFBQzhMLG1CQUFhOUwsQ0FBYjtBQUFlOztBQUFoQyxDQUFsRSxFQUFvRyxDQUFwRztBQUF1RyxJQUFJK0wsUUFBSjtBQUFhbE0sT0FBT0MsS0FBUCxDQUFhQyxRQUFRLG9DQUFSLENBQWIsRUFBMkQ7QUFBQ2dNLFdBQVMvTCxDQUFULEVBQVc7QUFBQytMLGVBQVMvTCxDQUFUO0FBQVc7O0FBQXhCLENBQTNELEVBQXFGLENBQXJGO0FBQXdGLElBQUk0UixNQUFKO0FBQVcvUixPQUFPQyxLQUFQLENBQWFDLFFBQVEsK0JBQVIsQ0FBYixFQUFzRDtBQUFDNlIsU0FBTzVSLENBQVAsRUFBUztBQUFDNFIsYUFBTzVSLENBQVA7QUFBUzs7QUFBcEIsQ0FBdEQsRUFBNEUsQ0FBNUU7QUFBK0UsSUFBSTZSLFlBQUo7QUFBaUJoUyxPQUFPQyxLQUFQLENBQWFDLFFBQVEsb0NBQVIsQ0FBYixFQUEyRDtBQUFDOFIsZUFBYTdSLENBQWIsRUFBZTtBQUFDNlIsbUJBQWE3UixDQUFiO0FBQWU7O0FBQWhDLENBQTNELEVBQTZGLENBQTdGOztBQVN0dkI7QUFFQSxNQUFNOFIscUJBQU4sU0FBb0N4UixjQUFwQyxDQUFtRDtBQUVqRDs7O0FBR0FDLGdCQUFjO0FBQ1osVUFBTSxjQUFOLEVBQXNCLElBQUlMLFlBQUosQ0FBaUI7QUFDckM2UixvQkFBYzNOLE1BRHVCO0FBRXJDNE4sMEJBQW9CNU4sTUFGaUI7QUFHckM2Tix3QkFBa0I3TixNQUhtQjtBQUlyQzhOLDhCQUF3QjlOLE1BSmE7QUFLckMrTiwwQkFBb0IvTixNQUxpQjtBQU1yQ2dPLGdDQUEwQmhPLE1BTlc7QUFPckNpTyxvQkFBY2pPLE1BUHVCO0FBUXJDa08sMEJBQW9CbE8sTUFSaUI7QUFTckNtTyx1QkFBaUJuTyxNQVRvQjtBQVVyQ29PLG1CQUFhcE8sTUFWd0I7QUFXckNnSixpQkFBV3RDLElBWDBCO0FBWXJDMkgsdUJBQWlCO0FBQUV4TyxjQUFNeUQ7QUFBUixPQVpvQjtBQWFyQywyQkFBcUI7QUFBRXpELGNBQU1ZLE1BQVI7QUFBZ0I0TCxrQkFBVTtBQUExQixPQWJnQjtBQWNyQ2lDLGNBQVE7QUFBRXpPLGNBQU15RDtBQUFSLE9BZDZCO0FBZXJDLGtCQUFZO0FBQUV6RCxjQUFNWSxNQUFSO0FBQWdCNEwsa0JBQVU7QUFBMUI7QUFmeUIsS0FBakIsQ0FBdEI7QUFpQkQ7QUFFRDs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBZ0JBek4sU0FBTztBQUFFK08sZ0JBQUY7QUFBZ0JDLHNCQUFoQjtBQUFvQ0Msb0JBQXBDO0FBQXNEQywwQkFBdEQ7QUFBOEVDLHNCQUE5RTtBQUNFQyw0QkFERjtBQUM0QkcsbUJBRDVCO0FBQzZDRixnQkFEN0M7QUFDMkRDLHNCQUQzRDtBQUMrRUUsZUFEL0U7QUFFRUMsbUJBRkY7QUFFbUJDO0FBRm5CLEdBQVAsRUFFb0M7QUFDbEMsVUFBTW5RLFFBQVEsS0FBSzFCLFdBQUwsQ0FBaUI0RSxNQUFqQixDQUF3QjtBQUFFc00sa0JBQUY7QUFBZ0JFLHNCQUFoQjtBQUFrQ0Usd0JBQWxDO0FBQXNESSxxQkFBdEQ7QUFDcENGLGtCQURvQztBQUN0QkcsaUJBRHNCO0FBQ1RwRixpQkFBVyxJQUFJdEMsSUFBSixFQURGO0FBQ2MySCxxQkFEZDtBQUMrQkMsWUFEL0I7QUFFdENWLHdCQUZzQztBQUVsQkUsNEJBRmtCO0FBRU1FLDhCQUZOO0FBRWdDRTtBQUZoQyxLQUF4QixDQUFkOztBQUdBLFdBQU8vUCxLQUFQO0FBQ0Q7QUFFRDs7Ozs7OztBQUtBRCxVQUFRQyxLQUFSLEVBQWU7QUFDYjtBQUNBLFVBQU1JLE1BQU0sS0FBS0MsT0FBTCxDQUFhTCxLQUFiLENBQVo7QUFDQSxVQUFNd1AsZUFBZXBQLElBQUlvUCxZQUF6QjtBQUNBLFVBQU1DLHFCQUFxQnJQLElBQUlxUCxrQkFBL0I7QUFDQSxVQUFNQyxtQkFBbUJ0UCxJQUFJc1AsZ0JBQTdCO0FBQ0EsVUFBTUMseUJBQXlCdlAsSUFBSXVQLHNCQUFuQztBQUNBLFVBQU1DLHFCQUFxQnhQLElBQUl3UCxrQkFBL0I7QUFDQSxVQUFNQywyQkFBMkJ6UCxJQUFJeVAsd0JBQXJDO0FBQ0EsVUFBTUMsZUFBZTFQLElBQUkwUCxZQUF6QjtBQUNBLFVBQU1DLHFCQUFxQjNQLElBQUkyUCxrQkFBL0I7QUFDQSxVQUFNQyxrQkFBa0I1UCxJQUFJNFAsZUFBNUI7QUFDQSxVQUFNQyxjQUFjN1AsSUFBSTZQLFdBQXhCO0FBQ0EsVUFBTXBGLFlBQVl6SyxJQUFJeUssU0FBdEI7QUFDQSxVQUFNcUYsa0JBQWtCOVAsSUFBSThQLGVBQTVCO0FBQ0EsV0FBTztBQUFFVixrQkFBRjtBQUFnQkUsc0JBQWhCO0FBQWtDRSx3QkFBbEM7QUFBc0RJLHFCQUF0RDtBQUF1RUYsa0JBQXZFO0FBQXFGRyxpQkFBckY7QUFDTHBGLGVBREs7QUFDTXFGLHFCQUROO0FBQ3VCVCx3QkFEdkI7QUFDMkNFLDRCQUQzQztBQUNtRUUsOEJBRG5FO0FBRVBFO0FBRk8sS0FBUDtBQUdBO0FBQ0Q7QUFFRDs7Ozs7O0FBSUF6UCxtQkFBaUI7QUFBRTtBQUNqQixVQUFNNkMsV0FBVyxFQUFqQjtBQUNBLFdBQU9BLFFBQVA7QUFDRDtBQUVEOzs7Ozs7Ozs7OztBQVNBaU4sa0JBQWdCQyxLQUFoQixFQUF1QjtBQUFFO0FBQ3ZCLFVBQU1DLGdCQUFnQmpCLE9BQU9rQixXQUFQLENBQW1CRixLQUFuQixDQUF0QjtBQUNBLFVBQU1HLGFBQWFGLGdCQUFnQkEsY0FBYzVHLFlBQTlCLEdBQTZDLENBQWhFO0FBQ0EsVUFBTStHLGVBQWVwQixPQUFPcUIsV0FBUCxDQUFtQkwsS0FBbkIsQ0FBckI7QUFDQSxVQUFNTSxZQUFZRixlQUFlQSxhQUFhL0csWUFBNUIsR0FBMkMsQ0FBN0Q7QUFDQSxVQUFNa0gsY0FBY3ZCLE9BQU93QixXQUFQLENBQW1CUixLQUFuQixDQUFwQjtBQUNBLFdBQU87QUFBRUEsV0FBRjtBQUFTRyxnQkFBVDtBQUFxQkcsZUFBckI7QUFBZ0NDO0FBQWhDLEtBQVA7QUFDRDtBQUVEOzs7Ozs7QUFJQUUsbUJBQWlCO0FBQ2YsVUFBTVgsU0FBUyxFQUFmO0FBQ0FBLFdBQU92TSxJQUFQLENBQVk7QUFBRWxDLFlBQU0sU0FBUjtBQUFtQjhCLGFBQU8sQ0FBMUI7QUFBNkJoRSxZQUFNLE9BQW5DO0FBQTRDdVIsWUFBTSxjQUFsRDtBQUFrRUMsYUFBTztBQUF6RSxLQUFaO0FBQ0FiLFdBQU92TSxJQUFQLENBQVk7QUFBRWxDLFlBQU0sU0FBUjtBQUFtQjhCLGFBQU8sQ0FBMUI7QUFBNkJoRSxZQUFNLE9BQW5DO0FBQTRDdVIsWUFBTSxjQUFsRDtBQUFrRUMsYUFBTztBQUF6RSxLQUFaO0FBQ0FiLFdBQU92TSxJQUFQLENBQVk7QUFBRWxDLFlBQU0sU0FBUjtBQUFtQjhCLGFBQU8sQ0FBMUI7QUFBNkJoRSxZQUFNLE9BQW5DO0FBQTRDdVIsWUFBTSxjQUFsRDtBQUFrRUMsYUFBTztBQUF6RSxLQUFaO0FBQ0FiLFdBQU92TSxJQUFQLENBQVk7QUFBRWxDLFlBQU0sU0FBUjtBQUFtQjhCLGFBQU8sQ0FBMUI7QUFBNkJoRSxZQUFNLFFBQW5DO0FBQTZDdVIsWUFBTSxjQUFuRDtBQUFtRUMsYUFBTztBQUExRSxLQUFaO0FBRUFiLFdBQU92TSxJQUFQLENBQVk7QUFBRWxDLFlBQU0sS0FBUjtBQUFlOEIsYUFBTyxDQUF0QjtBQUF5QmhFLFlBQU0sUUFBL0I7QUFBeUN1UixZQUFNLGNBQS9DO0FBQStEQyxhQUFPO0FBQXRFLEtBQVo7QUFDQWIsV0FBT3ZNLElBQVAsQ0FBWTtBQUFFbEMsWUFBTSxLQUFSO0FBQWU4QixhQUFPLENBQXRCO0FBQXlCaEUsWUFBTSxRQUEvQjtBQUF5Q3VSLFlBQU0sTUFBL0M7QUFBdURDLGFBQU87QUFBOUQsS0FBWjtBQUNBYixXQUFPdk0sSUFBUCxDQUFZO0FBQUVsQyxZQUFNLEtBQVI7QUFBZThCLGFBQU8sQ0FBdEI7QUFBeUJoRSxZQUFNLFFBQS9CO0FBQXlDdVIsWUFBTSxvQkFBL0M7QUFBcUVDLGFBQU87QUFBNUUsS0FBWjtBQUNBYixXQUFPdk0sSUFBUCxDQUFZO0FBQUVsQyxZQUFNLEtBQVI7QUFBZThCLGFBQU8sQ0FBdEI7QUFBeUJoRSxZQUFNLFFBQS9CO0FBQXlDdVIsWUFBTSxjQUEvQztBQUErREMsYUFBTztBQUF0RSxLQUFaO0FBQ0FiLFdBQU92TSxJQUFQLENBQVk7QUFBRWxDLFlBQU0sS0FBUjtBQUFlOEIsYUFBTyxDQUF0QjtBQUF5QmhFLFlBQU0sUUFBL0I7QUFBeUN1UixZQUFNLGNBQS9DO0FBQStEQyxhQUFPO0FBQXRFLEtBQVo7QUFDQSxXQUFPYixNQUFQO0FBQ0Q7O0FBRURjLGlCQUFlO0FBQ2I7QUFDQSxVQUFNekIsZUFBZWpPLE9BQU81QyxLQUFQLEVBQXJCO0FBQ0EsVUFBTThRLHFCQUFxQmxPLE9BQU8xQyxVQUFQLENBQWtCLGlDQUFsQixDQUEzQjtBQUNBLFVBQU02USxtQkFBbUJwTyxVQUFVM0MsS0FBVixFQUF6QjtBQUNBLFVBQU1nUix5QkFBeUJyTyxVQUFVekMsVUFBVixDQUFxQiwwQkFBckIsQ0FBL0I7QUFDQSxVQUFNK1EscUJBQXFCckcsYUFBYTVLLEtBQWIsRUFBM0I7QUFDQSxVQUFNa1IsMkJBQTJCdEcsYUFBYTFLLFVBQWIsQ0FBd0IsY0FBeEIsQ0FBakM7QUFDQSxVQUFNbVIsa0JBQWtCeEcsU0FBUzdLLEtBQVQsRUFBeEI7QUFDQSxVQUFNbVIsZUFBZVQsT0FBTzFRLEtBQVAsRUFBckI7QUFDQSxVQUFNb1IscUJBQXFCVixPQUFPeFEsVUFBUCxDQUFrQixjQUFsQixDQUEzQjtBQUNBLFVBQU1vUixjQUFjWCxhQUFhM1EsS0FBYixFQUFwQixDQVhhLENBVzZCOztBQUMxQyxVQUFNdVIsa0JBQWtCMUcsU0FBU29GLFVBQVQsR0FBc0J6TyxHQUF0QixDQUEwQmtRLFNBQVMsS0FBS0QsZUFBTCxDQUFxQkMsS0FBckIsQ0FBbkMsQ0FBeEI7QUFDQSxVQUFNRixTQUFTLEtBQUtXLGNBQUwsRUFBZixDQWJhLENBZWI7O0FBQ0EsVUFBTW5TLFFBQVEsS0FBS0wsV0FBTCxDQUFpQk0sSUFBakIsR0FBd0JELEtBQXhCLEVBQWQ7O0FBQ0EsUUFBSUEsUUFBUSxDQUFaLEVBQWU7QUFDYjtBQUNBLFlBQU15QixNQUFNLEtBQUs5QixXQUFMLENBQWlCZ0IsT0FBakIsRUFBWjs7QUFDQSxXQUFLaEIsV0FBTCxDQUFpQjZDLE1BQWpCLENBQXdCO0FBQUUxQixhQUFLO0FBQUU0RyxlQUFLakcsSUFBSVg7QUFBWDtBQUFQLE9BQXhCO0FBQ0QsS0FKRCxNQUlPLElBQUlkLFFBQVEsQ0FBWixFQUFlO0FBQ3BCO0FBQ0E7QUFDQSxhQUFPLEtBQUs4QixNQUFMLENBQVk7QUFBRStPLG9CQUFGO0FBQWdCRSx3QkFBaEI7QUFBa0NFLDBCQUFsQztBQUFzREksdUJBQXREO0FBQXVFRixvQkFBdkU7QUFBcUZHLG1CQUFyRjtBQUFrR0MsdUJBQWxHO0FBQW1IQyxjQUFuSDtBQUEySFYsMEJBQTNIO0FBQStJRSw4QkFBL0k7QUFBdUtFLGdDQUF2SztBQUNuQkU7QUFEbUIsT0FBWixDQUFQO0FBRUQsS0ExQlksQ0E0QmI7OztBQUNBLFVBQU1tQixpQkFBaUIsS0FBSzVTLFdBQUwsQ0FBaUJnQixPQUFqQixFQUF2Qjs7QUFDQSxXQUFPNFIsa0JBQWtCLEtBQUs1UyxXQUFMLENBQWlCb0IsTUFBakIsQ0FBd0J3UixlQUFlelIsR0FBdkMsRUFBNEM7QUFDbkU2TyxZQUFNO0FBQUVrQixvQkFBRjtBQUFnQkUsd0JBQWhCO0FBQWtDRSwwQkFBbEM7QUFBc0RJLHVCQUF0RDtBQUF1RUYsb0JBQXZFO0FBQXFGRyxtQkFBckY7QUFDSnBGLG1CQUFXLElBQUl0QyxJQUFKLEVBRFA7QUFDbUIySCx1QkFEbkI7QUFDb0NDLGNBRHBDO0FBQzRDViwwQkFENUM7QUFDZ0VFLDhCQURoRTtBQUVKRSxnQ0FGSTtBQUVzQkU7QUFGdEI7QUFENkQsS0FBNUMsQ0FBekI7QUFLRDs7QUE3SmdEO0FBZ0tuRDs7Ozs7O0FBSU8sTUFBTVgsY0FBYyxJQUFJRyxxQkFBSixFQUFwQixDOzs7Ozs7Ozs7OztBQy9LUGpTLE9BQU8rRCxNQUFQLENBQWM7QUFBQ2dPLFVBQU8sTUFBSUE7QUFBWixDQUFkO0FBQW1DLElBQUloUyxNQUFKO0FBQVdDLE9BQU9DLEtBQVAsQ0FBYUMsUUFBUSxlQUFSLENBQWIsRUFBc0M7QUFBQ0gsU0FBT0ksQ0FBUCxFQUFTO0FBQUNKLGFBQU9JLENBQVA7QUFBUzs7QUFBcEIsQ0FBdEMsRUFBNEQsQ0FBNUQ7QUFBK0QsSUFBSUMsS0FBSjtBQUFVSixPQUFPQyxLQUFQLENBQWFDLFFBQVEsY0FBUixDQUFiLEVBQXFDO0FBQUNFLFFBQU1ELENBQU4sRUFBUTtBQUFDQyxZQUFNRCxDQUFOO0FBQVE7O0FBQWxCLENBQXJDLEVBQXlELENBQXpEO0FBQTRELElBQUlFLFlBQUo7QUFBaUJMLE9BQU9DLEtBQVAsQ0FBYUMsUUFBUSxjQUFSLENBQWIsRUFBcUM7QUFBQ0ksVUFBUUgsQ0FBUixFQUFVO0FBQUNFLG1CQUFhRixDQUFiO0FBQWU7O0FBQTNCLENBQXJDLEVBQWtFLENBQWxFO0FBQXFFLElBQUlpSCxLQUFKO0FBQVVwSCxPQUFPQyxLQUFQLENBQWFDLFFBQVEsY0FBUixDQUFiLEVBQXFDO0FBQUNrSCxRQUFNakgsQ0FBTixFQUFRO0FBQUNpSCxZQUFNakgsQ0FBTjtBQUFROztBQUFsQixDQUFyQyxFQUF5RCxDQUF6RDtBQUE0RCxJQUFJTSxjQUFKO0FBQW1CVCxPQUFPQyxLQUFQLENBQWFDLFFBQVEsMkJBQVIsQ0FBYixFQUFrRDtBQUFDSSxVQUFRSCxDQUFSLEVBQVU7QUFBQ00scUJBQWVOLENBQWY7QUFBaUI7O0FBQTdCLENBQWxELEVBQWlGLENBQWpGO0FBQW9GLElBQUkrTCxRQUFKO0FBQWFsTSxPQUFPQyxLQUFQLENBQWFDLFFBQVEsaUNBQVIsQ0FBYixFQUF3RDtBQUFDZ00sV0FBUy9MLENBQVQsRUFBVztBQUFDK0wsZUFBUy9MLENBQVQ7QUFBVzs7QUFBeEIsQ0FBeEQsRUFBa0YsQ0FBbEY7QUFBcUYsSUFBSStELGdCQUFKO0FBQXFCbEUsT0FBT0MsS0FBUCxDQUFhQyxRQUFRLHFCQUFSLENBQWIsRUFBNEM7QUFBQ2dFLG1CQUFpQi9ELENBQWpCLEVBQW1CO0FBQUMrRCx1QkFBaUIvRCxDQUFqQjtBQUFtQjs7QUFBeEMsQ0FBNUMsRUFBc0YsQ0FBdEY7O0FBUTdpQixNQUFNMFQsZ0JBQU4sU0FBK0JwVCxjQUEvQixDQUE4QztBQUU1Qzs7O0FBR0FDLGdCQUFjO0FBQ1osVUFBTSxRQUFOLEVBQWdCLElBQUlMLFlBQUosQ0FBaUI7QUFDL0I4QixXQUFLO0FBQUVpQyxjQUFNaEUsTUFBTWlFO0FBQWQsT0FEMEI7QUFFL0JHLGNBQVE7QUFBRUosY0FBTUs7QUFBUixPQUZ1QjtBQUcvQjJILG9CQUFjO0FBQUVoSSxjQUFNRztBQUFSLE9BSGlCO0FBSS9COEgsZUFBUztBQUFFakksY0FBTVk7QUFBUixPQUpzQjtBQUsvQixxQkFBZTtBQUFFWixjQUFNRztBQUFSLE9BTGdCO0FBTS9CLHFCQUFlO0FBQUVILGNBQU1HO0FBQVIsT0FOZ0I7QUFPL0IseUJBQW1CO0FBQUVILGNBQU1HO0FBQVIsT0FQWTtBQVEvQitILGlCQUFXO0FBQUVsSSxjQUFNWTtBQUFSLE9BUm9CO0FBUy9CLHVCQUFpQjtBQUFFWixjQUFNRztBQUFSLE9BVGM7QUFVL0IsdUJBQWlCO0FBQUVILGNBQU1HO0FBQVIsT0FWYztBQVcvQiwyQkFBcUI7QUFBRUgsY0FBTUc7QUFBUixPQVhVO0FBWS9CTSxXQUFLO0FBQUVULGNBQU1ZLE1BQVI7QUFBZ0JDLGtCQUFVO0FBQTFCLE9BWjBCO0FBYS9CLGlCQUFXO0FBQUViLGNBQU1HO0FBQVIsT0Fib0I7QUFjL0IsaUJBQVc7QUFBRUgsY0FBTUc7QUFBUixPQWRvQjtBQWUvQixxQkFBZTtBQUFFSCxjQUFNRztBQUFSO0FBZmdCLEtBQWpCLENBQWhCO0FBa0JBLFNBQUtZLGdCQUFMLEdBQXdCO0FBQ3RCMk8seUJBQW1CLG1CQURHO0FBRXRCQywyQkFBcUI7QUFGQyxLQUF4Qjs7QUFJQSxRQUFJaFUsT0FBT3NGLE1BQVgsRUFBbUI7QUFDakIsV0FBS3JFLFdBQUwsQ0FBaUJzRSxhQUFqQixHQUFpQ0MsV0FBakMsQ0FBNkM7QUFBRTZHLHNCQUFjLENBQWhCO0FBQW1CNUgsZ0JBQVE7QUFBM0IsT0FBN0MsRUFBNkU7QUFBRWdCLG9CQUFZO0FBQWQsT0FBN0U7QUFDRDtBQUNGO0FBRUQ7Ozs7Ozs7Ozs7O0FBU0FyQyxTQUFPO0FBQUVxQixVQUFGO0FBQVU0SCxnQkFBVjtBQUF3QkMsV0FBeEI7QUFBaUNDLGFBQWpDO0FBQTRDekg7QUFBNUMsR0FBUCxFQUEwRDtBQUN4RCxVQUFNbkMsUUFBUSxLQUFLMUIsV0FBTCxDQUFpQjRFLE1BQWpCLENBQXdCO0FBQUVwQixZQUFGO0FBQVU0SCxrQkFBVjtBQUF3QkMsYUFBeEI7QUFBaUNDLGVBQWpDO0FBQTRDekg7QUFBNUMsS0FBeEIsQ0FBZDs7QUFDQSxXQUFPbkMsS0FBUDtBQUNEO0FBRUQ7Ozs7Ozs7QUFLQXVRLGNBQVl6TyxNQUFaLEVBQW9CO0FBQ2xCLFdBQU8sS0FBS3hELFdBQUwsQ0FBaUJnQixPQUFqQixDQUF5QjtBQUFFd0MsWUFBRjtBQUFVNEgsb0JBQWM7QUFBRTRILGFBQUs7QUFBUDtBQUF4QixLQUF6QixFQUErRDtBQUFFL0ssWUFBTTtBQUFFbUQsc0JBQWM7QUFBaEI7QUFBUixLQUEvRCxDQUFQO0FBQ0Q7QUFFRDs7Ozs7OztBQUtBZ0gsY0FBWTVPLE1BQVosRUFBb0I7QUFDbEIsV0FBTyxLQUFLeEQsV0FBTCxDQUFpQmdCLE9BQWpCLENBQXlCO0FBQUV3QztBQUFGLEtBQXpCLEVBQXFDO0FBQUV5RSxZQUFNO0FBQUVtRCxzQkFBYyxDQUFDO0FBQWpCO0FBQVIsS0FBckMsQ0FBUDtBQUNEO0FBRUQ7Ozs7Ozs7QUFLQW1ILGNBQVkvTyxNQUFaLEVBQW9CO0FBQ2xCLFdBQU8sS0FBS3hELFdBQUwsQ0FBaUJNLElBQWpCLENBQXNCO0FBQUVrRDtBQUFGLEtBQXRCLEVBQWtDbkQsS0FBbEMsRUFBUDtBQUNEO0FBRUQ7Ozs7Ozs7QUFLQW9CLFVBQVFDLEtBQVIsRUFBZTtBQUNiO0FBQ0EsVUFBTUksTUFBTSxLQUFLQyxPQUFMLENBQWFMLEtBQWIsQ0FBWjtBQUNBLFVBQU04QixTQUFTMUIsSUFBSTBCLE1BQW5CO0FBQ0EsVUFBTTRILGVBQWV0SixJQUFJc0osWUFBekI7QUFDQSxVQUFNQyxVQUFVdkosSUFBSXVKLE9BQXBCO0FBQ0EsVUFBTUMsWUFBWXhKLElBQUl3SixTQUF0QjtBQUNBLFVBQU16SCxNQUFNL0IsSUFBSStCLEdBQWhCO0FBRUEsV0FBTztBQUFFTCxZQUFGO0FBQVU0SCxrQkFBVjtBQUF3QkMsYUFBeEI7QUFBaUNDLGVBQWpDO0FBQTRDekg7QUFBNUMsS0FBUDtBQUNBO0FBQ0Q7O0FBRUQ3QixtQkFBaUI7QUFDZixVQUFNNkMsV0FBVyxFQUFqQjtBQUNBLFVBQU1DLGFBQWEsS0FBS3pFLEtBQUwsRUFBbkI7QUFDQSxVQUFNMEUsb0JBQW9CLEtBQUszRSxTQUFMLEdBQWlCNEUsWUFBakIsQ0FBOEIsaUJBQTlCLENBQTFCO0FBQ0EsVUFBTUMsS0FBSy9CLGlCQUFpQjRCLFVBQWpCLEVBQTZCLElBQTdCLEVBQW9DLFlBQVcsS0FBS2hGLGVBQWdCLGVBQXBFLENBQVgsQ0FKZSxDQU1mOztBQUNBLFVBQU0yTCxTQUFTUCxTQUFTNUssSUFBVCxHQUFnQnVCLEdBQWhCLENBQW9CQyxPQUFPQSxJQUFJMEIsTUFBL0IsQ0FBZjtBQUVBLFNBQUtsRCxJQUFMLEdBQVlxQyxPQUFaLENBQW9CLENBQUNiLEdBQUQsRUFBTW9ELEtBQU4sS0FBZ0I7QUFDbENELFNBQUdFLFNBQUgsQ0FBYUQsS0FBYixFQURrQyxDQUNiO0FBRXJCOztBQUNBSCx3QkFBa0JLLFFBQWxCLENBQTJCdEQsR0FBM0I7O0FBQ0EsVUFBSSxDQUFDaUQsa0JBQWtCTSxPQUFsQixFQUFMLEVBQWtDO0FBQ2hDO0FBQ0FSLGlCQUFTUyxJQUFULENBQWUsNkNBQTRDeEQsSUFBSVgsR0FBSSxtQkFBa0JvRSxLQUFLQyxTQUFMLENBQWVULGtCQUFrQlUsV0FBbEIsRUFBZixFQUFnRCxJQUFoRCxFQUFzRCxDQUF0RCxDQUF5RCxHQUE5STtBQUNEOztBQUNEVix3QkFBa0JXLGVBQWxCLEdBVGtDLENBV2xDOztBQUNBLFVBQUksQ0FBQytGLE9BQU9DLFFBQVAsQ0FBZ0I1SixJQUFJMEIsTUFBcEIsQ0FBTCxFQUFrQztBQUNoQ3FCLGlCQUFTUyxJQUFULENBQWUseURBQXdEeEQsSUFBSTBCLE1BQU8sWUFBVzFCLElBQUlYLEdBQUksR0FBckc7QUFDRDtBQUNGLEtBZkQ7QUFpQkE4RCxPQUFHVSxhQUFIO0FBQ0EsV0FBT2QsUUFBUDtBQUNEO0FBRUQ7Ozs7O0FBR0F2RCxZQUFVO0FBQUU7QUFDVixRQUFJdkMsT0FBT3dDLFFBQVgsRUFBcUI7QUFDbkIsWUFBTWdHLE9BQU8sSUFBYjtBQUVBeEksYUFBT3VDLE9BQVAsQ0FBZSxLQUFLNkMsZ0JBQUwsQ0FBc0IyTyxpQkFBckMsRUFBd0QsVUFBVTtBQUFFRztBQUFGLE9BQVYsRUFBeUI7QUFDL0U3TSxjQUFNNk0sU0FBTixFQUFpQjFQLE1BQWpCO0FBRUEsY0FBTTJQLFNBQVMzTCxLQUFLakgsSUFBTCxDQUFVLEVBQVYsRUFBYztBQUFFMkgsZ0JBQU07QUFBRW1ELDBCQUFjLENBQUM7QUFBakIsV0FBUjtBQUE4QmxELGlCQUFPK0s7QUFBckMsU0FBZCxDQUFmO0FBQ0EsZUFBT0MsTUFBUDtBQUNELE9BTEQ7QUFNRDtBQUNGOztBQXhJMkM7QUEySTlDOzs7Ozs7QUFJTyxNQUFNbkMsU0FBUyxJQUFJOEIsZ0JBQUosRUFBZixDOzs7Ozs7Ozs7OztBQ3ZKUDdULE9BQU8rRCxNQUFQLENBQWM7QUFBQ29RLG9CQUFpQixNQUFJQSxnQkFBdEI7QUFBdUNDLDJCQUF3QixNQUFJQSx1QkFBbkU7QUFBMkZDLHNCQUFtQixNQUFJQSxrQkFBbEg7QUFBcUlDLGVBQVksTUFBSUE7QUFBckosQ0FBZDtBQUFpTCxJQUFJeE4sZUFBSjtBQUFvQjlHLE9BQU9DLEtBQVAsQ0FBYUMsUUFBUSw2QkFBUixDQUFiLEVBQW9EO0FBQUM0RyxrQkFBZ0IzRyxDQUFoQixFQUFrQjtBQUFDMkcsc0JBQWdCM0csQ0FBaEI7QUFBa0I7O0FBQXRDLENBQXBELEVBQTRGLENBQTVGO0FBQStGLElBQUlFLFlBQUo7QUFBaUJMLE9BQU9DLEtBQVAsQ0FBYUMsUUFBUSxjQUFSLENBQWIsRUFBcUM7QUFBQ0ksVUFBUUgsQ0FBUixFQUFVO0FBQUNFLG1CQUFhRixDQUFiO0FBQWU7O0FBQTNCLENBQXJDLEVBQWtFLENBQWxFO0FBQXFFLElBQUlLLE1BQUo7QUFBV1IsT0FBT0MsS0FBUCxDQUFhQyxRQUFRLFFBQVIsQ0FBYixFQUErQjtBQUFDSSxVQUFRSCxDQUFSLEVBQVU7QUFBQ0ssYUFBT0wsQ0FBUDtBQUFTOztBQUFyQixDQUEvQixFQUFzRCxDQUF0RDs7QUFBeUQsSUFBSUksQ0FBSjs7QUFBTVAsT0FBT0MsS0FBUCxDQUFhQyxRQUFRLFFBQVIsQ0FBYixFQUErQjtBQUFDSSxVQUFRSCxDQUFSLEVBQVU7QUFBQ0ksUUFBRUosQ0FBRjtBQUFJOztBQUFoQixDQUEvQixFQUFpRCxDQUFqRDtBQUFvRCxJQUFJcUosUUFBSjtBQUFheEosT0FBT0MsS0FBUCxDQUFhQyxRQUFRLFlBQVIsQ0FBYixFQUFtQztBQUFDc0osV0FBU3JKLENBQVQsRUFBVztBQUFDcUosZUFBU3JKLENBQVQ7QUFBVzs7QUFBeEIsQ0FBbkMsRUFBNkQsQ0FBN0Q7QUFBZ0UsSUFBSTRSLE1BQUo7QUFBVy9SLE9BQU9DLEtBQVAsQ0FBYUMsUUFBUSxvQkFBUixDQUFiLEVBQTJDO0FBQUM2UixTQUFPNVIsQ0FBUCxFQUFTO0FBQUM0UixhQUFPNVIsQ0FBUDtBQUFTOztBQUFwQixDQUEzQyxFQUFpRSxDQUFqRTtBQU96a0IsTUFBTWdVLG1CQUFtQixJQUFJck4sZUFBSixDQUFvQjtBQUNsRDVFLFFBQU0seUJBRDRDO0FBRWxEa0UsWUFBVSxJQUFJL0YsWUFBSixHQUFtQjBHLFNBQW5CLENBQTZCO0FBQUVDLFdBQU87QUFBVCxHQUE3QixDQUZ3Qzs7QUFHbERDLFFBQU07QUFDSixXQUFPOEssT0FBT3pRLElBQVAsQ0FBWSxFQUFaLEVBQWdCRCxLQUFoQixFQUFQO0FBQ0Q7O0FBTGlELENBQXBCLENBQXpCO0FBUUEsTUFBTStTLDBCQUEwQixJQUFJdE4sZUFBSixDQUFvQjtBQUN6RDVFLFFBQU0sNkJBRG1EO0FBRXpEa0UsWUFBVSxJQUFJL0YsWUFBSixDQUFpQixFQUFqQixFQUFxQjBHLFNBQXJCLENBQStCO0FBQUVDLFdBQU87QUFBVCxHQUEvQixDQUYrQzs7QUFHekRDLFFBQU07QUFDSixRQUFJLENBQUMsS0FBS0MsWUFBVixFQUF3QjtBQUN0QixZQUFNcU4sUUFBUXhDLE9BQU8vUCxPQUFQLENBQWUsRUFBZixFQUFtQjtBQUFFaUgsY0FBTTtBQUFFbUQsd0JBQWMsQ0FBQztBQUFqQjtBQUFSLE9BQW5CLENBQWQ7QUFDQSxZQUFNb0ksY0FBY2hVLE9BQU8rVCxNQUFNbkksWUFBYixDQUFwQjtBQUNBLFlBQU1xSSxRQUFRRCxZQUFZQyxLQUFaLEVBQWQsQ0FIc0IsQ0FHYTs7QUFDbkMsWUFBTUMsT0FBT0YsWUFBWUUsSUFBWixFQUFiO0FBQ0EsYUFBTztBQUFFbFEsZ0JBQVErUCxNQUFNL1AsTUFBaEI7QUFBd0JpUSxhQUF4QjtBQUErQkM7QUFBL0IsT0FBUDtBQUNEOztBQUNELFdBQU8sSUFBUDtBQUNEOztBQVp3RCxDQUFwQixDQUFoQztBQXlCQSxNQUFNTCxxQkFBcUIsSUFBSXZOLGVBQUosQ0FBb0I7QUFDcEQ1RSxRQUFNLDJCQUQ4QztBQUVwRGtFLFlBQVUsSUFBSS9GLFlBQUosQ0FBaUI7QUFDekJvTSxZQUFRO0FBQUVySSxZQUFNeUQ7QUFBUixLQURpQjtBQUV6QixnQkFBWTtBQUFFekQsWUFBTUs7QUFBUixLQUZhO0FBR3pCa1Esa0JBQWM7QUFBRXZRLFlBQU1HO0FBQVIsS0FIVztBQUl6QnFRLGdCQUFZO0FBQUV4USxZQUFNRztBQUFSO0FBSmEsR0FBakIsRUFLUHdDLFNBTE8sQ0FLRztBQUFFQyxXQUFPO0FBQVQsR0FMSCxDQUYwQzs7QUFRcERDLE1BQUk7QUFBRXdGLFVBQUY7QUFBVWtJLGdCQUFWO0FBQXdCQztBQUF4QixHQUFKLEVBQTBDO0FBQ3hDO0FBQ0EsVUFBTUMsb0JBQW9CO0FBQ3hCeEksZUFBUztBQUNQeUksYUFBS3ZRLE9BQU93USxnQkFETDtBQUVQQyxpQkFBUyxJQUZGO0FBR1BDLGFBQUsxUSxPQUFPMlEsZ0JBSEw7QUFJUEMsaUJBQVMsSUFKRjtBQUtQQyxpQkFBUyxDQUxGO0FBTVAvVCxlQUFPO0FBTkEsT0FEZTtBQVN4QmlMLGlCQUFXO0FBQ1R3SSxhQUFLdlEsT0FBT3dRLGdCQURIO0FBRVRDLGlCQUFTLElBRkE7QUFHVEMsYUFBSzFRLE9BQU8yUSxnQkFISDtBQUlUQyxpQkFBUyxJQUpBO0FBS1RDLGlCQUFTLENBTEE7QUFNVC9ULGVBQU87QUFORSxPQVRhO0FBaUJ4QndELFdBQUs7QUFDSGlRLGFBQUt2USxPQUFPd1EsZ0JBRFQ7QUFFSEMsaUJBQVMsSUFGTjtBQUdIQyxhQUFLMVEsT0FBTzJRLGdCQUhUO0FBSUhDLGlCQUFTLElBSk47QUFLSEMsaUJBQVMsQ0FMTjtBQU1IL1QsZUFBTztBQU5KLE9BakJtQjtBQXlCeEJnVSxxQkFBZTtBQXpCUyxLQUExQixDQUZ3QyxDQTZCeEM7QUFDQTtBQUNBO0FBQ0E7O0FBQ0EsV0FBT3JRLE9BQU9zUSxNQUFQLENBQWMsR0FBRzdJLE9BQU81SixHQUFQLENBQVcrSixTQUFTO0FBQzFDLFlBQU0ySSxtQkFBbUJ4RCxPQUFPelEsSUFBUCxDQUFZO0FBQ25Da0QsZ0JBQVFvSSxLQUQyQjtBQUVuQ1Isc0JBQWM7QUFBRTRILGVBQUtXLFlBQVA7QUFBcUJ4TCxnQkFBTTNJLE9BQU9vVSxVQUFQLEVBQW1CWSxLQUFuQixDQUF5QixLQUF6QixFQUFnQzdULE9BQWhDO0FBQTNCO0FBRnFCLE9BQVosRUFHdEI4QixLQUhzQixFQUF6QixDQUQwQyxDQU0xQzs7QUFDQSxZQUFNZ1MsUUFBUWpWLE9BQU9tVSxZQUFQLENBQWQ7QUFDQSxZQUFNZSxNQUFNbFYsT0FBT29VLFVBQVAsQ0FBWixDQVIwQyxDQVMxQzs7QUFDQSxZQUFNTixjQUFjLElBQUl6SyxHQUFKLEVBQXBCOztBQUNBLFdBQUssSUFBSWpHLElBQUk2UixNQUFNL1QsT0FBTixDQUFjLEtBQWQsQ0FBYixFQUFtQ2tDLEtBQUs4UixJQUFJaFUsT0FBSixDQUFZLEtBQVosQ0FBeEMsRUFBNERrQyxJQUFJQSxFQUFFK1IsR0FBRixDQUFNLENBQU4sRUFBUyxNQUFULENBQWhFLEVBQWtGO0FBQ2hGckIsb0JBQVlySyxHQUFaLENBQWdCckcsRUFBRWpDLE9BQUYsRUFBaEIsRUFBNkJwQixFQUFFcVYsU0FBRixDQUFZZixpQkFBWixDQUE3QjtBQUNELE9BYnlDLENBZTFDOzs7QUFDQVUsdUJBQWlCNVIsT0FBakIsQ0FBeUI0USxTQUFTO0FBQ2hDLGNBQU1zQixjQUFjclYsT0FBTytULE1BQU1uSSxZQUFiLEVBQTJCMUssT0FBM0IsQ0FBbUMsS0FBbkMsRUFBMENDLE9BQTFDLEVBQXBCO0FBQ0EsY0FBTW1VLE1BQU14QixZQUFZcEssR0FBWixDQUFnQjJMLFdBQWhCLENBQVosQ0FGZ0MsQ0FFVTs7QUFDMUNDLFlBQUlULGFBQUosR0FIZ0MsQ0FLaEM7O0FBQ0EsWUFBSWQsTUFBTWxJLE9BQVYsRUFBbUI7QUFDakJ5SixjQUFJekosT0FBSixDQUFZaEwsS0FBWjs7QUFDQSxjQUFJa1QsTUFBTWxJLE9BQU4sQ0FBY3lJLEdBQWQsR0FBb0JnQixJQUFJekosT0FBSixDQUFZeUksR0FBcEMsRUFBeUM7QUFDdkNnQixnQkFBSXpKLE9BQUosQ0FBWXlJLEdBQVosR0FBa0JQLE1BQU1sSSxPQUFOLENBQWN5SSxHQUFoQztBQUNBZ0IsZ0JBQUl6SixPQUFKLENBQVkySSxPQUFaLEdBQXNCVCxNQUFNbkksWUFBNUI7QUFDRDs7QUFDRCxjQUFJbUksTUFBTWxJLE9BQU4sQ0FBYzRJLEdBQWQsR0FBb0JhLElBQUl6SixPQUFKLENBQVk0SSxHQUFwQyxFQUF5QztBQUN2Q2EsZ0JBQUl6SixPQUFKLENBQVk0SSxHQUFaLEdBQWtCVixNQUFNbEksT0FBTixDQUFjNEksR0FBaEM7QUFDQWEsZ0JBQUl6SixPQUFKLENBQVk4SSxPQUFaLEdBQXNCWixNQUFNbkksWUFBNUI7QUFDRDs7QUFDRDBKLGNBQUl6SixPQUFKLENBQVkrSSxPQUFaLElBQXVCLENBQUNiLE1BQU1sSSxPQUFOLENBQWMrSSxPQUFkLEdBQXdCVSxJQUFJekosT0FBSixDQUFZK0ksT0FBckMsSUFBZ0RVLElBQUl6SixPQUFKLENBQVloTCxLQUFuRjtBQUNELFNBakIrQixDQWtCaEM7OztBQUNBLFlBQUlrVCxNQUFNakksU0FBVixFQUFxQjtBQUNuQndKLGNBQUl4SixTQUFKLENBQWNqTCxLQUFkOztBQUNBLGNBQUlrVCxNQUFNakksU0FBTixDQUFnQndJLEdBQWhCLEdBQXNCZ0IsSUFBSXhKLFNBQUosQ0FBY3dJLEdBQXhDLEVBQTZDO0FBQzNDZ0IsZ0JBQUl4SixTQUFKLENBQWN3SSxHQUFkLEdBQW9CUCxNQUFNakksU0FBTixDQUFnQndJLEdBQXBDO0FBQ0FnQixnQkFBSXhKLFNBQUosQ0FBYzBJLE9BQWQsR0FBd0JULE1BQU1uSSxZQUE5QjtBQUNEOztBQUNELGNBQUltSSxNQUFNakksU0FBTixDQUFnQjJJLEdBQWhCLEdBQXNCYSxJQUFJeEosU0FBSixDQUFjMkksR0FBeEMsRUFBNkM7QUFDM0NhLGdCQUFJeEosU0FBSixDQUFjMkksR0FBZCxHQUFvQlYsTUFBTWpJLFNBQU4sQ0FBZ0IySSxHQUFwQztBQUNBYSxnQkFBSXhKLFNBQUosQ0FBYzZJLE9BQWQsR0FBd0JaLE1BQU1uSSxZQUE5QjtBQUNEOztBQUNEMEosY0FBSXhKLFNBQUosQ0FBYzhJLE9BQWQsSUFBeUIsQ0FBQ2IsTUFBTWpJLFNBQU4sQ0FBZ0I4SSxPQUFoQixHQUEwQlUsSUFBSXhKLFNBQUosQ0FBYzhJLE9BQXpDLElBQW9EVSxJQUFJeEosU0FBSixDQUFjakwsS0FBM0Y7QUFDRCxTQTlCK0IsQ0ErQmhDOzs7QUFDQSxZQUFJa1QsTUFBTTFQLEdBQVYsRUFBZTtBQUNiaVIsY0FBSWpSLEdBQUosQ0FBUXhELEtBQVI7O0FBQ0EsY0FBSWtULE1BQU0xUCxHQUFOLENBQVVpUSxHQUFWLEdBQWdCZ0IsSUFBSWpSLEdBQUosQ0FBUWlRLEdBQTVCLEVBQWlDO0FBQy9CZ0IsZ0JBQUlqUixHQUFKLENBQVFpUSxHQUFSLEdBQWNQLE1BQU0xUCxHQUFOLENBQVVpUSxHQUF4QjtBQUNBZ0IsZ0JBQUlqUixHQUFKLENBQVFtUSxPQUFSLEdBQWtCVCxNQUFNbkksWUFBeEI7QUFDRDs7QUFDRCxjQUFJbUksTUFBTTFQLEdBQU4sQ0FBVW9RLEdBQVYsR0FBZ0JhLElBQUlqUixHQUFKLENBQVFvUSxHQUE1QixFQUFpQztBQUMvQmEsZ0JBQUlqUixHQUFKLENBQVFvUSxHQUFSLEdBQWNWLE1BQU0xUCxHQUFOLENBQVVvUSxHQUF4QjtBQUNBYSxnQkFBSWpSLEdBQUosQ0FBUXNRLE9BQVIsR0FBa0JaLE1BQU1uSSxZQUF4QjtBQUNEOztBQUNEMEosY0FBSWpSLEdBQUosQ0FBUXVRLE9BQVIsSUFBbUIsQ0FBQ2IsTUFBTTFQLEdBQU4sQ0FBVXVRLE9BQVYsR0FBb0JVLElBQUlqUixHQUFKLENBQVF1USxPQUE3QixJQUF3Q1UsSUFBSWpSLEdBQUosQ0FBUXhELEtBQW5FO0FBQ0Q7QUFDRixPQTVDRCxFQWhCMEMsQ0E4RDFDOztBQUNBaVQsa0JBQVkzUSxPQUFaLENBQW9CbVMsT0FBTztBQUN6QixZQUFJQSxJQUFJekosT0FBSixDQUFZaEwsS0FBWixLQUFzQixDQUExQixFQUE2QixPQUFPeVUsSUFBSXpKLE9BQVgsQ0FESixDQUN3Qjs7QUFDakQsWUFBSXlKLElBQUl4SixTQUFKLENBQWNqTCxLQUFkLEtBQXdCLENBQTVCLEVBQStCLE9BQU95VSxJQUFJeEosU0FBWCxDQUZOLENBRTRCOztBQUNyRCxZQUFJd0osSUFBSWpSLEdBQUosQ0FBUXhELEtBQVIsS0FBa0IsQ0FBdEIsRUFBeUIsT0FBT3lVLElBQUlqUixHQUFYLENBSEEsQ0FHZ0I7QUFDMUMsT0FKRCxFQS9EMEMsQ0FvRTFDOztBQUNBeVAsa0JBQVkzUSxPQUFaLENBQW9CbVMsT0FBTztBQUN6QjtBQUNBQSxZQUFJQyxNQUFKLEdBQWNELElBQUlULGFBQUosR0FBb0IsSUFBckIsR0FBNkIsR0FBMUMsQ0FGeUIsQ0FFc0I7QUFDaEQsT0FIRCxFQXJFMEMsQ0EwRTFDOztBQUNBLFlBQU1XLE1BQU16VixFQUFFcVYsU0FBRixDQUFZZixpQkFBWixDQUFaLENBM0UwQyxDQTJFRTs7O0FBQzVDUCxrQkFBWTNRLE9BQVosQ0FBb0JtUyxPQUFPO0FBQUU7QUFDM0I7QUFDQUUsWUFBSVgsYUFBSixJQUFxQlMsSUFBSVQsYUFBekIsQ0FGeUIsQ0FJekI7O0FBQ0EsWUFBSVMsSUFBSXpKLE9BQVIsRUFBaUI7QUFDZjJKLGNBQUkzSixPQUFKLENBQVloTCxLQUFaOztBQUNBLGNBQUl5VSxJQUFJekosT0FBSixDQUFZeUksR0FBWixHQUFrQmtCLElBQUkzSixPQUFKLENBQVl5SSxHQUFsQyxFQUF1QztBQUNyQ2tCLGdCQUFJM0osT0FBSixDQUFZeUksR0FBWixHQUFrQmdCLElBQUl6SixPQUFKLENBQVl5SSxHQUE5QjtBQUNBa0IsZ0JBQUkzSixPQUFKLENBQVkySSxPQUFaLEdBQXNCYyxJQUFJekosT0FBSixDQUFZMkksT0FBbEM7QUFDRDs7QUFDRCxjQUFJYyxJQUFJekosT0FBSixDQUFZNEksR0FBWixHQUFrQmUsSUFBSTNKLE9BQUosQ0FBWTRJLEdBQWxDLEVBQXVDO0FBQ3JDZSxnQkFBSTNKLE9BQUosQ0FBWTRJLEdBQVosR0FBa0JhLElBQUl6SixPQUFKLENBQVk0SSxHQUE5QjtBQUNBZSxnQkFBSTNKLE9BQUosQ0FBWThJLE9BQVosR0FBc0JXLElBQUl6SixPQUFKLENBQVk4SSxPQUFsQztBQUNEOztBQUNEYSxjQUFJM0osT0FBSixDQUFZK0ksT0FBWixJQUF1QixDQUFDVSxJQUFJekosT0FBSixDQUFZK0ksT0FBWixHQUFzQlksSUFBSTNKLE9BQUosQ0FBWStJLE9BQW5DLElBQThDWSxJQUFJM0osT0FBSixDQUFZaEwsS0FBakY7QUFDRCxTQWhCd0IsQ0FpQnpCOzs7QUFDQSxZQUFJeVUsSUFBSXhKLFNBQVIsRUFBbUI7QUFDakIwSixjQUFJMUosU0FBSixDQUFjakwsS0FBZDs7QUFDQSxjQUFJeVUsSUFBSXhKLFNBQUosQ0FBY3dJLEdBQWQsR0FBb0JrQixJQUFJMUosU0FBSixDQUFjd0ksR0FBdEMsRUFBMkM7QUFDekNrQixnQkFBSTFKLFNBQUosQ0FBY3dJLEdBQWQsR0FBb0JnQixJQUFJeEosU0FBSixDQUFjd0ksR0FBbEM7QUFDQWtCLGdCQUFJMUosU0FBSixDQUFjMEksT0FBZCxHQUF3QmMsSUFBSXhKLFNBQUosQ0FBYzBJLE9BQXRDO0FBQ0Q7O0FBQ0QsY0FBSWMsSUFBSXhKLFNBQUosQ0FBYzJJLEdBQWQsR0FBb0JlLElBQUkxSixTQUFKLENBQWMySSxHQUF0QyxFQUEyQztBQUN6Q2UsZ0JBQUkxSixTQUFKLENBQWMySSxHQUFkLEdBQW9CYSxJQUFJeEosU0FBSixDQUFjMkksR0FBbEM7QUFDQWUsZ0JBQUkxSixTQUFKLENBQWM2SSxPQUFkLEdBQXdCVyxJQUFJeEosU0FBSixDQUFjNkksT0FBdEM7QUFDRDs7QUFDRGEsY0FBSTFKLFNBQUosQ0FBYzhJLE9BQWQsSUFBeUIsQ0FBQ1UsSUFBSXhKLFNBQUosQ0FBYzhJLE9BQWQsR0FBd0JZLElBQUkxSixTQUFKLENBQWM4SSxPQUF2QyxJQUFrRFksSUFBSTFKLFNBQUosQ0FBY2pMLEtBQXpGO0FBQ0QsU0E3QndCLENBOEJ6Qjs7O0FBQ0EsWUFBSXlVLElBQUlqUixHQUFSLEVBQWE7QUFDWG1SLGNBQUluUixHQUFKLENBQVF4RCxLQUFSOztBQUNBLGNBQUl5VSxJQUFJalIsR0FBSixDQUFRaVEsR0FBUixHQUFja0IsSUFBSW5SLEdBQUosQ0FBUWlRLEdBQTFCLEVBQStCO0FBQzdCa0IsZ0JBQUluUixHQUFKLENBQVFpUSxHQUFSLEdBQWNnQixJQUFJalIsR0FBSixDQUFRaVEsR0FBdEI7QUFDQWtCLGdCQUFJblIsR0FBSixDQUFRbVEsT0FBUixHQUFrQmMsSUFBSWpSLEdBQUosQ0FBUW1RLE9BQTFCO0FBQ0Q7O0FBQ0QsY0FBSWMsSUFBSWpSLEdBQUosQ0FBUW9RLEdBQVIsR0FBY2UsSUFBSW5SLEdBQUosQ0FBUW9RLEdBQTFCLEVBQStCO0FBQzdCZSxnQkFBSW5SLEdBQUosQ0FBUW9RLEdBQVIsR0FBY2EsSUFBSWpSLEdBQUosQ0FBUW9RLEdBQXRCO0FBQ0FlLGdCQUFJblIsR0FBSixDQUFRc1EsT0FBUixHQUFrQlcsSUFBSWpSLEdBQUosQ0FBUXNRLE9BQTFCO0FBQ0Q7O0FBQ0RhLGNBQUluUixHQUFKLENBQVF1USxPQUFSLElBQW1CLENBQUNVLElBQUlqUixHQUFKLENBQVF1USxPQUFSLEdBQWtCWSxJQUFJblIsR0FBSixDQUFRdVEsT0FBM0IsSUFBc0NZLElBQUluUixHQUFKLENBQVF4RCxLQUFqRTtBQUNEO0FBQ0YsT0EzQ0QsRUE1RTBDLENBeUgxQzs7QUFDQSxVQUFJMlUsSUFBSTNKLE9BQUosQ0FBWWhMLEtBQVosS0FBc0IsQ0FBMUIsRUFBNkIsT0FBTzJVLElBQUkzSixPQUFYLENBMUhhLENBMEhPOztBQUNqRCxVQUFJMkosSUFBSTFKLFNBQUosQ0FBY2pMLEtBQWQsS0FBd0IsQ0FBNUIsRUFBK0IsT0FBTzJVLElBQUkxSixTQUFYLENBM0hXLENBMkhXOztBQUNyRCxVQUFJMEosSUFBSW5SLEdBQUosQ0FBUXhELEtBQVIsS0FBa0IsQ0FBdEIsRUFBeUIsT0FBTzJVLElBQUluUixHQUFYLENBNUhpQixDQTRIRDs7QUFFekMsYUFBTztBQUFFLFNBQUMrSCxLQUFELEdBQVM7QUFBRTBILHVCQUFhOUssU0FBUzhLLFdBQVQsQ0FBZjtBQUFzQzJCLHVCQUFhRDtBQUFuRDtBQUFYLE9BQVA7QUFDRCxLQS9IdUIsQ0FBakIsQ0FBUDtBQWdJRDs7QUF6S21ELENBQXBCLENBQTNCO0FBbUxBLE1BQU0xQixjQUFjLElBQUl4TixlQUFKLENBQW9CO0FBQzdDNUUsUUFBTSxvQkFEdUM7QUFFN0NrRSxZQUFVLElBQUkvRixZQUFKLENBQWlCO0FBQ3pCb00sWUFBUTtBQUFFckksWUFBTXlEO0FBQVIsS0FEaUI7QUFFekIsZ0JBQVk7QUFBRXpELFlBQU1LO0FBQVIsS0FGYTtBQUd6QmtRLGtCQUFjO0FBQUV2USxZQUFNRztBQUFSLEtBSFc7QUFJekJxUSxnQkFBWTtBQUFFeFEsWUFBTUc7QUFBUjtBQUphLEdBQWpCLEVBS1B3QyxTQUxPLENBS0c7QUFBRUMsV0FBTztBQUFULEdBTEgsQ0FGbUM7O0FBUTdDQyxNQUFJO0FBQUV3RixVQUFGO0FBQVVrSSxnQkFBVjtBQUF3QkM7QUFBeEIsR0FBSixFQUEwQztBQUN4QztBQUNBO0FBQ0E7QUFDQTtBQUNBLFdBQU81UCxPQUFPc1EsTUFBUCxDQUFjLEdBQUc3SSxPQUFPNUosR0FBUCxDQUFXK0osU0FBUztBQUMxQyxZQUFNMkksbUJBQW1CeEQsT0FBT3pRLElBQVAsQ0FBWTtBQUNuQ2tELGdCQUFRb0ksS0FEMkI7QUFFbkNSLHNCQUFjO0FBQUU0SCxlQUFLVyxZQUFQO0FBQXFCeEwsZ0JBQU0zSSxPQUFPb1UsVUFBUCxFQUFtQlksS0FBbkIsQ0FBeUIsS0FBekIsRUFBZ0M3VCxPQUFoQztBQUEzQjtBQUZxQixPQUFaLEVBR3RCOEIsS0FIc0IsRUFBekIsQ0FEMEMsQ0FNMUM7O0FBQ0EsWUFBTWdTLFFBQVFqVixPQUFPbVUsWUFBUCxDQUFkO0FBQ0EsWUFBTWUsTUFBTWxWLE9BQU9vVSxVQUFQLENBQVosQ0FSMEMsQ0FTMUM7O0FBQ0EsWUFBTXNCLGlCQUFpQixJQUFJck0sR0FBSixFQUF2Qjs7QUFDQSxXQUFLLElBQUlqRyxJQUFJNlIsTUFBTS9ULE9BQU4sQ0FBYyxLQUFkLENBQWIsRUFBbUNrQyxLQUFLOFIsSUFBSWhVLE9BQUosQ0FBWSxLQUFaLENBQXhDLEVBQTREa0MsSUFBSUEsRUFBRStSLEdBQUYsQ0FBTSxDQUFOLEVBQVMsTUFBVCxDQUFoRSxFQUFrRjtBQUNoRk8sdUJBQWVqTSxHQUFmLENBQW1CckcsRUFBRWpDLE9BQUYsRUFBbkIsRUFBZ0M7QUFDOUIwSyxtQkFBUztBQUNQeUksaUJBQUtxQixRQURFO0FBRVBsQixpQkFBSyxDQUFDa0IsUUFGQztBQUdQZixxQkFBUyxDQUhGO0FBSVAvVCxtQkFBTztBQUpBLFdBRHFCO0FBTzlCaUwscUJBQVc7QUFDVHdJLGlCQUFLcUIsUUFESTtBQUVUbEIsaUJBQUssQ0FBQ2tCLFFBRkc7QUFHVGYscUJBQVMsQ0FIQTtBQUlUL1QsbUJBQU87QUFKRSxXQVBtQjtBQWE5QndELGVBQUs7QUFDSGlRLGlCQUFLcUIsUUFERjtBQUVIbEIsaUJBQUssQ0FBQ2tCLFFBRkg7QUFHSGYscUJBQVMsQ0FITjtBQUlIL1QsbUJBQU87QUFKSjtBQWJ5QixTQUFoQztBQW9CRCxPQWhDeUMsQ0FrQzFDOzs7QUFDQWtVLHVCQUFpQjVSLE9BQWpCLENBQXlCNFEsU0FBUztBQUNoQyxjQUFNc0IsY0FBY3JWLE9BQU8rVCxNQUFNbkksWUFBYixFQUEyQjFLLE9BQTNCLENBQW1DLEtBQW5DLEVBQTBDQyxPQUExQyxFQUFwQjtBQUNBLGNBQU1tVSxNQUFNSSxlQUFlaE0sR0FBZixDQUFtQjJMLFdBQW5CLENBQVosQ0FGZ0MsQ0FFYTtBQUU3Qzs7QUFDQSxZQUFJdEIsTUFBTWxJLE9BQVYsRUFBbUI7QUFDakJ5SixjQUFJekosT0FBSixDQUFZaEwsS0FBWjtBQUNBLGNBQUlrVCxNQUFNbEksT0FBTixDQUFjeUksR0FBZCxHQUFvQmdCLElBQUl6SixPQUFKLENBQVl5SSxHQUFwQyxFQUF5Q2dCLElBQUl6SixPQUFKLENBQVl5SSxHQUFaLEdBQWtCUCxNQUFNbEksT0FBTixDQUFjeUksR0FBaEM7QUFDekMsY0FBSVAsTUFBTWxJLE9BQU4sQ0FBYzRJLEdBQWQsR0FBb0JhLElBQUl6SixPQUFKLENBQVk0SSxHQUFwQyxFQUF5Q2EsSUFBSXpKLE9BQUosQ0FBWTRJLEdBQVosR0FBa0JWLE1BQU1sSSxPQUFOLENBQWM0SSxHQUFoQztBQUN6Q2EsY0FBSXpKLE9BQUosQ0FBWStJLE9BQVosSUFBdUIsQ0FBQ2IsTUFBTWxJLE9BQU4sQ0FBYytJLE9BQWQsR0FBd0JVLElBQUl6SixPQUFKLENBQVkrSSxPQUFyQyxJQUFnRFUsSUFBSXpKLE9BQUosQ0FBWWhMLEtBQW5GO0FBQ0QsU0FWK0IsQ0FXaEM7OztBQUNBLFlBQUlrVCxNQUFNakksU0FBVixFQUFxQjtBQUNuQndKLGNBQUl4SixTQUFKLENBQWNqTCxLQUFkO0FBQ0EsY0FBSWtULE1BQU1qSSxTQUFOLENBQWdCd0ksR0FBaEIsR0FBc0JnQixJQUFJeEosU0FBSixDQUFjd0ksR0FBeEMsRUFBNkNnQixJQUFJeEosU0FBSixDQUFjd0ksR0FBZCxHQUFvQlAsTUFBTWpJLFNBQU4sQ0FBZ0J3SSxHQUFwQztBQUM3QyxjQUFJUCxNQUFNakksU0FBTixDQUFnQjJJLEdBQWhCLEdBQXNCYSxJQUFJeEosU0FBSixDQUFjMkksR0FBeEMsRUFBNkNhLElBQUl4SixTQUFKLENBQWMySSxHQUFkLEdBQW9CVixNQUFNakksU0FBTixDQUFnQjJJLEdBQXBDO0FBQzdDYSxjQUFJeEosU0FBSixDQUFjOEksT0FBZCxJQUF5QixDQUFDYixNQUFNakksU0FBTixDQUFnQjhJLE9BQWhCLEdBQTBCVSxJQUFJeEosU0FBSixDQUFjOEksT0FBekMsSUFBb0RVLElBQUl4SixTQUFKLENBQWNqTCxLQUEzRjtBQUNELFNBakIrQixDQWtCaEM7OztBQUNBLFlBQUlrVCxNQUFNMVAsR0FBVixFQUFlO0FBQ2JpUixjQUFJalIsR0FBSixDQUFReEQsS0FBUjtBQUNBLGNBQUlrVCxNQUFNMVAsR0FBTixDQUFVaVEsR0FBVixHQUFnQmdCLElBQUlqUixHQUFKLENBQVFpUSxHQUE1QixFQUFpQ2dCLElBQUlqUixHQUFKLENBQVFpUSxHQUFSLEdBQWNQLE1BQU0xUCxHQUFOLENBQVVpUSxHQUF4QjtBQUNqQyxjQUFJUCxNQUFNMVAsR0FBTixDQUFVb1EsR0FBVixHQUFnQmEsSUFBSWpSLEdBQUosQ0FBUW9RLEdBQTVCLEVBQWlDYSxJQUFJalIsR0FBSixDQUFRb1EsR0FBUixHQUFjVixNQUFNMVAsR0FBTixDQUFVb1EsR0FBeEI7QUFDakNhLGNBQUlqUixHQUFKLENBQVF1USxPQUFSLElBQW1CLENBQUNiLE1BQU0xUCxHQUFOLENBQVV1USxPQUFWLEdBQW9CVSxJQUFJalIsR0FBSixDQUFRdVEsT0FBN0IsSUFBd0NVLElBQUlqUixHQUFKLENBQVF4RCxLQUFuRTtBQUNEO0FBQ0YsT0F6QkQsRUFuQzBDLENBOEQxQzs7QUFDQTZVLHFCQUFldlMsT0FBZixDQUF1Qm1TLE9BQU87QUFDNUIsWUFBSUEsSUFBSXpKLE9BQUosQ0FBWWhMLEtBQVosS0FBc0IsQ0FBMUIsRUFBNkIsT0FBT3lVLElBQUl6SixPQUFYLENBQTdCLENBQWlEO0FBQWpELGFBQ0ssT0FBT3lKLElBQUl6SixPQUFKLENBQVloTCxLQUFuQixDQUZ1QixDQUVHOztBQUMvQixZQUFJeVUsSUFBSXhKLFNBQUosQ0FBY2pMLEtBQWQsS0FBd0IsQ0FBNUIsRUFBK0IsT0FBT3lVLElBQUl4SixTQUFYLENBQS9CLENBQXFEO0FBQXJELGFBQ0ssT0FBT3dKLElBQUl4SixTQUFKLENBQWNqTCxLQUFyQixDQUp1QixDQUlLOztBQUNqQyxZQUFJeVUsSUFBSWpSLEdBQUosQ0FBUXhELEtBQVIsS0FBa0IsQ0FBdEIsRUFBeUIsT0FBT3lVLElBQUlqUixHQUFYLENBQXpCLENBQXlDO0FBQXpDLGFBQ0ssT0FBT2lSLElBQUlqUixHQUFKLENBQVF4RCxLQUFmLENBTnVCLENBTUQ7QUFDNUIsT0FQRDtBQVNBLGFBQU87QUFBRSxTQUFDdUwsS0FBRCxHQUFTcEQsU0FBUzBNLGNBQVQ7QUFBWCxPQUFQO0FBQ0QsS0F6RXVCLENBQWpCLENBQVA7QUEwRUQ7O0FBdkY0QyxDQUFwQixDQUFwQixDOzs7Ozs7Ozs7OztBQzNOUGxXLE9BQU9DLEtBQVAsQ0FBYUMsUUFBUSx1QkFBUixDQUFiO0FBQStDRixPQUFPQyxLQUFQLENBQWFDLFFBQVEsOEJBQVIsQ0FBYixFOzs7Ozs7Ozs7OztBQ0EvQ0YsT0FBTytELE1BQVAsQ0FBYztBQUFDcVMsYUFBVSxNQUFJQTtBQUFmLENBQWQ7QUFBeUMsSUFBSXJXLE1BQUo7QUFBV0MsT0FBT0MsS0FBUCxDQUFhQyxRQUFRLGVBQVIsQ0FBYixFQUFzQztBQUFDSCxTQUFPSSxDQUFQLEVBQVM7QUFBQ0osYUFBT0ksQ0FBUDtBQUFTOztBQUFwQixDQUF0QyxFQUE0RCxDQUE1RDtBQUErRCxJQUFJRSxZQUFKO0FBQWlCTCxPQUFPQyxLQUFQLENBQWFDLFFBQVEsY0FBUixDQUFiLEVBQXFDO0FBQUNJLFVBQVFILENBQVIsRUFBVTtBQUFDRSxtQkFBYUYsQ0FBYjtBQUFlOztBQUEzQixDQUFyQyxFQUFrRSxDQUFsRTtBQUFxRSxJQUFJTSxjQUFKO0FBQW1CVCxPQUFPQyxLQUFQLENBQWFDLFFBQVEsd0JBQVIsQ0FBYixFQUErQztBQUFDSSxVQUFRSCxDQUFSLEVBQVU7QUFBQ00scUJBQWVOLENBQWY7QUFBaUI7O0FBQTdCLENBQS9DLEVBQThFLENBQTlFOztBQUk1Tjs7Ozs7QUFLQSxNQUFNa1csbUJBQU4sU0FBa0M1VixjQUFsQyxDQUFpRDtBQUUvQzs7O0FBR0FDLGdCQUFjO0FBQ1osVUFBTSxXQUFOLEVBQW1CLElBQUlMLFlBQUosQ0FBaUI7QUFDbENpVyxnQkFBVTdSLE1BRHdCO0FBRWxDc08sYUFBT3RPO0FBRjJCLEtBQWpCLENBQW5CO0FBSUQ7QUFFRDs7Ozs7Ozs7OztBQVVBOzs7QUFDQXRCLFNBQU87QUFBRW1ULFlBQUY7QUFBWXZEO0FBQVosR0FBUCxFQUE0QjtBQUMxQixRQUFJaFQsT0FBT3dDLFFBQVgsRUFBcUI7QUFDbkIsWUFBTWdVLGNBQWMsS0FBS3ZVLE9BQUwsQ0FBYXNVLFFBQWIsRUFBdUJ2RCxLQUF2QixDQUFwQjs7QUFDQSxVQUFJd0QsV0FBSixFQUFpQjtBQUNmLGVBQU9BLFlBQVlwVSxHQUFuQjtBQUNEOztBQUNELGFBQU8sS0FBS25CLFdBQUwsQ0FBaUI0RSxNQUFqQixDQUF3QjtBQUFFMFEsZ0JBQUY7QUFBWXZEO0FBQVosT0FBeEIsQ0FBUDtBQUNELEtBUHlCLENBUTFCOzs7QUFDQSxXQUFPOUIsU0FBUDtBQUNEO0FBRUQ7Ozs7Ozs7QUFLQXVGLHFCQUFtQkYsUUFBbkIsRUFBNkI7QUFDM0IsV0FBTyxLQUFLdFYsV0FBTCxDQUFpQk0sSUFBakIsQ0FBc0I7QUFBRWdWO0FBQUYsS0FBdEIsRUFBb0M3UyxLQUFwQyxFQUFQO0FBQ0Q7QUFFRDs7Ozs7OztBQUtBZ1Qsc0JBQW9CSCxRQUFwQixFQUE4QjtBQUM1QixVQUFNL0UsT0FBTyxLQUFLdlEsV0FBTCxDQUFpQk0sSUFBakIsQ0FBc0I7QUFBRWdWO0FBQUYsS0FBdEIsRUFBb0M3UyxLQUFwQyxFQUFiOztBQUNBLFdBQVE4TixJQUFELEdBQVNoUixFQUFFc0MsR0FBRixDQUFNME8sSUFBTixFQUFZek8sT0FBT0EsSUFBSWlRLEtBQXZCLENBQVQsR0FBeUMsRUFBaEQ7QUFDRDtBQUVEOzs7Ozs7O0FBS0EyRCxzQkFBb0IzRCxLQUFwQixFQUEyQjtBQUN6QixVQUFNeEIsT0FBTyxLQUFLdlEsV0FBTCxDQUFpQk0sSUFBakIsQ0FBc0I7QUFBRXlSO0FBQUYsS0FBdEIsRUFBaUN0UCxLQUFqQyxFQUFiOztBQUNBLFdBQVE4TixJQUFELEdBQVNoUixFQUFFc0MsR0FBRixDQUFNME8sSUFBTixFQUFZek8sT0FBT0EsSUFBSXdULFFBQXZCLENBQVQsR0FBNEMsRUFBbkQ7QUFDRDs7QUFFRHRVLFVBQVFzVSxRQUFSLEVBQWtCdkQsS0FBbEIsRUFBeUI7QUFDdkIsV0FBTyxLQUFLL1IsV0FBTCxDQUFpQmdCLE9BQWpCLENBQXlCO0FBQUVzVSxjQUFGO0FBQVl2RDtBQUFaLEtBQXpCLENBQVA7QUFDRDtBQUVEOzs7Ozs7QUFJQTRELHVCQUFxQkwsUUFBckIsRUFBK0I7QUFDN0IsU0FBS3RWLFdBQUwsQ0FBaUI2QyxNQUFqQixDQUF3QjtBQUFFeVM7QUFBRixLQUF4QjtBQUNEO0FBRUQ7Ozs7Ozs7QUFLQTdULFVBQVFDLEtBQVIsRUFBZTtBQUNiLFVBQU1JLE1BQU0sS0FBS0MsT0FBTCxDQUFhTCxLQUFiLENBQVo7QUFDQSxVQUFNNFQsV0FBV3hULElBQUl3VCxRQUFyQjtBQUNBLFVBQU12RCxRQUFRalEsSUFBSWlRLEtBQWxCO0FBQ0EsV0FBTztBQUFFdUQsY0FBRjtBQUFZdkQ7QUFBWixLQUFQO0FBQ0Q7O0FBdEY4QztBQTJGakQ7Ozs7O0FBR08sTUFBTXFELFlBQVksSUFBSUMsbUJBQUosRUFBbEIsQzs7Ozs7Ozs7Ozs7QUN2R1ByVyxPQUFPK0QsTUFBUCxDQUFjO0FBQUNpTyxnQkFBYSxNQUFJQTtBQUFsQixDQUFkO0FBQStDLElBQUlqUyxNQUFKO0FBQVdDLE9BQU9DLEtBQVAsQ0FBYUMsUUFBUSxlQUFSLENBQWIsRUFBc0M7QUFBQ0gsU0FBT0ksQ0FBUCxFQUFTO0FBQUNKLGFBQU9JLENBQVA7QUFBUzs7QUFBcEIsQ0FBdEMsRUFBNEQsQ0FBNUQ7QUFBK0QsSUFBSXlXLFFBQUo7QUFBYTVXLE9BQU9DLEtBQVAsQ0FBYUMsUUFBUSxzQkFBUixDQUFiLEVBQTZDO0FBQUMwVyxXQUFTelcsQ0FBVCxFQUFXO0FBQUN5VyxlQUFTelcsQ0FBVDtBQUFXOztBQUF4QixDQUE3QyxFQUF1RSxDQUF2RTtBQUEwRSxJQUFJMFcsS0FBSjtBQUFVN1csT0FBT0MsS0FBUCxDQUFhQyxRQUFRLHVCQUFSLENBQWIsRUFBOEM7QUFBQzJXLFFBQU0xVyxDQUFOLEVBQVE7QUFBQzBXLFlBQU0xVyxDQUFOO0FBQVE7O0FBQWxCLENBQTlDLEVBQWtFLENBQWxFOztBQUFxRSxJQUFJSSxDQUFKOztBQUFNUCxPQUFPQyxLQUFQLENBQWFDLFFBQVEsUUFBUixDQUFiLEVBQStCO0FBQUNLLElBQUVKLENBQUYsRUFBSTtBQUFDSSxRQUFFSixDQUFGO0FBQUk7O0FBQVYsQ0FBL0IsRUFBMkMsQ0FBM0M7QUFBOEMsSUFBSUUsWUFBSjtBQUFpQkwsT0FBT0MsS0FBUCxDQUFhQyxRQUFRLGNBQVIsQ0FBYixFQUFxQztBQUFDSSxVQUFRSCxDQUFSLEVBQVU7QUFBQ0UsbUJBQWFGLENBQWI7QUFBZTs7QUFBM0IsQ0FBckMsRUFBa0UsQ0FBbEU7QUFBcUUsSUFBSU0sY0FBSjtBQUFtQlQsT0FBT0MsS0FBUCxDQUFhQyxRQUFRLHdCQUFSLENBQWIsRUFBK0M7QUFBQ0ksVUFBUUgsQ0FBUixFQUFVO0FBQUNNLHFCQUFlTixDQUFmO0FBQWlCOztBQUE3QixDQUEvQyxFQUE4RSxDQUE5RTtBQUFpRixJQUFJaVcsU0FBSjtBQUFjcFcsT0FBT0MsS0FBUCxDQUFhQyxRQUFRLHVCQUFSLENBQWIsRUFBOEM7QUFBQ2tXLFlBQVVqVyxDQUFWLEVBQVk7QUFBQ2lXLGdCQUFValcsQ0FBVjtBQUFZOztBQUExQixDQUE5QyxFQUEwRSxDQUExRTs7QUFRM2hCOzs7OztBQUtBLE1BQU0yVyxzQkFBTixTQUFxQ3JXLGNBQXJDLENBQW9EO0FBRWxEOzs7QUFHQUMsZ0JBQWM7QUFDWixVQUFNLGNBQU4sRUFBc0IsSUFBSUwsWUFBSixDQUFpQjtBQUNyQ2lXLGdCQUFVN1IsTUFEMkI7QUFFckNzUyxpQkFBV3RTLE1BRjBCO0FBR3JDdVMsZ0JBQVV2UyxNQUgyQjtBQUlyQ3dTLFlBQU14UztBQUorQixLQUFqQixDQUF0QjtBQU1EO0FBRUQ7Ozs7Ozs7Ozs7QUFVQTs7O0FBQ0F0QixTQUFPO0FBQUVtVCxZQUFGO0FBQVlZLFlBQVo7QUFBc0JILGFBQXRCO0FBQWlDQyxZQUFqQztBQUEyQ0csYUFBUyxFQUFwRDtBQUF3REYsV0FBTztBQUEvRCxHQUFQLEVBQWdGO0FBQzlFLFFBQUlsWCxPQUFPd0MsUUFBWCxFQUFxQjtBQUNuQjtBQUNBNFUsYUFBT3hULE9BQVAsQ0FBZW9QLFNBQVM7QUFDdEIsWUFBSSxDQUFDeFMsRUFBRTZXLFFBQUYsQ0FBV3JFLEtBQVgsQ0FBTCxFQUF3QjtBQUN0QixnQkFBTSxJQUFJaFQsT0FBT2MsS0FBWCxDQUFrQixnQ0FBK0JrUyxLQUFNLEVBQXZELENBQU47QUFDRDtBQUNGLE9BSkQsRUFGbUIsQ0FRbkI7O0FBQ0EsVUFBSWtFLFNBQVMsTUFBVCxJQUFtQkEsU0FBUyxPQUFoQyxFQUF5QztBQUN2QyxjQUFNLElBQUlsWCxPQUFPYyxLQUFYLENBQWlCLHNEQUFqQixDQUFOO0FBQ0QsT0FYa0IsQ0FhbkI7OztBQUNBLFVBQUl3VyxPQUFPVCxTQUFTVSxrQkFBVCxDQUE0QmhCLFFBQTVCLENBQVg7QUFDQSxVQUFJaUIsU0FBU0YsUUFBUUEsS0FBS2xWLEdBQTFCLENBZm1CLENBZ0JuQjs7QUFDQSxVQUFJLENBQUNvVixNQUFMLEVBQWE7QUFDWEEsaUJBQVNYLFNBQVNZLFVBQVQsQ0FBb0I7QUFBRWxCLGtCQUFGO0FBQVltQixpQkFBT25CLFFBQW5CO0FBQTZCWTtBQUE3QixTQUFwQixDQUFUO0FBQ0FHLGVBQU9ULFNBQVNVLGtCQUFULENBQTRCaEIsUUFBNUIsQ0FBUDtBQUNELE9BcEJrQixDQXNCbkI7OztBQUNBLFdBQUt0VixXQUFMLENBQWlCK1AsTUFBakIsQ0FBd0I7QUFBRXVGO0FBQUYsT0FBeEIsRUFBc0M7QUFBRXRGLGNBQU07QUFBRStGLG1CQUFGO0FBQWFDLGtCQUFiO0FBQXVCQztBQUF2QjtBQUFSLE9BQXRDOztBQUNBLFlBQU1TLFlBQVksS0FBSzFWLE9BQUwsQ0FBYTtBQUFFc1U7QUFBRixPQUFiLEVBQTJCblUsR0FBN0MsQ0F4Qm1CLENBMEJuQjs7O0FBQ0EsVUFBSW9WLE1BQUosRUFBWTtBQUNWVixjQUFNYyxlQUFOLENBQXNCSixNQUF0QixFQUE4Qk4sSUFBOUI7QUFDRCxPQTdCa0IsQ0ErQm5COzs7QUFDQWIsZ0JBQVVPLG9CQUFWLENBQStCTCxRQUEvQjtBQUNBYSxhQUFPdFUsR0FBUCxDQUFXa1EsU0FBU3FELFVBQVVqVCxNQUFWLENBQWlCO0FBQUVtVCxnQkFBRjtBQUFZdkQ7QUFBWixPQUFqQixDQUFwQixFQWpDbUIsQ0FtQ25COztBQUNBLGFBQU8yRSxTQUFQO0FBQ0QsS0F0QzZFLENBdUM5RTs7O0FBQ0EsV0FBT3pHLFNBQVA7QUFDRDtBQUVEOzs7Ozs7OztBQU1BMkcsaUJBQWV0QixRQUFmLEVBQXlCO0FBQ3ZCLFVBQU11QixVQUFVLEtBQUs3VyxXQUFMLENBQWlCZ0IsT0FBakIsQ0FBeUI7QUFBRXNVO0FBQUYsS0FBekIsQ0FBaEI7O0FBQ0EsUUFBSXVCLE9BQUosRUFBYTtBQUNYLGFBQU9BLE9BQVA7QUFDRDs7QUFDRCxVQUFNLElBQUk5WCxPQUFPYyxLQUFYLENBQWtCLDJDQUEwQ3lWLFFBQVMsRUFBckUsQ0FBTjtBQUNEO0FBRUQ7Ozs7Ozs7QUFLQTdULFVBQVFDLEtBQVIsRUFBZTtBQUNiLFVBQU1JLE1BQU0sS0FBS0MsT0FBTCxDQUFhTCxLQUFiLENBQVo7QUFDQSxVQUFNNFQsV0FBV3hULElBQUl3VCxRQUFyQjtBQUNBLFVBQU1TLFlBQVlqVSxJQUFJaVUsU0FBdEI7QUFDQSxVQUFNQyxXQUFXbFUsSUFBSWtVLFFBQXJCO0FBQ0EsVUFBTUMsT0FBT25VLElBQUlnVixLQUFqQjtBQUNBLFdBQU87QUFBRXhCLGNBQUY7QUFBWVMsZUFBWjtBQUF1QkMsY0FBdkI7QUFBaUNDO0FBQWpDLEtBQVA7QUFDRDtBQUVEOzs7Ozs7Ozs7QUFPQXBULFNBQU95UyxRQUFQLEVBQWlCO0FBQ2YsUUFBSXZXLE9BQU93QyxRQUFYLEVBQXFCO0FBQ25CLFlBQU1zVixVQUFVLEtBQUs3VixPQUFMLENBQWE7QUFBRXNVO0FBQUYsT0FBYixDQUFoQjs7QUFDQSxVQUFJdUIsT0FBSixFQUFhO0FBQ1gsYUFBSzdXLFdBQUwsQ0FBaUI2QyxNQUFqQixDQUF3QjtBQUFFeVM7QUFBRixTQUF4Qjs7QUFDQSxjQUFNZSxPQUFPVCxTQUFTVSxrQkFBVCxDQUE0QmhCLFFBQTVCLENBQWI7O0FBQ0EsWUFBSWUsSUFBSixFQUFVO0FBQ1J0WCxpQkFBT2dZLEtBQVAsQ0FBYWxVLE1BQWIsQ0FBb0J3VCxLQUFLbFYsR0FBekI7QUFDRDs7QUFDRCxlQUFPLElBQVA7QUFDRDtBQUNGOztBQUNELFdBQU8sS0FBUDtBQUNEO0FBRUQ7Ozs7Ozs7OztBQU9Bb0IsY0FBWTtBQUNWLFFBQUl4RCxPQUFPd0MsUUFBWCxFQUFxQjtBQUNuQixZQUFNeVYsZUFBZSxLQUFLaFgsV0FBTCxDQUFpQk0sSUFBakIsR0FBd0JtQyxLQUF4QixFQUFyQjs7QUFDQSxZQUFNQyxXQUFXLElBQWpCOztBQUNBbkQsUUFBRW9ELE9BQUYsQ0FBVXFVLFlBQVYsRUFBeUJILE9BQUQsSUFBYW5VLFNBQVNHLE1BQVQsQ0FBZ0JnVSxRQUFRdkIsUUFBeEIsQ0FBckM7QUFDRDs7QUFDRCxXQUFPLElBQVA7QUFDRDs7QUFwSWlEO0FBdUlwRDs7Ozs7O0FBSU8sTUFBTXRFLGVBQWUsSUFBSThFLHNCQUFKLEVBQXJCLEM7Ozs7Ozs7Ozs7O0FDeEpQOVcsT0FBT0MsS0FBUCxDQUFhQyxRQUFRLHVCQUFSLENBQWI7QUFBK0NGLE9BQU9DLEtBQVAsQ0FBYUMsUUFBUSwwQkFBUixDQUFiLEU7Ozs7Ozs7Ozs7O0FDQS9DRixPQUFPQyxLQUFQLENBQWFDLFFBQVEsaUJBQVIsQ0FBYjtBQUF5Q0YsT0FBT0MsS0FBUCxDQUFhQyxRQUFRLHdCQUFSLENBQWI7QUFBZ0RGLE9BQU9DLEtBQVAsQ0FBYUMsUUFBUSxrQkFBUixDQUFiO0FBQTBDRixPQUFPQyxLQUFQLENBQWFDLFFBQVEsc0JBQVIsQ0FBYjtBQUE4Q0YsT0FBT0MsS0FBUCxDQUFhQyxRQUFRLGtCQUFSLENBQWI7QUFBMENGLE9BQU9DLEtBQVAsQ0FBYUMsUUFBUSxxQkFBUixDQUFiO0FBQTZDRixPQUFPQyxLQUFQLENBQWFDLFFBQVEsb0JBQVIsQ0FBYjtBQUE0Q0YsT0FBT0MsS0FBUCxDQUFhQyxRQUFRLHFCQUFSLENBQWIsRTs7Ozs7Ozs7Ozs7QUNBcFRGLE9BQU9DLEtBQVAsQ0FBYUMsUUFBUSxlQUFSLENBQWI7QUFBdUNGLE9BQU9DLEtBQVAsQ0FBYUMsUUFBUSxnQkFBUixDQUFiO0FBQXdDRixPQUFPQyxLQUFQLENBQWFDLFFBQVEsY0FBUixDQUFiO0FBQXNDRixPQUFPQyxLQUFQLENBQWFDLFFBQVEsY0FBUixDQUFiLEU7Ozs7Ozs7Ozs7O0FDQXJILElBQUlILE1BQUo7QUFBV0MsT0FBT0MsS0FBUCxDQUFhQyxRQUFRLGVBQVIsQ0FBYixFQUFzQztBQUFDSCxTQUFPSSxDQUFQLEVBQVM7QUFBQ0osYUFBT0ksQ0FBUDtBQUFTOztBQUFwQixDQUF0QyxFQUE0RCxDQUE1RDtBQUErRCxJQUFJK0wsUUFBSjtBQUFhbE0sT0FBT0MsS0FBUCxDQUFhQyxRQUFRLHdDQUFSLENBQWIsRUFBK0Q7QUFBQ2dNLFdBQVMvTCxDQUFULEVBQVc7QUFBQytMLGVBQVMvTCxDQUFUO0FBQVc7O0FBQXhCLENBQS9ELEVBQXlGLENBQXpGOztBQUl2RixTQUFTOFgsU0FBVCxHQUFxQjtBQUNuQjtBQUNBLFFBQU1DLFFBQVFuWSxPQUFPb1ksUUFBUCxDQUFnQnZHLFFBQWhCLElBQTRCLEVBQTFDO0FBQ0F2QyxVQUFRQyxHQUFSLENBQWEsZ0JBQWU0SSxNQUFNcE4sTUFBTyxhQUF6QztBQUNBb04sUUFBTXJWLEdBQU4sQ0FBVWdQLE9BQU8zRixTQUFTL0ksTUFBVCxDQUFnQjBPLEdBQWhCLENBQWpCO0FBQ0Q7O0FBRUQ5UixPQUFPcVksT0FBUCxDQUFlLE1BQU07QUFDbkJIO0FBQ0QsQ0FGRCxFOzs7Ozs7Ozs7OztBQ1hBLElBQUlsWSxNQUFKO0FBQVdDLE9BQU9DLEtBQVAsQ0FBYUMsUUFBUSxlQUFSLENBQWIsRUFBc0M7QUFBQ0gsU0FBT0ksQ0FBUCxFQUFTO0FBQUNKLGFBQU9JLENBQVA7QUFBUzs7QUFBcEIsQ0FBdEMsRUFBNEQsQ0FBNUQ7QUFBK0QsSUFBSTZSLFlBQUo7QUFBaUJoUyxPQUFPQyxLQUFQLENBQWFDLFFBQVEsd0NBQVIsQ0FBYixFQUErRDtBQUFDOFIsZUFBYTdSLENBQWIsRUFBZTtBQUFDNlIsbUJBQWE3UixDQUFiO0FBQWU7O0FBQWhDLENBQS9ELEVBQWlHLENBQWpHOztBQUkzRixTQUFTa1ksU0FBVCxHQUFxQjtBQUNuQjtBQUNBLFFBQU1DLFdBQVd2WSxPQUFPb1ksUUFBUCxDQUFnQkgsWUFBaEIsSUFBZ0MsRUFBakQ7QUFDQTNJLFVBQVFDLEdBQVIsQ0FBYSxnQkFBZWdKLFNBQVN4TixNQUFPLGlCQUE1QztBQUNBd04sV0FBU3pWLEdBQVQsQ0FBYWdWLFdBQVc3RixhQUFhN08sTUFBYixDQUFvQjBVLE9BQXBCLENBQXhCO0FBQ0Q7O0FBRUQ5WCxPQUFPcVksT0FBUCxDQUFlLE1BQU07QUFDbkJDO0FBQ0QsQ0FGRCxFOzs7Ozs7Ozs7OztBQ1hBLElBQUlyVSxTQUFKO0FBQWNoRSxPQUFPQyxLQUFQLENBQWFDLFFBQVEsMENBQVIsQ0FBYixFQUFpRTtBQUFDOEQsWUFBVTdELENBQVYsRUFBWTtBQUFDNkQsZ0JBQVU3RCxDQUFWO0FBQVk7O0FBQTFCLENBQWpFLEVBQTZGLENBQTdGO0FBQWdHLElBQUlpVyxTQUFKO0FBQWNwVyxPQUFPQyxLQUFQLENBQWFDLFFBQVEscUNBQVIsQ0FBYixFQUE0RDtBQUFDa1csWUFBVWpXLENBQVYsRUFBWTtBQUFDaVcsZ0JBQVVqVyxDQUFWO0FBQVk7O0FBQTFCLENBQTVELEVBQXdGLENBQXhGO0FBQTJGLElBQUk4RCxNQUFKO0FBQVdqRSxPQUFPQyxLQUFQLENBQWFDLFFBQVEsbUNBQVIsQ0FBYixFQUEwRDtBQUFDK0QsU0FBTzlELENBQVAsRUFBUztBQUFDOEQsYUFBTzlELENBQVA7QUFBUzs7QUFBcEIsQ0FBMUQsRUFBZ0YsQ0FBaEY7QUFBbUYsSUFBSTRSLE1BQUo7QUFBVy9SLE9BQU9DLEtBQVAsQ0FBYUMsUUFBUSxzQ0FBUixDQUFiLEVBQTZEO0FBQUM2UixTQUFPNVIsQ0FBUCxFQUFTO0FBQUM0UixhQUFPNVIsQ0FBUDtBQUFTOztBQUFwQixDQUE3RCxFQUFtRixDQUFuRjtBQUFzRixJQUFJMlIsV0FBSjtBQUFnQjlSLE9BQU9DLEtBQVAsQ0FBYUMsUUFBUSxpREFBUixDQUFiLEVBQXdFO0FBQUM0UixjQUFZM1IsQ0FBWixFQUFjO0FBQUMyUixrQkFBWTNSLENBQVo7QUFBYzs7QUFBOUIsQ0FBeEUsRUFBd0csQ0FBeEc7QUFBMkcsSUFBSStMLFFBQUo7QUFBYWxNLE9BQU9DLEtBQVAsQ0FBYUMsUUFBUSx3Q0FBUixDQUFiLEVBQStEO0FBQUNnTSxXQUFTL0wsQ0FBVCxFQUFXO0FBQUMrTCxlQUFTL0wsQ0FBVDtBQUFXOztBQUF4QixDQUEvRCxFQUF5RixDQUF6RjtBQUE0RixJQUFJOEwsWUFBSjtBQUFpQmpNLE9BQU9DLEtBQVAsQ0FBYUMsUUFBUSwrQ0FBUixDQUFiLEVBQXNFO0FBQUMrTCxlQUFhOUwsQ0FBYixFQUFlO0FBQUM4TCxtQkFBYTlMLENBQWI7QUFBZTs7QUFBaEMsQ0FBdEUsRUFBd0csQ0FBeEc7QUFBMkcsSUFBSTZSLFlBQUo7QUFBaUJoUyxPQUFPQyxLQUFQLENBQWFDLFFBQVEsd0NBQVIsQ0FBYixFQUErRDtBQUFDOFIsZUFBYTdSLENBQWIsRUFBZTtBQUFDNlIsbUJBQWE3UixDQUFiO0FBQWU7O0FBQWhDLENBQS9ELEVBQWlHLENBQWpHO0FBU3Z3QjZELFVBQVUxQixPQUFWO0FBQ0E4VCxVQUFVOVQsT0FBVjtBQUNBMkIsT0FBTzNCLE9BQVA7QUFDQTJKLGFBQWEzSixPQUFiO0FBQ0E0SixTQUFTNUosT0FBVDtBQUNBd1AsWUFBWXhQLE9BQVo7QUFDQXlQLE9BQU96UCxPQUFQO0FBQ0EwUCxhQUFhMVAsT0FBYixHOzs7Ozs7Ozs7OztBQ2hCQSxJQUFJdkMsTUFBSjtBQUFXQyxPQUFPQyxLQUFQLENBQWFDLFFBQVEsZUFBUixDQUFiLEVBQXNDO0FBQUNILFNBQU9JLENBQVAsRUFBUztBQUFDSixhQUFPSSxDQUFQO0FBQVM7O0FBQXBCLENBQXRDLEVBQTRELENBQTVEO0FBQStELElBQUlvWSxVQUFKO0FBQWV2WSxPQUFPQyxLQUFQLENBQWFDLFFBQVEsOEJBQVIsQ0FBYixFQUFxRDtBQUFDcVksYUFBV3BZLENBQVgsRUFBYTtBQUFDb1ksaUJBQVdwWSxDQUFYO0FBQWE7O0FBQTVCLENBQXJELEVBQW1GLENBQW5GO0FBQXNGLElBQUkyUixXQUFKO0FBQWdCOVIsT0FBT0MsS0FBUCxDQUFhQyxRQUFRLGlEQUFSLENBQWIsRUFBd0U7QUFBQzRSLGNBQVkzUixDQUFaLEVBQWM7QUFBQzJSLGtCQUFZM1IsQ0FBWjtBQUFjOztBQUE5QixDQUF4RSxFQUF3RyxDQUF4RztBQUkvTG9ZLFdBQVdDLE1BQVgsQ0FBa0I7QUFDaEJsSixPQUFLdlAsT0FBT29ZLFFBQVAsQ0FBZ0JNO0FBREwsQ0FBbEI7O0FBSUEsU0FBU0MseUJBQVQsR0FBcUM7QUFDbkM7QUFDQSxRQUFNQyx3QkFBd0I1WSxPQUFPb1ksUUFBUCxDQUFnQlMsZ0NBQWhCLElBQW9ELEVBQWxGO0FBQ0FMLGFBQVc1QyxHQUFYLENBQWU7QUFDYnpULFVBQU0sa0VBRE87O0FBRWIyVyxhQUFTQyxNQUFULEVBQWlCO0FBQ2YsYUFBT0EsT0FBT0MsSUFBUCxDQUFhLFNBQVFKLHFCQUFzQixVQUEzQyxDQUFQLENBRGUsQ0FDK0M7QUFDL0QsS0FKWTs7QUFLYkssVUFBTTtBQUNKbEgsa0JBQVk2QixZQUFaO0FBQ0Q7O0FBUFksR0FBZjtBQVNBdEUsVUFBUUMsR0FBUixDQUFhLG9EQUFtRHFKLHFCQUFzQixXQUF0RjtBQUNBSixhQUFXOUMsS0FBWDtBQUNEOztBQUVEMVYsT0FBT3FZLE9BQVAsQ0FBZSxNQUFNO0FBQ25CTTtBQUNELENBRkQsRTs7Ozs7Ozs7Ozs7QUN4QkExWSxPQUFPK0QsTUFBUCxDQUFjO0FBQUNHLG9CQUFpQixNQUFJQSxnQkFBdEI7QUFBdUMrVSxzQkFBbUIsTUFBSUEsa0JBQTlEO0FBQWlGQyxpQkFBYyxNQUFJQSxhQUFuRztBQUFpSHpQLGtCQUFlLE1BQUlBO0FBQXBJLENBQWQ7QUFBbUssSUFBSTFKLE1BQUo7QUFBV0MsT0FBT0MsS0FBUCxDQUFhQyxRQUFRLGVBQVIsQ0FBYixFQUFzQztBQUFDSCxTQUFPSSxDQUFQLEVBQVM7QUFBQ0osYUFBT0ksQ0FBUDtBQUFTOztBQUFwQixDQUF0QyxFQUE0RCxDQUE1RDtBQUErRCxJQUFJaUgsS0FBSjtBQUFVcEgsT0FBT0MsS0FBUCxDQUFhQyxRQUFRLGNBQVIsQ0FBYixFQUFxQztBQUFDa0gsUUFBTWpILENBQU4sRUFBUTtBQUFDaUgsWUFBTWpILENBQU47QUFBUTs7QUFBbEIsQ0FBckMsRUFBeUQsQ0FBekQ7QUFBNEQsSUFBSUssTUFBSjtBQUFXUixPQUFPQyxLQUFQLENBQWFDLFFBQVEsUUFBUixDQUFiLEVBQStCO0FBQUNJLFVBQVFILENBQVIsRUFBVTtBQUFDSyxhQUFPTCxDQUFQO0FBQVM7O0FBQXJCLENBQS9CLEVBQXNELENBQXREOztBQVl2VCxTQUFTK0QsZ0JBQVQsQ0FBMEJpVixLQUExQixFQUFpQ0MsVUFBakMsRUFBNkNDLE9BQTdDLEVBQXNEO0FBQzNELE1BQUlDLGNBQWMsSUFBbEI7QUFDQSxNQUFJQyxhQUFhLENBQWpCO0FBQ0EsUUFBTUMsV0FBV0wsUUFBUSxDQUF6QixDQUgyRCxDQUcvQjs7QUFFNUIsTUFBSSxDQUFDRyxXQUFMLEVBQWtCO0FBQ2hCQSxrQkFBY3ZaLE9BQU8wWixXQUFQLENBQW1CLE1BQU07QUFDckNSLHlCQUFtQk0sVUFBbkIsRUFBK0JDLFFBQS9CLEVBQXlDLEdBQXpDLEVBQThDLEVBQTlDLEVBQWtESCxPQUFsRCxFQURxQyxDQUN1QjtBQUM3RCxLQUZhLEVBRVhELFVBRlcsQ0FBZDtBQUdEOztBQUVELFNBQU87QUFDTHpTLG9CQUFnQjtBQUNkLFVBQUkyUyxXQUFKLEVBQWlCdlosT0FBTzRHLGFBQVAsQ0FBcUIyUyxXQUFyQjtBQUNqQkksY0FBUUMsTUFBUixDQUFlQyxLQUFmLENBQXFCLElBQXJCLEVBRmMsQ0FFYztBQUM3QixLQUpJOztBQUtMelQsY0FBVTBULFVBQVYsRUFBc0I7QUFDcEJOLG1CQUFhTSxVQUFiO0FBQ0Q7O0FBUEksR0FBUDtBQVNEOztBQVVNLFNBQVNaLGtCQUFULENBQTRCYSxPQUE1QixFQUFxQ1gsS0FBckMsRUFBNENZLFFBQTVDLEVBQXNEQyxRQUF0RCxFQUFnRVgsT0FBaEUsRUFBeUU7QUFDOUU7QUFDQSxRQUFNWSxjQUFjcFMsTUFBTW1FLElBQU4sQ0FBVyxJQUFJa08sTUFBSixDQUFXRixXQUFXLENBQXRCLENBQVgsQ0FBcEI7QUFDQUMsY0FBWSxDQUFaLElBQWlCLEdBQWpCO0FBQ0FBLGNBQVlBLFlBQVluUCxNQUFaLEdBQXFCLENBQWpDLElBQXNDLEdBQXRDO0FBRUEsUUFBTXFQLHFCQUFzQkwsVUFBVVgsS0FBWCxHQUFvQixHQUEvQztBQUNBLFFBQU1pQixjQUFjSixZQUFZRyxxQkFBcUIsS0FBakMsQ0FBcEI7QUFDQUYsY0FBWTlKLElBQVosQ0FBaUI0SixRQUFqQixFQUEyQixDQUEzQixFQUE4QkssY0FBYyxDQUE1QyxFQVI4RSxDQVM5RTs7QUFDQVYsVUFBUUMsTUFBUixDQUFlQyxLQUFmLENBQXFCLFFBQXJCLEVBVjhFLENBVTlDOztBQUNoQ0YsVUFBUUMsTUFBUixDQUFlQyxLQUFmLENBQXNCLE9BQU1QLE9BQVEsSUFBR1ksWUFBWUksSUFBWixDQUFpQixFQUFqQixDQUFxQixLQUFJRixtQkFBbUJHLE9BQW5CLENBQTJCLENBQTNCLENBQThCLElBQTlGO0FBQ0Q7O0FBVU0sTUFBTXBCLGdCQUFnQixDQUFDcUIsU0FBRCxFQUFZQyxRQUFaLEVBQXNCQyxRQUF0QixFQUFnQ0MsVUFBaEMsS0FBK0M7QUFDMUV0VCxRQUFNbVQsU0FBTixFQUFpQmhXLE1BQWpCO0FBQ0E2QyxRQUFNb1QsUUFBTixFQUFnQmpXLE1BQWhCO0FBQ0E2QyxRQUFNcVQsUUFBTixFQUFnQmxXLE1BQWhCO0FBQ0E2QyxRQUFNc1QsVUFBTixFQUFrQixDQUFDalcsTUFBRCxDQUFsQixFQUowRSxDQU0xRTtBQUNBOztBQUNBLFFBQU1rVyxzQkFBc0JDLEtBQUtDLEdBQUwsQ0FBU0osV0FBV0QsUUFBcEIsSUFBZ0NFLFdBQVc1UCxNQUF2RTtBQUVBLE1BQUlnUSxjQUFjLElBQWxCOztBQUNBLE9BQUssSUFBSWxYLElBQUksQ0FBYixFQUFnQkEsSUFBSThXLFdBQVc1UCxNQUEvQixFQUF1Q2xILEdBQXZDLEVBQTRDO0FBQzFDLFFBQUkyVyxZQUFZQyxXQUFZRyx1QkFBdUIvVyxJQUFJLENBQTNCLENBQTVCLEVBQTREO0FBQzFEa1gsb0JBQWNKLFdBQVc5VyxDQUFYLENBQWQ7QUFDQTtBQUNEO0FBQ0YsR0FoQnlFLENBa0IxRTtBQUNBOzs7QUFDQSxNQUFJLENBQUNrWCxXQUFMLEVBQWtCQSxjQUFjSixXQUFXQSxXQUFXNVAsTUFBWCxHQUFvQixDQUEvQixDQUFkO0FBRWxCLFNBQU9nUSxXQUFQO0FBQ0QsQ0F2Qk07O0FBZ0NBLE1BQU1yUixpQkFBaUIsQ0FBQ3NSLElBQUQsRUFBT3JSLFFBQVAsS0FBb0I7QUFDaEQsUUFBTXNSLFFBQVF4YSxPQUFPdWEsSUFBUCxDQUFkO0FBQ0EsUUFBTUUsT0FBT0QsTUFBTUMsSUFBTixFQUFiLENBRmdELENBRXJCOztBQUMzQixRQUFNQyxhQUFhRixNQUFNRCxJQUFOLEVBQW5CLENBSGdELENBR2Y7O0FBQ2pDLFFBQU1JLE1BQU1ILE1BQU1JLFNBQU4sRUFBWixDQUpnRCxDQUlqQjs7QUFDL0IsUUFBTUMsT0FBT0wsTUFBTUssSUFBTixFQUFiLENBTGdELENBS3JCOztBQUMzQixRQUFNNUcsUUFBUXVHLE1BQU12RyxLQUFOLEVBQWQsQ0FOZ0QsQ0FNbkI7O0FBQzdCLFFBQU1DLE9BQU9zRyxNQUFNdEcsSUFBTixFQUFiLENBUGdELENBT3JCO0FBRTNCOztBQUNBLE1BQUkzSyxXQUFKOztBQUNBLFVBQVFMLFFBQVI7QUFDRSxTQUFLLFdBQUw7QUFDRTtBQUNBSyxvQkFBZSxHQUFFa1IsSUFBSyxJQUFHRSxHQUFJLElBQUd6RyxJQUFLLEVBQXJDO0FBQ0E7O0FBQ0YsU0FBSyxZQUFMO0FBQ0U7QUFDQTNLLG9CQUFlLEdBQUVtUixVQUFXLElBQUd6RyxLQUFNLElBQUdDLElBQUssRUFBN0M7QUFDQTs7QUFDRixTQUFLLEtBQUw7QUFDRTtBQUNBM0ssb0JBQWUsR0FBRW9SLEdBQUksSUFBR3pHLElBQUssRUFBN0I7QUFDQTs7QUFDRixTQUFLLE1BQUw7QUFDRTtBQUNBM0ssb0JBQWUsR0FBRXNSLElBQUssSUFBRzNHLElBQUssRUFBOUI7QUFDQTs7QUFDRixTQUFLLE9BQUw7QUFDRTtBQUNBM0ssb0JBQWUsR0FBRTBLLEtBQU0sSUFBR0MsSUFBSyxFQUEvQjtBQUNBOztBQUNGLFNBQUssTUFBTDtBQUNFO0FBQ0EzSyxvQkFBYzJLLElBQWQ7QUFDQTs7QUFDRjtBQUNFO0FBMUJKOztBQTZCQSxTQUFPM0ssV0FBUDtBQUNELENBekNNLEM7Ozs7Ozs7Ozs7O0FDaEdQL0osT0FBT0MsS0FBUCxDQUFhQyxRQUFRLGtDQUFSLENBQWI7QUFBMERGLE9BQU9DLEtBQVAsQ0FBYUMsUUFBUSxvQ0FBUixDQUFiLEUiLCJmaWxlIjoiL2FwcC5qcyIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IE1ldGVvciB9IGZyb20gJ21ldGVvci9tZXRlb3InO1xuaW1wb3J0IHsgTW9uZ28gfSBmcm9tICdtZXRlb3IvbW9uZ28nO1xuaW1wb3J0IFNpbXBsZVNjaGVtYSBmcm9tICdzaW1wbC1zY2hlbWEnO1xuaW1wb3J0IF8gZnJvbSAnbG9kYXNoJztcbmltcG9ydCBNb21lbnQgZnJvbSAnbW9tZW50JztcblxuXG4vKipcbiAqIEJhc2VDb2xsZWN0aW9uIGlzIGFuIGFic3RyYWN0IHN1cGVyY2xhc3Mgb2YgYWxsIG90aGVyIGNvbGxlY3Rpb24gY2xhc3Nlcy5cbiAqL1xuY2xhc3MgQmFzZUNvbGxlY3Rpb24ge1xuXG4gIC8qKlxuICAgKiBTdXBlcmNsYXNzIGNvbnN0cnVjdG9yIGZvciBhbGwgY29sbGVjdGlvbnMuXG4gICAqIERlZmluZXMgaW50ZXJuYWwgZmllbGRzIHJlcXVpcmVkIGJ5IGFsbCBjb2xsZWN0aW9ucy5cbiAgICogQHBhcmFtIHtTdHJpbmd9IGNvbGxlY3Rpb25OYW1lIC0gVGhlIG5hbWUgb2YgdGhlIGNvbGxlY3Rpb24uXG4gICAqIEBwYXJhbSB7T2JqZWN0fSBzY2hlbWEgLSBUaGUgU2ltcGxlU2NoZW1hIGluc3RhbmNlIHRoYXQgZGVmaW5lcyB0aGlzIGNvbGxlY3Rpb24ncyBzY2hlbWEuXG4gICAqL1xuICBjb25zdHJ1Y3Rvcihjb2xsZWN0aW9uTmFtZSwgc2NoZW1hKSB7XG4gICAgaWYgKHR5cGVvZiBjb2xsZWN0aW9uTmFtZSAhPT0gJ3N0cmluZycpIHRocm93IG5ldyBNZXRlb3IuRXJyb3IoJ2NvbGxlY3Rpb25OYW1lIG11c3QgYmUgYSBTdHJpbmcuJyk7XG4gICAgaWYgKCEoc2NoZW1hIGluc3RhbmNlb2YgU2ltcGxlU2NoZW1hKSkgdGhyb3cgbmV3IE1ldGVvci5FcnJvcignc2NoZW1hIG11c3QgYmUgYSBTaW1wbGVTY2hlbWEgaW5zdGFuY2UuJyk7XG5cbiAgICB0aGlzLl9jb2xsZWN0aW9uTmFtZSA9IGNvbGxlY3Rpb25OYW1lO1xuICAgIHRoaXMuX3NjaGVtYSA9IHNjaGVtYTtcbiAgICB0aGlzLl9jb2xsZWN0aW9uID0gbmV3IE1vbmdvLkNvbGxlY3Rpb24oY29sbGVjdGlvbk5hbWUsIHsgaWRHZW5lcmF0aW9uOiAnTU9OR08nIH0pO1xuICAgIHRoaXMuX2NvbGxlY3Rpb24uYXR0YWNoU2NoZW1hKHNjaGVtYSk7XG4gIH1cblxuICAvKipcbiAgICogUmV0dXJucyB0aGUgc2NoZW1hIChTaW1wbGVTY2hlbWEpIGFzc29jaWF0ZWQgd2l0aCB0aGlzIGNvbGxlY3Rpb24uXG4gICAqIEByZXR1cm5zIHtTaW1wbGVTY2hlbWF9IC0gVGhlIFNpbXBsZVNjaGVtYSBpbnN0YW5jZS5cbiAgICovXG4gIGdldFNjaGVtYSgpIHtcbiAgICByZXR1cm4gdGhpcy5fc2NoZW1hO1xuICB9XG5cbiAgLyoqXG4gICAqIFJldHVybnMgdGhlIG51bWJlciBvZiBkb2N1bWVudHMgaW4gdGhpcyBjb2xsZWN0aW9uLlxuICAgKiBAcmV0dXJucyB7TnVtYmVyfSAtIFRoZSBudW1iZXIgb2YgZG9jdW1lbnRzIGluIHRoZSBjb2xsZWN0aW9uLlxuICAgKi9cbiAgY291bnQoKSB7XG4gICAgcmV0dXJuIHRoaXMuX2NvbGxlY3Rpb24uZmluZCgpLmNvdW50KCk7XG4gIH1cblxuICAvKipcbiAgICogUmV0dXJucyB0aGUgbnVtYmVyIG9mIGRvY3VtZW50cyBpbiB0aGlzIGNvbGxlY3Rpb24gd2l0aCBhIFVUQyBtaWxsaXNlY29uZCB0aW1lc3RhbXAgZ3JlYXRlciB0aGFuIHRvZGF5J3NcbiAgICogZGF0ZSBhdCBtaWRuaWdodC5cbiAgICogQHBhcmFtIHRpbWVGaWVsZCBUaGUgbmFtZSBvZiB0aGUgZmllbGQgY29udGFpbmluZyBhIHRpbWVzdGFtcCBpbiBVVEMgbWlsbGlzZWNvbmQgZm9ybWF0LlxuICAgKiBAcmV0dXJucyBUaGUgbnVtYmVyIG9mIGRvY3VtZW50cyB3aG9zZSB0aW1lc3RhbXAgaXMgZnJvbSB0b2RheS5cbiAgICovXG4gIGNvdW50VG9kYXkodGltZUZpZWxkKSB7XG4gICAgY29uc3Qgc3RhcnRUb2RheSA9IE1vbWVudCgpLnN0YXJ0T2YoJ2RheScpLnZhbHVlT2YoKTtcbiAgICBjb25zdCBxdWVyeSA9IHt9O1xuICAgIHF1ZXJ5W3RpbWVGaWVsZF0gPSB7ICRndGU6IHN0YXJ0VG9kYXkgfTtcbiAgICByZXR1cm4gdGhpcy5fY29sbGVjdGlvbi5maW5kKHF1ZXJ5KS5jb3VudCgpO1xuXG4gIH1cblxuICAvKipcbiAgICogQ2FsbHMgdGhlIE1vbmdvREIgbmF0aXZlIGZpbmQoKSBvbiB0aGlzIGNvbGxlY3Rpb24uXG4gICAqIEBzZWUge0BsaW5rIGh0dHA6Ly9kb2NzLm1ldGVvci5jb20vYXBpL2NvbGxlY3Rpb25zLmh0bWwjTW9uZ28tQ29sbGVjdGlvbi1maW5kfE1ldGVvciBEb2NzIE1vbmdvLkNvbGxlY3Rpb24uZmluZCgpfVxuICAgKiBAcGFyYW0ge09iamVjdH0gc2VsZWN0b3IgLSBBIE1vbmdvREIgc2VsZWN0b3Igb2JqZWN0LlxuICAgKiBAcGFyYW0ge09iamVjdH0gb3B0aW9ucyAtIEEgTW9uZ29EQiBvcHRpb25zIG9iamVjdC5cbiAgICogQHJldHVybnMge0N1cnNvcn0gLSBUaGUgTW9uZ29EQiBjdXJzb3IgY29udGFpbmluZyB0aGUgcmVzdWx0cyBvZiB0aGUgcXVlcnkuXG4gICAqL1xuICBmaW5kKHNlbGVjdG9yID0ge30sIG9wdGlvbnMgPSB7fSkge1xuICAgIHJldHVybiB0aGlzLl9jb2xsZWN0aW9uLmZpbmQoc2VsZWN0b3IsIG9wdGlvbnMpO1xuICB9XG5cbiAgLyoqXG4gICAqIENhbGxzIHRoZSBNb25nb0RCIG5hdGl2ZSBmaW5kT25lKCkgb24gdGhpcyBjb2xsZWN0aW9uLlxuICAgKiBAc2VlIHtAbGluayBodHRwOi8vZG9jcy5tZXRlb3IuY29tL2FwaS9jb2xsZWN0aW9ucy5odG1sI01vbmdvLUNvbGxlY3Rpb24tZmluZE9uZXxcbiAgICogTWV0ZW9yIERvY3MgTW9uZ28uQ29sbGVjdGlvbi5maW5kT25lKCl9XG4gICAqIEBwYXJhbSB7T2JqZWN0fSBzZWxlY3RvciAtIEEgTW9uZ29EQiBzZWxlY3RvciBvYmplY3QuXG4gICAqIEBwYXJhbSB7T2JqZWN0fSBvcHRpb25zIC0gQSBNb25nb0RCIG9wdGlvbnMgb2JqZWN0LlxuICAgKiBAcmV0dXJucyB7T2JqZWN0fSAtIFRoZSBkb2N1bWVudCBjb250YWluaW5nIHRoZSByZXN1bHRzIG9mIHRoZSBxdWVyeS5cbiAgICovXG4gIGZpbmRPbmUoc2VsZWN0b3IgPSB7fSwgb3B0aW9ucyA9IHt9KSB7XG4gICAgcmV0dXJuIHRoaXMuX2NvbGxlY3Rpb24uZmluZE9uZShzZWxlY3Rvciwgb3B0aW9ucyk7XG4gIH1cblxuICAvKipcbiAgICogUmV0dXJucyB0cnVlIGlmIHRoZSBwYXNzZWQgZW50aXR5IGlzIGluIHRoaXMgY29sbGVjdGlvbi5cbiAgICogQHBhcmFtIHsgU3RyaW5nIHwgT2JqZWN0IH0gbmFtZSBUaGUgZG9jSUQsIG9yIGFuIG9iamVjdCBzcGVjaWZ5aW5nIGEgZG9jdW1lbnQuXG4gICAqIEByZXR1cm5zIHtib29sZWFufSBUcnVlIGlmIG5hbWUgZXhpc3RzIGluIHRoaXMgY29sbGVjdGlvbi5cbiAgICovXG4gIGlzRGVmaW5lZChuYW1lKSB7XG4gICAgcmV0dXJuIChcbiAgICAgICEhdGhpcy5fY29sbGVjdGlvbi5maW5kT25lKG5hbWUpIHx8XG4gICAgICAhIXRoaXMuX2NvbGxlY3Rpb24uZmluZE9uZSh7IG5hbWUgfSkgfHxcbiAgICAgICEhdGhpcy5fY29sbGVjdGlvbi5maW5kT25lKHsgX2lkOiBuYW1lIH0pKTtcbiAgfVxuXG4gIC8qKlxuICAgKiBVcGRhdGUgdGhlIGNvbGxlY3Rpb24uXG4gICAqIEBwYXJhbSBzZWxlY3RvclxuICAgKiBAcGFyYW0gbW9kaWZpZXJcbiAgICogQHBhcmFtIG9wdGlvbnNcbiAgICogQHJldHVybnMge2FueX1cbiAgICovXG4gIHVwZGF0ZShzZWxlY3RvciA9IHt9LCBtb2RpZmllciA9IHt9LCBvcHRpb25zID0ge30pIHtcbiAgICByZXR1cm4gdGhpcy5fY29sbGVjdGlvbi51cGRhdGUoc2VsZWN0b3IsIG1vZGlmaWVyLCBvcHRpb25zKTtcbiAgfVxuXG4gIC8qKlxuICAgKiBEZWZhdWx0IHB1YmxpY2F0aW9uIG9mIGNvbGxlY3Rpb24gKHB1Ymxpc2hlcyBlbnRpcmUgY29sbGVjdGlvbikuIERlcml2ZWQgY2xhc3NlcyB3aWxsIG9mdGVuIG92ZXJyaWRlIHdpdGhcbiAgICogdGhlaXIgb3duIHB1Ymxpc2goKSBtZXRob2QsIGFzIGl0cyBnZW5lcmFsbHkgYSBiYWQgaWRlYSB0byBwdWJsaXNoIHRoZSBlbnRpcmUgY29sbGVjdGlvbiB0byB0aGUgY2xpZW50LlxuICAgKi9cbiAgcHVibGlzaCgpIHtcbiAgICBpZiAoTWV0ZW9yLmlzU2VydmVyKSB7XG4gICAgICBNZXRlb3IucHVibGlzaCh0aGlzLl9jb2xsZWN0aW9uTmFtZSwgKCkgPT4gdGhpcy5fY29sbGVjdGlvbi5maW5kKCkpO1xuICAgIH1cbiAgfVxuXG4gIC8qKlxuICAgKiBEZWZhdWx0IHZlcnNpb24gb2YgZ2V0UHVibGljYXRpb25OYW1lIHJldHVybnMgdGhlIHNpbmdsZSBwdWJsaWNhdGlvbiBuYW1lLlxuICAgKiBEZXJpdmVkIGNsYXNzZXMgbWFueSBuZWVkIHRvIG92ZXJyaWRlIHRoaXMgbWV0aG9kIGFzIHdlbGwuXG4gICAqIEByZXR1cm5zIFRoZSBkZWZhdWx0IHB1YmxpY2F0aW9uIG5hbWUuXG4gICAqL1xuICBnZXRQdWJsaWNhdGlvbk5hbWUoKSB7XG4gICAgcmV0dXJuIHRoaXMuX2NvbGxlY3Rpb25OYW1lO1xuICB9XG5cbiAgLyoqXG4gICAqIFJldHVybnMgYW4gb2JqZWN0IHJlcHJlc2VudGluZyB0aGUgZGVmaW5pdGlvbiBvZiBkb2NJRCBpbiBhIGZvcm1hdCBhcHByb3ByaWF0ZSB0byB0aGUgcmVzdG9yZU9uZSBmdW5jdGlvbi5cbiAgICogTXVzdCBiZSBvdmVycmlkZGVuIGJ5IGVhY2ggY29sbGVjdGlvbi5cbiAgICogQHBhcmFtIGRvY0lEIC0gQSBkb2NJRCBmcm9tIHRoaXMgY29sbGVjdGlvbi5cbiAgICogQHJldHVybnMgeyBPYmplY3QgfSAtIEFuIG9iamVjdCByZXByZXNlbnRpbmcgdGhpcyBkb2N1bWVudC5cbiAgICovXG4gIGR1bXBPbmUoZG9jSUQpIHsgLy8gZXNsaW50LWRpc2FibGUtbGluZSBuby11bnVzZWQtdmFyc1xuICAgIHRocm93IG5ldyBNZXRlb3IuRXJyb3IoYERlZmF1bHQgZHVtcE9uZSBtZXRob2QgaW52b2tlZCBieSBjb2xsZWN0aW9uICR7dGhpcy5fY29sbGVjdGlvbk5hbWV9YCk7XG4gIH1cblxuICAvKipcbiAgICogRHVtcHMgdGhlIGVudGlyZSBjb2xsZWN0aW9uIGFzIGEgc2luZ2xlIG9iamVjdCB3aXRoIHR3byBmaWVsZHM6IG5hbWUgYW5kIGNvbnRlbnRzLlxuICAgKiBUaGUgbmFtZSBpcyB0aGUgbmFtZSBvZiB0aGUgY29sbGVjdGlvbi5cbiAgICogVGhlIGNvbnRlbnRzIGlzIGFuIGFycmF5IG9mIGFsbCBkb2N1bWVudHMgd2l0aGluIHRoZSBjb2xsZWN0aW9uLiBUaGVzZSBkb2N1bWVudHMgYXJlIGdlbmVyYXRlZCB1c2luZyB0aGVcbiAgICogZHVtcE9uZSgpIG1ldGhvZCBhbmQgc3Vic2VxdWVudGx5IGFyZSBtZWFudCB0byBiZSB1c2VkIHdpdGggdGhlIHJlc3RvcmUoKSBtZXRob2QuXG4gICAqIEByZXR1cm5zIHtPYmplY3R9IEFuIG9iamVjdCByZXByZXNlbnRpbmcgdGhlIGNvbnRlbnRzIG9mIHRoaXMgY29sbGVjdGlvbi5cbiAgICovXG4gIGR1bXBBbGwoKSB7XG4gICAgcmV0dXJuIHsgbmFtZTogdGhpcy5fY29sbGVjdGlvbk5hbWUsIGNvbnRlbnRzOiB0aGlzLmZpbmQoKS5tYXAoZG9jID0+IHRoaXMuZHVtcE9uZShkb2MuX2lkKSkgfTtcbiAgfVxuXG4gIC8qKlxuICAgKiBGaW5kcyBhbmQgcmV0dXJucyB0aGUgZW50aXJlIGRvY3VtZW50IG9mIHRoZSBnaXZlbiBkb2NJRC5cbiAgICogQHBhcmFtIHtPYmplY3R9IGRvY0lEIC0gVGhlIE1vbmdvLk9iamVjdElEIG9mIHRoZSBkb2N1bWVudCB0byBmaW5kLlxuICAgKiBAcmV0dXJucyB7T2JqZWN0fSAtIFRoZSBmb3VuZCBkb2N1bWVudC5cbiAgICovXG4gIGZpbmREb2MoZG9jSUQpIHtcbiAgICBjb25zdCBkb2MgPSB0aGlzLmZpbmRPbmUoeyBfaWQ6IGRvY0lEIH0sIHt9KTtcbiAgICBpZiAoIWRvYykge1xuICAgICAgdGhyb3cgbmV3IE1ldGVvci5FcnJvcihgQ291bGQgbm90IGZpbmQgZG9jdW1lbnQgd2l0aCBkb2NJRDogJHtkb2NJRH0gaW4gY29sbGVjdGlvbjogJHt0aGlzLl9jb2xsZWN0aW9uTmFtZX0uYCk7XG4gICAgfVxuICAgIHJldHVybiBkb2M7XG4gIH1cblxuICAvKipcbiAgICogRGVmaW5lcyB0aGUgZGVmYXVsdCBpbnRlZ3JpdHkgY2hlY2tlciBmb3IgdGhlIGJhc2UgY29sbGVjdGlvbi4gRGVyaXZlZCBjbGFzc2VzIGFyZSByZXNwb25zaWJsZSBmb3IgaW1wbGVtZW50aW5nXG4gICAqIHRoZWlyIG93biBpbnRlZ3JpdHkgY2hlY2tlciwgaWYgaXQgaXMgbmVlZGVkLlxuICAgKiBAcmV0dXJucyB7W1N0cmluZ119IC0gQXJyYXkgY29udGFpbmluZyBhIHN0cmluZyBpbmRpY2F0aW5nIHRoZSB1c2Ugb2YgdGhlIGRlZmF1bHQgaW50ZWdyaXR5IGNoZWNrZXIuXG4gICAqL1xuICBjaGVja0ludGVncml0eSgpIHsgLy8gZXNsaW50LWRpc2FibGUtbGluZSBjbGFzcy1tZXRob2RzLXVzZS10aGlzXG4gICAgcmV0dXJuIFsnVGhlcmUgaXMgbm8gaW50ZWdyaXR5IGNoZWNrZXIgZGVmaW5lZCBmb3IgdGhpcyBjb2xsZWN0aW9uLiddO1xuICB9XG5cbiAgLyoqXG4gICAqIERlZmluZXMgYSBzaW5nbGUgY29sbGVjdGlvbiBkb2N1bWVudCByZXByZXNlbnRlZCBieSBkdW1wT2JqZWN0LlxuICAgKiBAcmV0dXJucyB7U3RyaW5nfSAtIFRoZSBuZXdseSBjcmVhdGVkIGRvY3VtZW50IElELlxuICAgKi9cbiAgcmVzdG9yZU9uZShkdW1wT2JqZWN0KSB7XG4gICAgaWYgKHR5cGVvZiB0aGlzLmRlZmluZSA9PT0gJ2Z1bmN0aW9uJykge1xuICAgICAgcmV0dXJuIHRoaXMuZGVmaW5lKGR1bXBPYmplY3QpO1xuICAgIH1cbiAgICByZXR1cm4gbnVsbDtcbiAgfVxuXG4gIC8qKlxuICAgKiBEZWZpbmVzIGVhY2ggY29sbGVjdGlvbiBlbnRpdHkgZ2l2ZW4gYnkgdGhlIHBhc3NlZCBhcnJheSBvZiBkdW1wT2JqZWN0cy5cbiAgICogQHBhcmFtIGR1bXBPYmplY3RzIC0gVGhlIGFycmF5IG9mIG9iamVjdHMgcmVwcmVzZW50aW5nIGVudGl0aWVzIG9mIHRoZSBjb2xsZWN0aW9uLlxuICAgKi9cbiAgcmVzdG9yZUFsbChkdW1wT2JqZWN0cykge1xuICAgIF8uZWFjaChkdW1wT2JqZWN0cywgZHVtcE9iamVjdCA9PiB0aGlzLnJlc3RvcmVPbmUoZHVtcE9iamVjdCkpO1xuICB9XG5cbiAgLyoqXG4gICAqIFJlbW92ZXMgYWxsIGVsZW1lbnRzIG9mIHRoaXMgY29sbGVjdGlvbi5cbiAgICogVGhpcyBpcyBpbXBsZW1lbnRlZCBieSBtYXBwaW5nIHRocm91Z2ggYWxsIGVsZW1lbnRzIGJlY2F1c2UgbWluaS1tb25nbyBkb2VzIG5vdCBpbXBsZW1lbnQgdGhlIHJlbW92ZSBvcGVyYXRpb24uXG4gICAqIFNvIHRoaXMgYXBwcm9hY2ggY2FuIGJlIHVzZWQgb24gYm90aCBjbGllbnQgYW5kIHNlcnZlciBzaWRlLlxuICAgKiByZW1vdmVBbGwgc2hvdWxkIG9ubHkgdXNlZCBmb3IgdGVzdGluZyBwdXJwb3Nlcywgc28gaXQgZG9lc24ndCBuZWVkIHRvIGJlIGVmZmljaWVudC5cbiAgICogQHJldHVybnMgdHJ1ZVxuICAgKi9cbiAgcmVtb3ZlQWxsKCkge1xuICAgIGNvbnN0IGl0ZW1zID0gdGhpcy5fY29sbGVjdGlvbi5maW5kKCkuZmV0Y2goKTtcbiAgICBjb25zdCBpbnN0YW5jZSA9IHRoaXM7XG4gICAgXy5mb3JFYWNoKGl0ZW1zLCAoaSkgPT4ge1xuICAgICAgaW5zdGFuY2UucmVtb3ZlKGkuX2lkKTtcbiAgICB9KTtcbiAgICByZXR1cm4gdHJ1ZTtcbiAgfVxuXG4gIC8qKlxuICAgKiBEZWZhdWx0IHJlbW92ZSBmdW5jdGlvbiBjYWxscyByZW1vdmUgd2l0aCB0aGUgZG9jSUQuXG4gICAqIEBwYXJhbSBkb2NJRCBUaGUgZG9jSUQgb2YgdGhlIGRvY3VtZW50IHRvIGJlIHJlbW92ZWQuXG4gICAqL1xuICByZW1vdmUoZG9jSUQpIHtcbiAgICB0aGlzLl9jb2xsZWN0aW9uLnJlbW92ZShkb2NJRCk7XG4gIH1cbn1cblxuZXhwb3J0IGRlZmF1bHQgQmFzZUNvbGxlY3Rpb247XG4iLCJpbXBvcnQgeyBNZXRlb3IgfSBmcm9tICdtZXRlb3IvbWV0ZW9yJztcbmltcG9ydCB7IE1vbmdvIH0gZnJvbSAnbWV0ZW9yL21vbmdvJztcbmltcG9ydCBTaW1wbGVTY2hlbWEgZnJvbSAnc2ltcGwtc2NoZW1hJztcbmltcG9ydCBCYXNlQ29sbGVjdGlvbiBmcm9tICcuLi9iYXNlL0Jhc2VDb2xsZWN0aW9uLmpzJztcbmltcG9ydCB7IEV2ZW50cyB9IGZyb20gJy4uL2V2ZW50cy9FdmVudHNDb2xsZWN0aW9uJztcbmltcG9ydCB7IHByb2dyZXNzQmFyU2V0dXAgfSBmcm9tICcuLi8uLi9tb2R1bGVzL3V0aWxzJztcblxuLyoqXG4gKiBDb2xsZWN0aW9uIGNsYXNzIGZvciB0aGUgYm94X2V2ZW50cyBjb2xsZWN0aW9uLlxuICogRG9jczogaHR0cHM6Ly9vcGVuLXBvd2VyLXF1YWxpdHkuZ2l0Ym9va3MuaW8vb3Blbi1wb3dlci1xdWFsaXR5LW1hbnVhbC9jb250ZW50L2RhdGFtb2RlbC9kZXNjcmlwdGlvbi5odG1sI2JveF9ldmVudHNcbiAqL1xuY2xhc3MgQm94RXZlbnRzQ29sbGVjdGlvbiBleHRlbmRzIEJhc2VDb2xsZWN0aW9uIHtcblxuICAvKipcbiAgICogQ3JlYXRlcyB0aGUgY29sbGVjdGlvbi5cbiAgICovXG4gIGNvbnN0cnVjdG9yKCkge1xuICAgIHN1cGVyKCdib3hfZXZlbnRzJywgbmV3IFNpbXBsZVNjaGVtYSh7XG4gICAgICBfaWQ6IHsgdHlwZTogTW9uZ28uT2JqZWN0SUQgfSxcbiAgICAgIGV2ZW50X2lkOiBOdW1iZXIsXG4gICAgICBib3hfaWQ6IFN0cmluZyxcbiAgICAgIGV2ZW50X3N0YXJ0X3RpbWVzdGFtcF9tczogTnVtYmVyLFxuICAgICAgZXZlbnRfZW5kX3RpbWVzdGFtcF9tczogTnVtYmVyLFxuICAgICAgd2luZG93X3RpbWVzdGFtcHNfbXM6IFtOdW1iZXJdLCAvLyBGb3IgcmVzZWFyY2ggcHVycG9zZXMuXG4gICAgICB0aGQ6IE51bWJlcixcbiAgICAgIGl0aWM6IFN0cmluZyxcbiAgICAgIGxvY2F0aW9uOiB7IHR5cGU6IE9iamVjdCwgb3B0aW9uYWw6IHRydWUgfSxcbiAgICAgICdsb2NhdGlvbi5zdGFydF90aW1lJzogeyB0eXBlOiBOdW1iZXIsIG9wdGlvbmFsOiB0cnVlIH0sXG4gICAgICAnbG9jYXRpb24uemlwY29kZSc6IHsgdHlwZTogTnVtYmVyLCBvcHRpb25hbDogdHJ1ZSB9LFxuICAgICAgZGF0YV9mc19maWxlbmFtZTogU3RyaW5nLCAvLyBTdG9yZXMgdGhlIEdyaWRGcyBmaWxlbmFtZS4gRm9ybWF0IGlzICdldmVudF9ldmVudE51bWJlcl9ib3hJZCdcbiAgICB9KSk7XG5cbiAgICB0aGlzLnB1YmxpY2F0aW9uTmFtZXMgPSB7XG4gICAgICBFVkVOVF9EQVRBOiAnZXZlbnRfZGF0YScsXG4gICAgfTtcbiAgICBpZiAoTWV0ZW9yLnNlcnZlcikge1xuICAgICAgdGhpcy5fY29sbGVjdGlvbi5yYXdDb2xsZWN0aW9uKCkuY3JlYXRlSW5kZXgoeyBldmVudF9zdGFydF90aW1lc3RhbXBfbXM6IDEsIGJveF9pZDogMSB9LCB7IGJhY2tncm91bmQ6IHRydWUgfSk7XG4gICAgfVxuICB9XG5cbiAgLyoqXG4gICAqIERlZmluZXMgYSBuZXcgQm94RXZlbnQgZG9jdW1lbnQuXG4gICAqIEBwYXJhbSB7TnVtYmVyfSBldmVudF9pZCAtIFRoZSBldmVudF9pZCBhc3NvY2lhdGVkIHdpdGggdGhlIEJveEV2ZW50LlxuICAgKiBAcGFyYW0ge1N0cmluZ30gYm94X2lkIC0gVGhlIGJveF9pZCBhc3NvY2lhdGVkIHdpdGggdGhlIEJveEV2ZW50LlxuICAgKiBAcGFyYW0ge051bWJlcn0gZXZlbnRfc3RhcnQgLSBUaGUgc3RhcnQgdGltZXN0YW1wICh1bml4IG1pbGxpc2Vjb25kcykgb2YgdGhlIGV2ZW50LlxuICAgKiBAcGFyYW0ge051bWJlcn0gZXZlbnRfZW5kIC0gVGhlIGVuZCB0aW1lc3RhbXAgKHVuaXggbWlsbGlzZWNvbmRzKSBvZiB0aGUgZXZlbnQuXG4gICAqIEBwYXJhbSB7W051bWJlcl19IHdpbmRvd190aW1lc3RhbXBzIC0gQW4gYXJyYXkgb2YgdGltZXN0YW1wcywgZm9yIHJlc2VhcmNoIHB1cnBvc2VzLiBTZWUgZG9jcyBmb3IgZGV0YWlscy5cbiAgICogQHBhcmFtIHtOdW1iZXJ9IHRoZCAtIFRoZSB0b3RhbCBoYXJtb25pYyBkaXN0b3J0aW9uIHZhbHVlIG9mIHRoZSBldmVudC5cbiAgICogQHBhcmFtIHtTdHJpbmd9IGl0aWMgLSBUaGUgSVRJQyB2YWx1ZSBvZiB0aGUgZXZlbnQuXG4gICAqIEBwYXJhbSB7T2JqZWN0fSBsb2NhdGlvbiAtIFRoZSBsb2NhdGlvbiBvZiB0aGUgT1BRQm94IGF0IHRoZSB0aW1lIG9mIHRoZSBldmVudC5cbiAgICogQHBhcmFtIHtTdHJpbmd9IGRhdGFfZnNfZmlsZW5hbWUgLSBUaGUgR3JpZEZTIGZpbGVuYW1lIGhvbGRpbmcgdGhlIGFjdHVhbCBldmVudCB3YXZlZm9ybSBkYXRhLlxuICAgKiBAcmV0dXJucyBUaGUgbmV3bHkgY3JlYXRlZCBkb2N1bWVudCBJRC5cbiAgICovXG4gIGRlZmluZSh7IGV2ZW50X2lkLCBib3hfaWQsIGV2ZW50X3N0YXJ0LCBldmVudF9lbmQsIHdpbmRvd190aW1lc3RhbXBzLCB0aGQsIGl0aWMsIGxvY2F0aW9uLCBkYXRhX2ZzX2ZpbGVuYW1lIH0pIHtcbiAgICBjb25zdCBkb2NJRCA9IHRoaXMuX2NvbGxlY3Rpb24uaW5zZXJ0KHtcbiAgICAgIGV2ZW50X2lkLCBib3hfaWQsIGV2ZW50X3N0YXJ0LCBldmVudF9lbmQsIHdpbmRvd190aW1lc3RhbXBzLCB0aGQsIGl0aWMsIGxvY2F0aW9uLCBkYXRhX2ZzX2ZpbGVuYW1lLFxuICAgIH0pO1xuICAgIHJldHVybiBkb2NJRDtcbiAgfVxuXG4gIC8qKlxuICAgKiBSZXR1cm5zIGFuIG9iamVjdCByZXByZXNlbnRpbmcgYSBzaW5nbGUgQm94RXZlbnQuXG4gICAqIEBwYXJhbSB7T2JqZWN0fSBkb2NJRCAtIFRoZSBNb25nby5PYmplY3RJRCBvZiB0aGUgQm94RXZlbnQuXG4gICAqIEByZXR1cm5zIHtPYmplY3R9IC0gQW4gb2JqZWN0IHJlcHJlc2VudGluZyBhIHNpbmdsZSBCb3hFdmVudC5cbiAgICovXG4gIGR1bXBPbmUoZG9jSUQpIHtcbiAgICAvKiBlc2xpbnQtZGlzYWJsZSBjYW1lbGNhc2UgKi9cbiAgICBjb25zdCBkb2MgPSB0aGlzLmZpbmREb2MoZG9jSUQpO1xuICAgIGNvbnN0IGV2ZW50X2lkID0gZG9jLmV2ZW50X2lkO1xuICAgIGNvbnN0IGJveF9pZCA9IGRvYy5ib3hfaWQ7XG4gICAgY29uc3QgZXZlbnRfc3RhcnQgPSBkb2MuZXZlbnRfc3RhcnQ7XG4gICAgY29uc3QgZXZlbnRfZW5kID0gZG9jLmV2ZW50X2VuZDtcbiAgICBjb25zdCB3aW5kb3dfdGltZXN0YW1wcyA9IGRvYy53aW5kb3dfdGltZXN0YW1wcztcbiAgICBjb25zdCB0aGQgPSBkb2MudGhkO1xuICAgIGNvbnN0IGl0aWMgPSBkb2MuaXRpYztcbiAgICBjb25zdCBsb2NhdGlvbiA9IGRvYy5sb2NhdGlvbjtcbiAgICBjb25zdCBkYXRhX2ZzX2ZpbGVuYW1lID0gZG9jLmRhdGFfZnNfZmlsZW5hbWU7XG5cbiAgICByZXR1cm4geyBldmVudF9pZCwgYm94X2lkLCBldmVudF9zdGFydCwgZXZlbnRfZW5kLCB3aW5kb3dfdGltZXN0YW1wcywgdGhkLCBpdGljLCBsb2NhdGlvbiwgZGF0YV9mc19maWxlbmFtZSB9O1xuICAgIC8qIGVzbGludC1lbmFibGUgY2FtZWxjYXNlICovXG4gIH1cblxuICBjaGVja0ludGVncml0eSgpIHtcbiAgICBjb25zdCBwcm9ibGVtcyA9IFtdO1xuICAgIGNvbnN0IHRvdGFsQ291bnQgPSB0aGlzLmNvdW50KCk7XG4gICAgY29uc3QgdmFsaWRhdGlvbkNvbnRleHQgPSB0aGlzLmdldFNjaGVtYSgpLm5hbWVkQ29udGV4dCgnYm94RXZlbnRzSW50ZWdyaXR5Jyk7XG4gICAgY29uc3QgcGIgPSBwcm9ncmVzc0JhclNldHVwKHRvdGFsQ291bnQsIDIwMDAsIGBDaGVja2luZyAke3RoaXMuX2NvbGxlY3Rpb25OYW1lfSBjb2xsZWN0aW9uOiBgKTtcblxuICAgIHRoaXMuZmluZCgpLmZvckVhY2goKGRvYywgaW5kZXgpID0+IHtcbiAgICAgIHBiLnVwZGF0ZUJhcihpbmRleCk7IC8vIFVwZGF0ZSBwcm9ncmVzcyBiYXIuXG5cbiAgICAgIC8vIFZhbGlkYXRlIGVhY2ggZG9jdW1lbnQgYWdhaW5zdCB0aGUgY29sbGVjdGlvbiBzY2hlbWEuXG4gICAgICB2YWxpZGF0aW9uQ29udGV4dC52YWxpZGF0ZShkb2MpO1xuICAgICAgaWYgKCF2YWxpZGF0aW9uQ29udGV4dC5pc1ZhbGlkKCkpIHtcbiAgICAgICAgLy8gZXNsaW50LWRpc2FibGUtbmV4dC1saW5lIG1heC1sZW5cbiAgICAgICAgcHJvYmxlbXMucHVzaChgQm94RXZlbnQgZG9jdW1lbnQgZmFpbGVkIHNjaGVtYSB2YWxpZGF0aW9uOiAke2RvYy5faWR9IChJbnZhbGlkIGtleXM6ICR7SlNPTi5zdHJpbmdpZnkodmFsaWRhdGlvbkNvbnRleHQuaW52YWxpZEtleXMoKSwgbnVsbCwgMil9KWApO1xuICAgICAgfVxuICAgICAgdmFsaWRhdGlvbkNvbnRleHQucmVzZXRWYWxpZGF0aW9uKCk7XG5cbiAgICAgIC8vIEVuc3VyZSBldmVudF9pZCBwb2ludHMgdG8gYW4gZXhpc3RpbmcgRXZlbnQgZG9jdW1lbnQuXG4gICAgICBpZiAoRXZlbnRzLmZpbmQoeyBldmVudF9pZDogZG9jLmV2ZW50X2lkIH0pLmNvdW50KCkgPCAxKSB7XG4gICAgICAgIC8vIGVzbGludC1kaXNhYmxlLW5leHQtbGluZSBtYXgtbGVuXG4gICAgICAgIHByb2JsZW1zLnB1c2goYEJveEV2ZW50J3MgZXZlbnRfaWQgZG9lcyBub3QgZXhpc3QgaW4gRXZlbnRzIGNvbGxlY3Rpb246ICR7ZG9jLl9pZH0gKGV2ZW50X2lkOiAke2RvYy5ldmVudF9pZH0pYCk7XG4gICAgICB9XG4gICAgfSk7XG5cbiAgICBwYi5jbGVhckludGVydmFsKCk7XG4gICAgcmV0dXJuIHByb2JsZW1zO1xuICB9XG5cbiAgLyoqXG4gICAqIExvYWRzIGFsbCBwdWJsaWNhdGlvbnMgcmVsYXRlZCB0byB0aGlzIGNvbGxlY3Rpb24uXG4gICAqL1xuICBwdWJsaXNoKCkgeyAvLyBlc2xpbnQtZGlzYWJsZS1saW5lIGNsYXNzLW1ldGhvZHMtdXNlLXRoaXNcbiAgICBpZiAoTWV0ZW9yLmlzU2VydmVyKSB7IC8vIGVzbGludC1kaXNhYmxlLWxpbmUgbm8tZW1wdHlcbiAgICB9XG4gIH1cbn1cblxuLyoqXG4gKiBQcm92aWRlcyB0aGUgc2luZ2xldG9uIGluc3RhbmNlIG9mIHRoaXMgY2xhc3MuXG4gKiBAdHlwZSB7Qm94RXZlbnRzQ29sbGVjdGlvbn1cbiAqL1xuZXhwb3J0IGNvbnN0IEJveEV2ZW50cyA9IG5ldyBCb3hFdmVudHNDb2xsZWN0aW9uKCk7XG4iLCJpbXBvcnQgeyBNZXRlb3IgfSBmcm9tICdtZXRlb3IvbWV0ZW9yJztcbmltcG9ydCB7IFZhbGlkYXRlZE1ldGhvZCB9IGZyb20gJ21ldGVvci9tZGc6dmFsaWRhdGVkLW1ldGhvZCc7XG5pbXBvcnQgU2ltcGxlU2NoZW1hIGZyb20gJ3NpbXBsLXNjaGVtYSc7XG5pbXBvcnQgeyBCb3hFdmVudHMgfSBmcm9tICcuL0JveEV2ZW50c0NvbGxlY3Rpb24uanMnO1xuXG5leHBvcnQgY29uc3QgdG90YWxCb3hFdmVudHNDb3VudCA9IG5ldyBWYWxpZGF0ZWRNZXRob2Qoe1xuICBuYW1lOiAnQm94RXZlbnRzLnRvdGFsQm94RXZlbnRzQ291bnQnLFxuICB2YWxpZGF0ZTogbmV3IFNpbXBsZVNjaGVtYSgpLnZhbGlkYXRvcih7IGNsZWFuOiB0cnVlIH0pLFxuICBydW4oKSB7XG4gICAgcmV0dXJuIEJveEV2ZW50cy5maW5kKHt9KS5jb3VudCgpO1xuICB9LFxufSk7XG5cbmV4cG9ydCBjb25zdCBnZXRCb3hFdmVudCA9IG5ldyBWYWxpZGF0ZWRNZXRob2Qoe1xuICBuYW1lOiAnQm94RXZlbnRzLmdldEJveEV2ZW50JyxcbiAgdmFsaWRhdGU6IG5ldyBTaW1wbGVTY2hlbWEoe1xuICAgIGV2ZW50X2lkOiB7IHR5cGU6IE51bWJlciB9LFxuICAgIGJveF9pZDogeyB0eXBlOiBTdHJpbmcgfSxcbiAgfSkudmFsaWRhdG9yKHsgY2xlYW46IHRydWUgfSksXG4gIHJ1bih7IGV2ZW50X2lkLCBib3hfaWQgfSkge1xuICAgIGlmICghdGhpcy5pc1NpbXVsYXRpb24pIHtcbiAgICAgIGNvbnN0IGJveEV2ZW50ID0gQm94RXZlbnRzLmZpbmRPbmUoeyBldmVudF9pZCwgYm94X2lkIH0sIHt9KTtcbiAgICAgIC8vIGVzbGludC1kaXNhYmxlLW5leHQtbGluZSBtYXgtbGVuLCBjYW1lbGNhc2VcbiAgICAgIGlmICghYm94RXZlbnQpIHRocm93IG5ldyBNZXRlb3IuRXJyb3IoJ0JveEV2ZW50cyBkb2N1bWVudCBub3QgZm91bmQnLCBgRG9jdW1lbnQgbm90IGZvdW5kIGZvciBldmVudF9udW1iZXI6ICR7ZXZlbnRfaWR9LCBib3hfaWQ6ICR7Ym94X2lkfWApO1xuICAgICAgcmV0dXJuIGJveEV2ZW50O1xuICAgIH1cbiAgICByZXR1cm4gbnVsbDtcbiAgfSxcbn0pO1xuIiwiaW1wb3J0ICcuL0JveEV2ZW50c0NvbGxlY3Rpb24uanMnO1xuaW1wb3J0ICcuL0JveEV2ZW50c0NvbGxlY3Rpb25NZXRob2RzLmpzJztcbiIsImltcG9ydCB7IE1ldGVvciB9IGZyb20gJ21ldGVvci9tZXRlb3InO1xuaW1wb3J0IHsgTW9uZ28gfSBmcm9tICdtZXRlb3IvbW9uZ28nO1xuaW1wb3J0IHsgY2hlY2ssIE1hdGNoIH0gZnJvbSAnbWV0ZW9yL2NoZWNrJztcbmltcG9ydCBTaW1wbGVTY2hlbWEgZnJvbSAnc2ltcGwtc2NoZW1hJztcbmltcG9ydCBCYXNlQ29sbGVjdGlvbiBmcm9tICcuLi9iYXNlL0Jhc2VDb2xsZWN0aW9uLmpzJztcbmltcG9ydCB7IHByb2dyZXNzQmFyU2V0dXAgfSBmcm9tICcuLi8uLi9tb2R1bGVzL3V0aWxzJztcblxuLyoqXG4gKiBDb2xsZWN0aW9uIGNsYXNzIGZvciB0aGUgZXZlbnRzIGNvbGxlY3Rpb24uXG4gKiBEb2NzOiBodHRwczovL29wZW4tcG93ZXItcXVhbGl0eS5naXRib29rcy5pby9vcGVuLXBvd2VyLXF1YWxpdHktbWFudWFsL2NvbnRlbnQvZGF0YW1vZGVsL2Rlc2NyaXB0aW9uLmh0bWwjZXZlbnRzXG4gKi9cbmNsYXNzIEV2ZW50c0NvbGxlY3Rpb24gZXh0ZW5kcyBCYXNlQ29sbGVjdGlvbiB7XG5cbiAgLyoqXG4gICAqIENyZWF0ZXMgdGhlIGNvbGxlY3Rpb24uXG4gICAqL1xuICBjb25zdHJ1Y3RvcigpIHtcbiAgICBzdXBlcignZXZlbnRzJywgbmV3IFNpbXBsZVNjaGVtYSh7XG4gICAgICBfaWQ6IHsgdHlwZTogTW9uZ28uT2JqZWN0SUQgfSxcbiAgICAgIGV2ZW50X2lkOiBOdW1iZXIsXG4gICAgICB0eXBlOiBTdHJpbmcsXG4gICAgICBkZXNjcmlwdGlvbjogU3RyaW5nLFxuICAgICAgYm94ZXNfdHJpZ2dlcmVkOiBbU3RyaW5nXSxcbiAgICAgIGJveGVzX3JlY2VpdmVkOiBbU3RyaW5nXSxcbiAgICAgIHRhcmdldF9ldmVudF9zdGFydF90aW1lc3RhbXBfbXM6IE51bWJlcixcbiAgICAgIHRhcmdldF9ldmVudF9lbmRfdGltZXN0YW1wX21zOiBOdW1iZXIsXG4gICAgICBsYXRlbmNpZXNfbXM6IHsgdHlwZTogQXJyYXksIG9wdGlvbmFsOiB0cnVlIH0sXG4gICAgICAnbGF0ZW5jaWVzX21zLiQnOiBOdW1iZXIsXG4gICAgfSkpO1xuXG4gICAgdGhpcy5ldmVudFR5cGVzID0gWydGUkVRVUVOQ1lfU0FHJywgJ0ZSRVFVRU5DWV9TV0VMTCcsICdWT0xUQUdFX1NBRycsICdWT0xUQUdFX1NXRUxMJywgJ1RIRCcsICdPVEhFUiddO1xuICAgIHRoaXMuRlJFUVVFTkNZX1NBR19UWVBFID0gJ0ZSRVFVRU5DWV9TQUcnO1xuICAgIHRoaXMuRlJFUVVFTkNZX1NXRUxMX1RZUEUgPSAnRlJFUVVFTkNZX1NXRUxMJztcbiAgICB0aGlzLlZPTFRBR0VfU0FHX1RZUEUgPSAnVk9MVEFHRV9TQUcnO1xuICAgIHRoaXMuVk9MVEFHRV9TV0VMTF9UWVBFID0gJ1ZPTFRBR0VfU1dFTEwnO1xuICAgIHRoaXMuVEhEX1RZUEUgPSAnVEhEJztcbiAgICB0aGlzLk9USEVSX1RZUEUgPSAnT1RIRVInO1xuXG4gICAgdGhpcy5wdWJsaWNhdGlvbk5hbWVzID0ge1xuICAgICAgR0VUX0VWRU5UUzogJ2dldF9ldmVudHMnLFxuICAgICAgR0VUX1JFQ0VOVF9FVkVOVFM6ICdnZXRfcmVjZW50X2V2ZW50cycsXG4gICAgfTtcbiAgICBpZiAoTWV0ZW9yLnNlcnZlcikge1xuICAgICAgdGhpcy5fY29sbGVjdGlvbi5yYXdDb2xsZWN0aW9uKCkuY3JlYXRlSW5kZXgoeyB0YXJnZXRfZXZlbnRfc3RhcnRfdGltZXN0YW1wX21zOiAxIH0sIHsgYmFja2dyb3VuZDogdHJ1ZSB9KTtcbiAgICB9XG4gIH1cblxuICAvKipcbiAgICogRGVmaW5lcyBhIG5ldyBFdmVudCBkb2N1bWVudC5cbiAgICogQHBhcmFtIHtOdW1iZXJ9IGV2ZW50X2lkIC0gVGhlIGV2ZW50J3MgaWQgdmFsdWUgKG5vdCBNb25nbyBJRClcbiAgICogQHBhcmFtIHtTdHJpbmd9IHR5cGUgLSBUaGUgdW5peCB0aW1lc3RhbXAgKG1pbGxpcykgb2YgdGhlIG1lYXN1cmVtZW50LlxuICAgKiBAcGFyYW0ge1N0cmluZ30gZGVzY3JpcHRpb24gLSBUaGUgZGVzY3JpcHRpb24gb2YgdGhlIGV2ZW50LlxuICAgKiBAcGFyYW0ge1N0cmluZ30gYm94ZXNfdHJpZ2dlcmVkIC0gVGhlIE9QUUJveGVzIGZyb20gd2hpY2ggZGF0YSB3YXMgcmVxdWVzdGVkIGZvciB0aGlzIGV2ZW50LlxuICAgKiBAcGFyYW0ge051bWJlcn0gbGF0ZW5jaWVzIC0gQXJyYXkgb2YgdW5peCB0aW1lc3RhbXBzIGZvciB0aGUgZXZlbnQuIFNlZSBkb2NzIGZvciBkZXRhaWxzLlxuICAgKiBAcmV0dXJucyBUaGUgbmV3bHkgY3JlYXRlZCBkb2N1bWVudCBJRC5cbiAgICovXG4gIGRlZmluZSh7IGV2ZW50X2lkLCB0eXBlLCBkZXNjcmlwdGlvbiwgYm94ZXNfdHJpZ2dlcmVkLCBib3hlc19yZWNlaXZlZCwgdGFyZ2V0X2V2ZW50X3N0YXJ0X3RpbWVzdGFtcF9tcyxcbiAgICB0YXJnZXRfZXZlbnRfZW5kX3RpbWVzdGFtcF9tcywgbGF0ZW5jaWVzX21zIH0pIHtcbiAgICBjb25zdCBkb2NJRCA9IHRoaXMuX2NvbGxlY3Rpb24uaW5zZXJ0KHsgZXZlbnRfaWQsIHR5cGUsIGRlc2NyaXB0aW9uLCBib3hlc190cmlnZ2VyZWQsIGJveGVzX3JlY2VpdmVkLFxuICAgICAgdGFyZ2V0X2V2ZW50X3N0YXJ0X3RpbWVzdGFtcF9tcywgdGFyZ2V0X2V2ZW50X2VuZF90aW1lc3RhbXBfbXMsIGxhdGVuY2llc19tcyB9KTtcbiAgICByZXR1cm4gZG9jSUQ7XG4gIH1cblxuICAvKipcbiAgICogUmV0dXJucyBhbiBvYmplY3QgcmVwcmVzZW50aW5nIGEgc2luZ2xlIEV2ZW50LlxuICAgKiBAcGFyYW0ge09iamVjdH0gZG9jSUQgLSBUaGUgTW9uZ28uT2JqZWN0SUQgb2YgdGhlIEV2ZW50LlxuICAgKiBAcmV0dXJucyB7T2JqZWN0fSAtIEFuIG9iamVjdCByZXByZXNlbnRpbmcgYSBzaW5nbGUgRXZlbnQuXG4gICAqL1xuICBkdW1wT25lKGRvY0lEKSB7XG4gICAgLyogZXNsaW50LWRpc2FibGUgY2FtZWxjYXNlICovXG4gICAgY29uc3QgZG9jID0gdGhpcy5maW5kRG9jKGRvY0lEKTtcbiAgICBjb25zdCBldmVudF9pZCA9IGRvYy5ldmVudF9pZDtcbiAgICBjb25zdCB0eXBlID0gZG9jLnR5cGU7XG4gICAgY29uc3QgZGVzY3JpcHRpb24gPSBkb2MuZGVzY3JpcHRpb247XG4gICAgY29uc3QgYm94ZXNfdHJpZ2dlcmVkID0gZG9jLmJveGVzX3RyaWdnZXJlZDtcbiAgICBjb25zdCBib3hlc19yZWNlaXZlZCA9IGRvYy5ib3hlc19yZWNlaXZlZDtcbiAgICBjb25zdCB0YXJnZXRfZXZlbnRfc3RhcnRfdGltZXN0YW1wX21zID0gZG9jLnRhcmdldF9ldmVudF9zdGFydF90aW1lc3RhbXBfbXM7XG4gICAgY29uc3QgdGFyZ2V0X2V2ZW50X2VuZF90aW1lc3RhbXBfbXMgPSBkb2MudGFyZ2V0X2V2ZW50X2VuZF90aW1lc3RhbXBfbXM7XG4gICAgY29uc3QgbGF0ZW5jaWVzX21zID0gZG9jLmxhdGVuY2llc19tcztcblxuICAgIHJldHVybiB7IGV2ZW50X2lkLCB0eXBlLCBkZXNjcmlwdGlvbiwgYm94ZXNfdHJpZ2dlcmVkLCBib3hlc19yZWNlaXZlZCxcbiAgICAgIHRhcmdldF9ldmVudF9zdGFydF90aW1lc3RhbXBfbXMsIHRhcmdldF9ldmVudF9lbmRfdGltZXN0YW1wX21zLCBsYXRlbmNpZXNfbXMgfTtcbiAgICAvKiBlc2xpbnQtZW5hYmxlIGNhbWVsY2FzZSAqL1xuICB9XG5cbiAgY2hlY2tJbnRlZ3JpdHkoKSB7XG4gICAgY29uc3QgcHJvYmxlbXMgPSBbXTtcbiAgICBjb25zdCB0b3RhbENvdW50ID0gdGhpcy5jb3VudCgpO1xuICAgIGNvbnN0IHZhbGlkYXRpb25Db250ZXh0ID0gdGhpcy5nZXRTY2hlbWEoKS5uYW1lZENvbnRleHQoJ2V2ZW50c0ludGVncml0eScpO1xuICAgIGNvbnN0IHBiID0gcHJvZ3Jlc3NCYXJTZXR1cCh0b3RhbENvdW50LCAyMDAwLCBgQ2hlY2tpbmcgJHt0aGlzLl9jb2xsZWN0aW9uTmFtZX0gY29sbGVjdGlvbjogYCk7XG5cbiAgICB0aGlzLmZpbmQoKS5mb3JFYWNoKChkb2MsIGluZGV4KSA9PiB7XG4gICAgICBwYi51cGRhdGVCYXIoaW5kZXgpOyAvLyBVcGRhdGUgcHJvZ3Jlc3MgYmFyLlxuXG4gICAgICAvLyBWYWxpZGF0ZSBlYWNoIGRvY3VtZW50IGFnYWluc3QgdGhlIGNvbGxlY3Rpb24gc2NoZW1hLlxuICAgICAgdmFsaWRhdGlvbkNvbnRleHQudmFsaWRhdGUoZG9jKTtcbiAgICAgIGlmICghdmFsaWRhdGlvbkNvbnRleHQuaXNWYWxpZCgpKSB7XG4gICAgICAgIC8vIGVzbGludC1kaXNhYmxlLW5leHQtbGluZSBtYXgtbGVuXG4gICAgICAgIHByb2JsZW1zLnB1c2goYEV2ZW50cyBkb2N1bWVudCBmYWlsZWQgc2NoZW1hIHZhbGlkYXRpb246ICR7ZG9jLl9pZH0gKEludmFsaWQga2V5czogJHtKU09OLnN0cmluZ2lmeSh2YWxpZGF0aW9uQ29udGV4dC5pbnZhbGlkS2V5cygpLCBudWxsLCAyKX0pYCk7XG4gICAgICB9XG4gICAgICB2YWxpZGF0aW9uQ29udGV4dC5yZXNldFZhbGlkYXRpb24oKTtcbiAgICB9KTtcblxuICAgIHBiLmNsZWFySW50ZXJ2YWwoKTtcbiAgICByZXR1cm4gcHJvYmxlbXM7XG4gIH1cblxuXG4gIC8qKlxuICAgKiBMb2FkcyBhbGwgcHVibGljYXRpb25zIHJlbGF0ZWQgdG8gdGhpcyBjb2xsZWN0aW9uLlxuICAgKi9cbiAgcHVibGlzaCgpIHtcbiAgICBpZiAoTWV0ZW9yLmlzU2VydmVyKSB7XG4gICAgICBjb25zdCBzZWxmID0gdGhpcztcblxuICAgICAgTWV0ZW9yLnB1Ymxpc2godGhpcy5wdWJsaWNhdGlvbk5hbWVzLkdFVF9FVkVOVFMsIGZ1bmN0aW9uICh7IHN0YXJ0VGltZSwgZW5kVGltZSB9KSB7XG4gICAgICAgIGNoZWNrKHN0YXJ0VGltZSwgTWF0Y2guTWF5YmUoTnVtYmVyKSk7XG4gICAgICAgIGNoZWNrKGVuZFRpbWUsIE1hdGNoLk1heWJlKE51bWJlcikpO1xuXG4gICAgICAgIGNvbnN0IHNlbGVjdG9yID0gc2VsZi5xdWVyeUNvbnN0cnVjdG9ycygpLmdldEV2ZW50cyh7IHN0YXJ0VGltZSwgZW5kVGltZSB9KTtcbiAgICAgICAgcmV0dXJuIHNlbGYuZmluZChzZWxlY3Rvcik7XG4gICAgICB9KTtcblxuICAgICAgTWV0ZW9yLnB1Ymxpc2godGhpcy5wdWJsaWNhdGlvbk5hbWVzLkdFVF9SRUNFTlRfRVZFTlRTLCBmdW5jdGlvbiAoeyBudW1FdmVudHMsIGV4Y2x1ZGVPdGhlciB9KSB7XG4gICAgICAgIGNoZWNrKG51bUV2ZW50cywgTnVtYmVyKTtcbiAgICAgICAgY29uc3QgcXVlcnkgPSBleGNsdWRlT3RoZXIgPyB7IHR5cGU6IHsgJG5lOiAnT1RIRVInIH0gfSA6IHt9O1xuICAgICAgICBjb25zdCBldmVudHMgPSBzZWxmLmZpbmQocXVlcnksIHsgc29ydDogeyB0YXJnZXRfZXZlbnRfc3RhcnRfdGltZXN0YW1wX21zOiAtMSB9LCBsaW1pdDogbnVtRXZlbnRzIH0pO1xuICAgICAgICByZXR1cm4gZXZlbnRzO1xuICAgICAgfSk7XG4gICAgfVxuICB9XG5cbiAgcXVlcnlDb25zdHJ1Y3RvcnMoKSB7IC8vIGVzbGludC1kaXNhYmxlLWxpbmUgY2xhc3MtbWV0aG9kcy11c2UtdGhpc1xuICAgIHJldHVybiB7XG4gICAgICBnZXRFdmVudHMoeyBzdGFydFRpbWUsIGVuZFRpbWUgfSkge1xuICAgICAgICBjaGVjayhzdGFydFRpbWUsIE1hdGNoLk1heWJlKE51bWJlcikpO1xuICAgICAgICBjaGVjayhlbmRUaW1lLCBNYXRjaC5NYXliZShOdW1iZXIpKTtcblxuICAgICAgICBjb25zdCBzZWxlY3RvciA9IHt9O1xuICAgICAgICBpZiAoc3RhcnRUaW1lKSBzZWxlY3Rvci50YXJnZXRfZXZlbnRfc3RhcnRfdGltZXN0YW1wX21zID0geyAkZ3RlOiBzdGFydFRpbWUgfTtcbiAgICAgICAgaWYgKGVuZFRpbWUpIHNlbGVjdG9yLnRhcmdldF9ldmVudF9lbmRfdGltZXN0YW1wX21zID0geyAkbHRlOiBlbmRUaW1lIH07XG5cbiAgICAgICAgcmV0dXJuIHNlbGVjdG9yO1xuICAgICAgfSxcbiAgICB9O1xuICB9XG59XG5cbi8qKlxuICogUHJvdmlkZXMgdGhlIHNpbmdsZXRvbiBpbnN0YW5jZSBvZiB0aGlzIGNsYXNzLlxuICogQHR5cGUge0V2ZW50c0NvbGxlY3Rpb259XG4gKi9cbmV4cG9ydCBjb25zdCBFdmVudHMgPSBuZXcgRXZlbnRzQ29sbGVjdGlvbigpO1xuIiwiaW1wb3J0IHsgVmFsaWRhdGVkTWV0aG9kIH0gZnJvbSAnbWV0ZW9yL21kZzp2YWxpZGF0ZWQtbWV0aG9kJztcbmltcG9ydCBTaW1wbGVTY2hlbWEgZnJvbSAnc2ltcGwtc2NoZW1hJztcbmltcG9ydCB7IGRlbWFwaWZ5IH0gZnJvbSAnZXM2LW1hcGlmeSc7XG5pbXBvcnQgeyBFdmVudHMgfSBmcm9tICcuL0V2ZW50c0NvbGxlY3Rpb24uanMnO1xuaW1wb3J0IHsgdGltZVVuaXRTdHJpbmcgfSBmcm9tICcuLi8uLi9tb2R1bGVzL3V0aWxzLmpzJztcblxuXG5leHBvcnQgY29uc3QgdG90YWxFdmVudHNDb3VudCA9IG5ldyBWYWxpZGF0ZWRNZXRob2Qoe1xuICBuYW1lOiAnRXZlbnRzLnRvdGFsRXZlbnRzQ291bnQnLFxuICB2YWxpZGF0ZTogbmV3IFNpbXBsZVNjaGVtYSgpLnZhbGlkYXRvcih7IGNsZWFuOiB0cnVlIH0pLFxuICBydW4oKSB7XG4gICAgcmV0dXJuIEV2ZW50cy5maW5kKHt9KS5jb3VudCgpO1xuICB9LFxufSk7XG5cbmV4cG9ydCBjb25zdCBldmVudHNDb3VudE1hcCA9IG5ldyBWYWxpZGF0ZWRNZXRob2Qoe1xuICBuYW1lOiAnRXZlbnRzLmV2ZW50c0NvdW50TWFwJyxcbiAgdmFsaWRhdGU6IG5ldyBTaW1wbGVTY2hlbWEoe1xuICAgIHRpbWVVbml0OiB7IHR5cGU6IFN0cmluZyB9LFxuICAgIHN0YXJ0VGltZTogeyB0eXBlOiBOdW1iZXIgfSxcbiAgICBlbmRUaW1lOiB7IHR5cGU6IE51bWJlciwgb3B0aW9uYWw6IHRydWUgfSxcbiAgfSkudmFsaWRhdG9yKHsgY2xlYW46IHRydWUgfSksXG4gIHJ1bih7IHRpbWVVbml0LCBzdGFydFRpbWUsIGVuZFRpbWUgfSkge1xuICAgIC8vIFRpbWVVbml0cyBjYW4gYmUgeWVhciwgbW9udGgsIHdlZWssIGRheSwgZGF5T2ZNb250aCwgaG91ck9mRGF5XG4gICAgY29uc3Qgc2VsZWN0b3IgPSBFdmVudHMucXVlcnlDb25zdHJ1Y3RvcnMoKS5nZXRFdmVudHMoeyBzdGFydFRpbWUsIGVuZFRpbWUgfSk7XG4gICAgY29uc3QgZXZlbnRNZXRhRGF0YSA9IEV2ZW50cy5maW5kKHNlbGVjdG9yKTtcblxuICAgIGNvbnN0IGV2ZW50Q291bnRNYXAgPSBuZXcgTWFwKCk7XG4gICAgZXZlbnRNZXRhRGF0YS5mb3JFYWNoKGV2ZW50ID0+IHtcbiAgICAgIGNvbnN0IHRpbWVVbml0S2V5ID0gdGltZVVuaXRTdHJpbmcoZXZlbnQudGFyZ2V0X2V2ZW50X3N0YXJ0X3RpbWVzdGFtcF9tcywgdGltZVVuaXQpO1xuICAgICAgaWYgKGV2ZW50Q291bnRNYXAuaGFzKHRpbWVVbml0S2V5KSkge1xuICAgICAgICBldmVudENvdW50TWFwLnNldCh0aW1lVW5pdEtleSwgZXZlbnRDb3VudE1hcC5nZXQodGltZVVuaXRLZXkpICsgMSk7XG4gICAgICB9IGVsc2Uge1xuICAgICAgICBldmVudENvdW50TWFwLnNldCh0aW1lVW5pdEtleSwgMSk7XG4gICAgICB9XG4gICAgfSk7XG5cbiAgICByZXR1cm4gZGVtYXBpZnkoZXZlbnRDb3VudE1hcCk7XG4gIH0sXG59KTtcblxuZXhwb3J0IGNvbnN0IGdldEV2ZW50QnlFdmVudElEID0gbmV3IFZhbGlkYXRlZE1ldGhvZCh7XG4gIG5hbWU6ICdFdmVudHMuZ2V0RXZlbnRCeUV2ZW50SUQnLFxuICB2YWxpZGF0ZTogbmV3IFNpbXBsZVNjaGVtYSh7XG4gICAgZXZlbnRfaWQ6IHsgdHlwZTogTnVtYmVyIH0sXG4gIH0pLnZhbGlkYXRvcih7IGNsZWFuOiB0cnVlIH0pLFxuICBydW4oeyBldmVudF9pZCB9KSB7XG4gICAgY29uc3QgZXZlbnRNZXRhRGF0YSA9IEV2ZW50cy5maW5kT25lKHsgZXZlbnRfaWQgfSwge30pO1xuICAgIHJldHVybiBldmVudE1ldGFEYXRhO1xuICB9LFxufSk7XG5cbmV4cG9ydCBjb25zdCBnZXRNb3N0UmVjZW50RXZlbnQgPSBuZXcgVmFsaWRhdGVkTWV0aG9kKHtcbiAgbmFtZTogJ0V2ZW50cy5nZXRNb3N0UmVjZW50RXZlbnQnLFxuICB2YWxpZGF0ZTogbmV3IFNpbXBsZVNjaGVtYSh7fSkudmFsaWRhdG9yKHsgY2xlYW46IHRydWUgfSksXG4gIHJ1bigpIHtcbiAgICBjb25zdCBtb3N0UmVjZW50RXZlbnQgPSBFdmVudHMuZmluZE9uZSh7fSwgeyBzb3J0OiB7IHRhcmdldF9ldmVudF9zdGFydF90aW1lc3RhbXBfbXM6IC0xIH0gfSk7XG4gICAgcmV0dXJuIG1vc3RSZWNlbnRFdmVudDtcbiAgfSxcbn0pO1xuIiwiaW1wb3J0ICcuL0V2ZW50c0NvbGxlY3Rpb24uanMnO1xuaW1wb3J0ICcuL0V2ZW50c0NvbGxlY3Rpb25NZXRob2RzLmpzJztcbiIsImltcG9ydCB7IE1ldGVvciB9IGZyb20gJ21ldGVvci9tZXRlb3InO1xuaW1wb3J0IHsgTW9uZ28gfSBmcm9tICdtZXRlb3IvbW9uZ28nO1xuaW1wb3J0IFNpbXBsZVNjaGVtYSBmcm9tICdzaW1wbC1zY2hlbWEnO1xuaW1wb3J0IEJhc2VDb2xsZWN0aW9uIGZyb20gJy4uL2Jhc2UvQmFzZUNvbGxlY3Rpb24uanMnO1xuaW1wb3J0IHsgRlNGaWxlcyB9IGZyb20gJy4uL2ZzLWZpbGVzL0ZTRmlsZXNDb2xsZWN0aW9uJztcbmltcG9ydCB7IHByb2dyZXNzQmFyU2V0dXAgfSBmcm9tICcuLi8uLi9tb2R1bGVzL3V0aWxzJztcblxuLyoqXG4gKiBDb2xsZWN0aW9uIGNsYXNzIGZvciB0aGUgZnMuY2h1bmtzIGNvbGxlY3Rpb24uXG4gKiBEb2NzOiBodHRwczovL29wZW4tcG93ZXItcXVhbGl0eS5naXRib29rcy5pby9vcGVuLXBvd2VyLXF1YWxpdHktbWFudWFsL2NvbnRlbnQvZGF0YW1vZGVsL2Rlc2NyaXB0aW9uLmh0bWwjYm94X2V2ZW50c1xuICovXG5jbGFzcyBGU0NodW5rc0NvbGxlY3Rpb24gZXh0ZW5kcyBCYXNlQ29sbGVjdGlvbiB7XG5cbiAgLyoqXG4gICAqIENyZWF0ZXMgdGhlIGNvbGxlY3Rpb24uXG4gICAqL1xuICBjb25zdHJ1Y3RvcigpIHtcbiAgICBzdXBlcignZnMuY2h1bmtzJywgbmV3IFNpbXBsZVNjaGVtYSh7XG4gICAgICBfaWQ6IHsgdHlwZTogTW9uZ28uT2JqZWN0SUQgfSxcbiAgICAgIGZpbGVzX2lkOiB7IHR5cGU6IE1vbmdvLk9iamVjdElEIH0sXG4gICAgICBuOiBOdW1iZXIsXG4gICAgICBkYXRhOiBVaW50OEFycmF5LFxuICAgIH0pKTtcblxuICAgIHRoaXMucHVibGljYXRpb25OYW1lcyA9IHtcbiAgICB9O1xuICB9XG5cbiAgLyoqXG4gICAqIERlZmluZXMgYSBuZXcgZnMuY2h1bmtzIGRvY3VtZW50LlxuICAgKiBAcGFyYW0ge09iamVjdElEfSBmaWxlc19pZCAtIFRoZSBPYmplY3RJRCBvZiB0aGUgY29ycmVzcG9uZGluZyBmcy5maWxlcyBkb2N1bWVudC5cbiAgICogQHBhcmFtIHtOdW1iZXJ9IG4gLSBUaGUgbnVtYmVyIG9mIGNodW5rcy5cbiAgICogQHBhcmFtIHtPYmplY3R9IGRhdGEgLSBUaGUgYmluYXJ5IGZvciB0aGlzIGNodW5rLlxuICAgKiBAcmV0dXJucyBUaGUgbmV3bHkgY3JlYXRlZCBkb2N1bWVudCBJRC5cbiAgICovXG4gIGRlZmluZSh7IGZpbGVzX2lkLCBuLCBkYXRhIH0pIHtcbiAgICBjb25zdCBkb2NJRCA9IHRoaXMuX2NvbGxlY3Rpb24uaW5zZXJ0KHsgZmlsZXNfaWQsIG4sIGRhdGEgfSk7XG4gICAgcmV0dXJuIGRvY0lEO1xuICB9XG5cbiAgLyoqXG4gICAqIFJldHVybnMgYW4gb2JqZWN0IHJlcHJlc2VudGluZyBhIHNpbmdsZSBmcy5jaHVuay5cbiAgICogQHBhcmFtIHtPYmplY3R9IGRvY0lEIC0gVGhlIE1vbmdvLk9iamVjdElEIG9mIHRoZSBmcy5jaHVuayBkb2N1bWVudC5cbiAgICogQHJldHVybnMge09iamVjdH0gLSBBbiBvYmplY3QgcmVwcmVzZW50aW5nIGEgc2luZ2xlIGZzLmNodW5rIGRvY3VtZW50LlxuICAgKi9cbiAgZHVtcE9uZShkb2NJRCkge1xuICAgIC8qIGVzbGludC1kaXNhYmxlIGNhbWVsY2FzZSAqL1xuICAgIGNvbnN0IGRvYyA9IHRoaXMuZmluZERvYyhkb2NJRCk7XG4gICAgY29uc3QgZmlsZXNfaWQgPSBkb2MuZmlsZXNfaWQ7XG4gICAgY29uc3QgbiA9IGRvYy5uO1xuICAgIGNvbnN0IGRhdGEgPSBkb2MuZGF0YTtcblxuICAgIHJldHVybiB7IGZpbGVzX2lkLCBuLCBkYXRhIH07XG4gICAgLyogZXNsaW50LWVuYWJsZSBjYW1lbGNhc2UgKi9cbiAgfVxuXG4gIGNoZWNrSW50ZWdyaXR5KCkge1xuICAgIGNvbnN0IHByb2JsZW1zID0gW107XG4gICAgY29uc3QgdG90YWxDb3VudCA9IHRoaXMuY291bnQoKTtcbiAgICBjb25zdCB2YWxpZGF0aW9uQ29udGV4dCA9IHRoaXMuZ2V0U2NoZW1hKCkubmFtZWRDb250ZXh0KCdmc0ZpbGVzSW50ZWdyaXR5Jyk7XG4gICAgY29uc3QgcGIgPSBwcm9ncmVzc0JhclNldHVwKHRvdGFsQ291bnQsIDIwMDAsIGBDaGVja2luZyAke3RoaXMuX2NvbGxlY3Rpb25OYW1lfSBjb2xsZWN0aW9uOiBgKTtcblxuICAgIHRoaXMuZmluZCgpLmZvckVhY2goKGRvYywgaW5kZXgpID0+IHtcbiAgICAgIHBiLnVwZGF0ZUJhcihpbmRleCk7IC8vIFVwZGF0ZSBwcm9ncmVzcyBiYXIuXG5cbiAgICAgIC8vIFZhbGlkYXRlIGVhY2ggZG9jdW1lbnQgYWdhaW5zdCB0aGUgY29sbGVjdGlvbiBzY2hlbWEuXG4gICAgICB2YWxpZGF0aW9uQ29udGV4dC52YWxpZGF0ZShkb2MpO1xuICAgICAgaWYgKCF2YWxpZGF0aW9uQ29udGV4dC5pc1ZhbGlkKCkpIHtcbiAgICAgICAgLy8gZXNsaW50LWRpc2FibGUtbmV4dC1saW5lIG1heC1sZW5cbiAgICAgICAgcHJvYmxlbXMucHVzaChgRlMuQ2h1bmtzIGRvY3VtZW50IGZhaWxlZCBzY2hlbWEgdmFsaWRhdGlvbjogJHtkb2MuX2lkfSAoSW52YWxpZCBrZXlzOiAke0pTT04uc3RyaW5naWZ5KHZhbGlkYXRpb25Db250ZXh0LmludmFsaWRLZXlzKCksIG51bGwsIDIpfSlgKTtcbiAgICAgIH1cbiAgICAgIHZhbGlkYXRpb25Db250ZXh0LnJlc2V0VmFsaWRhdGlvbigpO1xuXG4gICAgICAvLyBFbnN1cmUgZmlsZXNfaWQgcG9pbnRzIHRvIHZhbGlkIGZzLmZpbGVzIGRvY3VtZW50LlxuICAgICAgY29uc3QgZnNGaWxlID0gRlNGaWxlcy5maW5kT25lKHsgX2lkOiBkb2MuZmlsZXNfaWQgfSk7XG4gICAgICBpZiAoIWZzRmlsZSkge1xuICAgICAgICBwcm9ibGVtcy5wdXNoKGBGUy5DaHVua3MgZmlsZXNfaWQgZG9lcyBtYXRjaCBhbiBleGlzdGluZyBGUy5GaWxlcyBkb2N1bWVudDogJHtkb2MuX2lkfWApO1xuICAgICAgfVxuICAgIH0pO1xuXG4gICAgcGIuY2xlYXJJbnRlcnZhbCgpO1xuICAgIHJldHVybiBwcm9ibGVtcztcbiAgfVxuXG4gIC8qKlxuICAgKiBMb2FkcyBhbGwgcHVibGljYXRpb25zIHJlbGF0ZWQgdG8gdGhpcyBjb2xsZWN0aW9uLlxuICAgKi9cbiAgcHVibGlzaCgpIHsgLy8gZXNsaW50LWRpc2FibGUtbGluZSBjbGFzcy1tZXRob2RzLXVzZS10aGlzXG4gICAgaWYgKE1ldGVvci5pc1NlcnZlcikgeyAvLyBlc2xpbnQtZGlzYWJsZS1saW5lIG5vLWVtcHR5XG4gICAgfVxuICB9XG59XG5cbi8qKlxuICogUHJvdmlkZXMgdGhlIHNpbmdsZXRvbiBpbnN0YW5jZSBvZiB0aGlzIGNsYXNzLlxuICogQHR5cGUge0ZTQ2h1bmtzQ29sbGVjdGlvbn1cbiAqL1xuZXhwb3J0IGNvbnN0IEZTQ2h1bmtzID0gbmV3IEZTQ2h1bmtzQ29sbGVjdGlvbigpO1xuIiwiaW1wb3J0ICcuL0ZTQ2h1bmtzQ29sbGVjdGlvbi5qcyc7XG4iLCJpbXBvcnQgeyBNZXRlb3IgfSBmcm9tICdtZXRlb3IvbWV0ZW9yJztcbmltcG9ydCB7IE1vbmdvIH0gZnJvbSAnbWV0ZW9yL21vbmdvJztcbmltcG9ydCBTaW1wbGVTY2hlbWEgZnJvbSAnc2ltcGwtc2NoZW1hJztcbmltcG9ydCBCYXNlQ29sbGVjdGlvbiBmcm9tICcuLi9iYXNlL0Jhc2VDb2xsZWN0aW9uLmpzJztcbmltcG9ydCB7IEV2ZW50cyB9IGZyb20gJy4uL2V2ZW50cy9FdmVudHNDb2xsZWN0aW9uJztcbmltcG9ydCB7IEJveEV2ZW50cyB9IGZyb20gJy4uL2JveC1ldmVudHMvQm94RXZlbnRzQ29sbGVjdGlvbic7XG5pbXBvcnQgeyBwcm9ncmVzc0JhclNldHVwIH0gZnJvbSAnLi4vLi4vbW9kdWxlcy91dGlscyc7XG5cbi8qKlxuICogQ29sbGVjdGlvbiBjbGFzcyBmb3IgdGhlIGZzLmZpbGVzIGNvbGxlY3Rpb24uXG4gKiBEb2NzOiBodHRwczovL29wZW4tcG93ZXItcXVhbGl0eS5naXRib29rcy5pby9vcGVuLXBvd2VyLXF1YWxpdHktbWFudWFsL2NvbnRlbnQvZGF0YW1vZGVsL2Rlc2NyaXB0aW9uLmh0bWwjYm94X2V2ZW50c1xuICovXG5jbGFzcyBGU0ZpbGVzQ29sbGVjdGlvbiBleHRlbmRzIEJhc2VDb2xsZWN0aW9uIHtcblxuICAvKipcbiAgICogQ3JlYXRlcyB0aGUgY29sbGVjdGlvbi5cbiAgICovXG4gIGNvbnN0cnVjdG9yKCkge1xuICAgIHN1cGVyKCdmcy5maWxlcycsIG5ldyBTaW1wbGVTY2hlbWEoe1xuICAgICAgX2lkOiB7IHR5cGU6IE1vbmdvLk9iamVjdElEIH0sXG4gICAgICBmaWxlbmFtZTogU3RyaW5nLFxuICAgICAgbGVuZ3RoOiB7IHR5cGU6IE51bWJlciB9LFxuICAgICAgY2h1bmtTaXplOiB7IHR5cGU6IE51bWJlciB9LFxuICAgICAgdXBsb2FkRGF0ZTogeyB0eXBlOiBEYXRlIH0sXG4gICAgICBtZDU6IHsgdHlwZTogU3RyaW5nIH0sXG4gICAgICBtZXRhZGF0YTogeyB0eXBlOiBPYmplY3QgfSxcbiAgICAgICdtZXRhZGF0YS5ldmVudF9pZCc6IHsgdHlwZTogTnVtYmVyIH0sXG4gICAgICAnbWV0YWRhdGEuYm94X2lkJzogeyB0eXBlOiBTdHJpbmcgfSxcbiAgICB9KSk7XG5cbiAgICB0aGlzLnB1YmxpY2F0aW9uTmFtZXMgPSB7XG4gICAgfTtcbiAgfVxuXG4gIC8qKlxuICAgKiBEZWZpbmVzIGEgbmV3IGZzLmZpbGVzIGRvY3VtZW50LlxuICAgKiBAcGFyYW0ge1N0cmluZ30gZmlsZW5hbWUgLSBUaGUgZmlsZW5hbWUsIHdoaWNoIGNvcnJlc3BvbmRzIHRvIGJveF9ldmVudCdzIGRhdGFfZnNfZmlsZW5hbWUgZmllbGQuXG4gICAqIEBwYXJhbSB7TnVtYmVyfSBsZW5ndGggLSBUaGUgc2l6ZSBvZiBkYXRhLlxuICAgKiBAcGFyYW0ge051bWJlcn0gY2h1bmtTaXplIC0gVGhlIG1heCBzaXplIG9mIGNodW5rcy5cbiAgICogQHBhcmFtIHtOdW1iZXJ9IHVwbG9hZERhdGUgLSBUaGUgY3JlYXRpb24gZGF0ZS5cbiAgICogQHBhcmFtIHtTdHJpbmd9IG1kNSAtIFRoZSBmaWxlIG1kNS5cbiAgICogQHBhcmFtIHtPYmplY3R9IG1ldGFkYXRhIC0gT2JqZWN0IHRoYXQgaG9sZHMgdGhlIGV2ZW50J3MgZXZlbnRfaWQgYW5kIGJveF9pZC5cbiAgICogQHJldHVybnMgVGhlIG5ld2x5IGNyZWF0ZWQgZG9jdW1lbnQgSUQuXG4gICAqL1xuICBkZWZpbmUoeyBmaWxlbmFtZSwgbGVuZ3RoLCBjaHVua1NpemUsIHVwbG9hZERhdGUsIG1kNSwgbWV0YWRhdGEgfSkge1xuICAgIGNvbnN0IGRvY0lEID0gdGhpcy5fY29sbGVjdGlvbi5pbnNlcnQoeyBmaWxlbmFtZSwgbGVuZ3RoLCBjaHVua1NpemUsIHVwbG9hZERhdGUsIG1kNSwgbWV0YWRhdGEgfSk7XG4gICAgcmV0dXJuIGRvY0lEO1xuICB9XG5cbiAgLyoqXG4gICAqIFJldHVybnMgYW4gb2JqZWN0IHJlcHJlc2VudGluZyBhIHNpbmdsZSBmcy5maWxlLlxuICAgKiBAcGFyYW0ge09iamVjdH0gZG9jSUQgLSBUaGUgTW9uZ28uT2JqZWN0SUQgb2YgdGhlIGZzLmZpbGVzIGRvY3VtZW50LlxuICAgKiBAcmV0dXJucyB7T2JqZWN0fSAtIEFuIG9iamVjdCByZXByZXNlbnRpbmcgYSBzaW5nbGUgZnMuZmlsZXMgZG9jdW1lbnQuXG4gICAqL1xuICBkdW1wT25lKGRvY0lEKSB7XG4gICAgLyogZXNsaW50LWRpc2FibGUgY2FtZWxjYXNlICovXG4gICAgY29uc3QgZG9jID0gdGhpcy5maW5kRG9jKGRvY0lEKTtcbiAgICBjb25zdCBmaWxlbmFtZSA9IGRvYy5maWxlbmFtZTtcbiAgICBjb25zdCBsZW5ndGggPSBkb2MubGVuZ3RoO1xuICAgIGNvbnN0IGNodW5rU2l6ZSA9IGRvYy5jaHVua1NpemU7XG4gICAgY29uc3QgdXBsb2FkRGF0ZSA9IGRvYy51cGxvYWREYXRlO1xuICAgIGNvbnN0IG1kNSA9IGRvYy5tZDU7XG4gICAgY29uc3QgbWV0YWRhdGEgPSBkb2MubWV0YWRhdGE7XG5cbiAgICByZXR1cm4geyBmaWxlbmFtZSwgbGVuZ3RoLCBjaHVua1NpemUsIHVwbG9hZERhdGUsIG1kNSwgbWV0YWRhdGEgfTtcbiAgICAvKiBlc2xpbnQtZW5hYmxlIGNhbWVsY2FzZSAqL1xuICB9XG5cbiAgY2hlY2tJbnRlZ3JpdHkoKSB7XG4gICAgY29uc3QgcHJvYmxlbXMgPSBbXTtcbiAgICBjb25zdCB0b3RhbENvdW50ID0gdGhpcy5jb3VudCgpO1xuICAgIGNvbnN0IHZhbGlkYXRpb25Db250ZXh0ID0gdGhpcy5nZXRTY2hlbWEoKS5uYW1lZENvbnRleHQoJ2ZzRmlsZXNJbnRlZ3JpdHknKTtcbiAgICBjb25zdCBwYiA9IHByb2dyZXNzQmFyU2V0dXAodG90YWxDb3VudCwgMjAwMCwgYENoZWNraW5nICR7dGhpcy5fY29sbGVjdGlvbk5hbWV9IGNvbGxlY3Rpb246IGApO1xuXG4gICAgdGhpcy5maW5kKCkuZm9yRWFjaCgoZG9jLCBpbmRleCkgPT4ge1xuICAgICAgcGIudXBkYXRlQmFyKGluZGV4KTsgLy8gVXBkYXRlIHByb2dyZXNzIGJhci5cblxuICAgICAgLy8gVmFsaWRhdGUgZWFjaCBkb2N1bWVudCBhZ2FpbnN0IHRoZSBjb2xsZWN0aW9uIHNjaGVtYS5cbiAgICAgIHZhbGlkYXRpb25Db250ZXh0LnZhbGlkYXRlKGRvYyk7XG4gICAgICBpZiAoIXZhbGlkYXRpb25Db250ZXh0LmlzVmFsaWQoKSkge1xuICAgICAgICAvLyBlc2xpbnQtZGlzYWJsZS1uZXh0LWxpbmUgbWF4LWxlblxuICAgICAgICBwcm9ibGVtcy5wdXNoKGBGUy5GaWxlcyBkb2N1bWVudCBmYWlsZWQgc2NoZW1hIHZhbGlkYXRpb246ICR7ZG9jLl9pZH0gKEludmFsaWQga2V5czogJHtKU09OLnN0cmluZ2lmeSh2YWxpZGF0aW9uQ29udGV4dC5pbnZhbGlkS2V5cygpLCBudWxsLCAyKX0pYCk7XG4gICAgICB9XG4gICAgICB2YWxpZGF0aW9uQ29udGV4dC5yZXNldFZhbGlkYXRpb24oKTtcblxuICAgICAgY29uc3QgZXZlbnQgPSBFdmVudHMuZmluZE9uZSh7IGV2ZW50X2lkOiBkb2MubWV0YWRhdGEuZXZlbnRfaWQgfSk7XG4gICAgICAvLyBFbnN1cmUgbWV0YWRhdGEuZXZlbnRfaWQgcG9pbnRzIHRvIGFuIGV4aXN0aW5nIEV2ZW50IGRvY3VtZW50LlxuICAgICAgaWYgKCFldmVudCkge1xuICAgICAgICBwcm9ibGVtcy5wdXNoKGBGUy5GaWxlcyBtZXRhZGF0YS5ldmVudF9pZCBkb2VzIG5vdCBleGlzdCBpbiBFdmVudHMgY29sbGVjdGlvbjogJHtkb2MuX2lkfWApO1xuICAgICAgfVxuXG4gICAgICAvLyBFbnN1cmUgbWV0YWRhdGEuZXZlbnRfaWQgYW5kIG1ldGFkYXRhLmJveF9pZCBwb2ludHMgdG8gYW4gZXhpc3RpbmcgQm94RXZlbnQgZG9jdW1lbnQuXG4gICAgICBjb25zdCBib3hFdmVudCA9IEJveEV2ZW50cy5maW5kT25lKHsgZXZlbnRfaWQ6IGRvYy5tZXRhZGF0YS5ldmVudF9pZCwgYm94X2lkOiBkb2MubWV0YWRhdGEuYm94X2lkIH0pO1xuICAgICAgaWYgKCFib3hFdmVudCkge1xuICAgICAgICAvLyBlc2xpbnQtZGlzYWJsZS1uZXh0LWxpbmUgbWF4LWxlblxuICAgICAgICBwcm9ibGVtcy5wdXNoKGBGUy5GaWxlcyBtZXRhZGF0YS5ldmVudF9pZCBhbmQgbWV0YWRhdGFfYm94X2lkIHBhaXIgZG9lcyBub3QgZXhpc3QgaW4gdGhlIEJveEV2ZW50cyBjb2xsZWN0aW9uOiAke2RvYy5faWR9YCk7XG4gICAgICB9XG4gICAgfSk7XG5cbiAgICBwYi5jbGVhckludGVydmFsKCk7XG4gICAgcmV0dXJuIHByb2JsZW1zO1xuICB9XG5cbiAgLyoqXG4gICAqIExvYWRzIGFsbCBwdWJsaWNhdGlvbnMgcmVsYXRlZCB0byB0aGlzIGNvbGxlY3Rpb24uXG4gICAqL1xuICBwdWJsaXNoKCkgeyAvLyBlc2xpbnQtZGlzYWJsZS1saW5lIGNsYXNzLW1ldGhvZHMtdXNlLXRoaXNcbiAgICBpZiAoTWV0ZW9yLmlzU2VydmVyKSB7IC8vIGVzbGludC1kaXNhYmxlLWxpbmUgbm8tZW1wdHlcbiAgICB9XG4gIH1cbn1cblxuLyoqXG4gKiBQcm92aWRlcyB0aGUgc2luZ2xldG9uIGluc3RhbmNlIG9mIHRoaXMgY2xhc3MuXG4gKiBAdHlwZSB7RlNGaWxlc0NvbGxlY3Rpb259XG4gKi9cbmV4cG9ydCBjb25zdCBGU0ZpbGVzID0gbmV3IEZTRmlsZXNDb2xsZWN0aW9uKCk7XG4iLCJpbXBvcnQgeyBWYWxpZGF0ZWRNZXRob2QgfSBmcm9tICdtZXRlb3IvbWRnOnZhbGlkYXRlZC1tZXRob2QnO1xuaW1wb3J0IFNpbXBsZVNjaGVtYSBmcm9tICdzaW1wbC1zY2hlbWEnO1xuaW1wb3J0IHsgRlNGaWxlcyB9IGZyb20gJy4vRlNGaWxlc0NvbGxlY3Rpb24nO1xuaW1wb3J0IHsgRlNDaHVua3MgfSBmcm9tICcuLi9mcy1jaHVua3MvRlNDaHVua3NDb2xsZWN0aW9uJztcblxuZXhwb3J0IGNvbnN0IGdldEV2ZW50RGF0YSA9IG5ldyBWYWxpZGF0ZWRNZXRob2Qoe1xuICBuYW1lOiAnRlNGaWxlcy5nZXRFdmVudERhdGEnLFxuICB2YWxpZGF0ZTogbmV3IFNpbXBsZVNjaGVtYSh7XG4gICAgZmlsZW5hbWU6IHsgdHlwZTogU3RyaW5nIH0sXG4gIH0pLnZhbGlkYXRvcih7IGNsZWFuOiB0cnVlIH0pLFxuICBydW4oeyBmaWxlbmFtZSB9KSB7XG4gICAgaWYgKCF0aGlzLmlzU2ltdWxhdGlvbikge1xuICAgICAgLy8gR2V0IGZpbGUgYW5kIGNodW5rc1xuICAgICAgY29uc3QgZmlsZSA9IEZTRmlsZXMuZmluZE9uZSh7IGZpbGVuYW1lIH0pO1xuICAgICAgY29uc3QgY2h1bmtzID0gRlNDaHVua3MuZmluZCh7IGZpbGVzX2lkOiBmaWxlLl9pZCB9LCB7IHNvcnQ6IHsgbjogMSB9IH0pLmZldGNoKCk7XG5cbiAgICAgIC8vIEdyaWRmcyBzZWVtcyB0byBzdG9yZSBjaHVua3MgYXNcbiAgICAgIC8vIE5lZWQgdG8gcGFyc2UgYmluYXJ5IGRhdGEgY2h1bmtzIGFzIDE2LWJpdCBzaWduZWQgaW50LlxuICAgICAgY29uc3QgaW50MTZDaHVua3MgPSBbXTsgLy8gQXJyYXkgb2YgY2h1bmtzLlxuICAgICAgbGV0IHRvdGFsU2l6ZSA9IDA7XG4gICAgICBjaHVua3MuZm9yRWFjaChjaHVuayA9PiB7XG4gICAgICAgIGNvbnN0IHU4ID0gbmV3IFVpbnQ4QXJyYXkoY2h1bmsuZGF0YSk7XG4gICAgICAgIGNvbnN0IHMxNiA9IG5ldyBJbnQxNkFycmF5KHU4LmJ1ZmZlcik7XG4gICAgICAgIGludDE2Q2h1bmtzLnB1c2goczE2KTtcbiAgICAgICAgdG90YWxTaXplICs9IHMxNi5sZW5ndGg7XG4gICAgICB9KTtcblxuICAgICAgLy8gRmxhdHRlbi9jb21iaW5lIGFsbCBjaHVua3MgdG8gYSBzaW5nbGUgYXJyYXkuXG4gICAgICBjb25zdCBjb21iaW5lZEludDE2Q2h1bmtzID0gbmV3IEludDE2QXJyYXkodG90YWxTaXplKTtcbiAgICAgIGxldCBvZmZzZXQgPSAwO1xuICAgICAgaW50MTZDaHVua3MuZm9yRWFjaCgoY2h1bmspID0+IHtcbiAgICAgICAgY29tYmluZWRJbnQxNkNodW5rcy5zZXQoY2h1bmssIG9mZnNldCk7XG4gICAgICAgIG9mZnNldCArPSBjaHVuay5sZW5ndGg7XG4gICAgICB9KTtcblxuICAgICAgcmV0dXJuIEFycmF5LmZyb20oY29tYmluZWRJbnQxNkNodW5rcyk7IC8vIFJldHVybiBkYXRhIGFzIHJlZ3VsYXIgYXJyYXkuXG4gICAgfVxuICAgIHJldHVybiBudWxsO1xuICB9LFxufSk7XG4iLCJpbXBvcnQgJy4vRlNGaWxlc0NvbGxlY3Rpb24uanMnO1xuaW1wb3J0ICcuL0ZTRmlsZXNDb2xsZWN0aW9uTWV0aG9kcy5qcyc7XG4iLCJpbXBvcnQgeyBNZXRlb3IgfSBmcm9tICdtZXRlb3IvbWV0ZW9yJztcbmltcG9ydCB7IE1vbmdvIH0gZnJvbSAnbWV0ZW9yL21vbmdvJztcbmltcG9ydCB7IGNoZWNrIH0gZnJvbSAnbWV0ZW9yL2NoZWNrJztcbmltcG9ydCBTaW1wbGVTY2hlbWEgZnJvbSAnc2ltcGwtc2NoZW1hJztcbmltcG9ydCBCYXNlQ29sbGVjdGlvbiBmcm9tICcuLi9iYXNlL0Jhc2VDb2xsZWN0aW9uLmpzJztcbmltcG9ydCB7IE9wcUJveGVzIH0gZnJvbSAnLi4vb3BxLWJveGVzL09wcUJveGVzQ29sbGVjdGlvbic7XG5pbXBvcnQgeyBwcm9ncmVzc0JhclNldHVwIH0gZnJvbSAnLi4vLi4vbW9kdWxlcy91dGlscyc7XG5cbmNsYXNzIE1lYXN1cmVtZW50c0NvbGxlY3Rpb24gZXh0ZW5kcyBCYXNlQ29sbGVjdGlvbiB7XG5cbiAgLyoqXG4gICAqIENyZWF0ZXMgdGhlIE1lYXN1cmVtZW50cyBjb2xsZWN0aW9uLlxuICAgKi9cbiAgY29uc3RydWN0b3IoKSB7XG4gICAgc3VwZXIoJ21lYXN1cmVtZW50cycsIG5ldyBTaW1wbGVTY2hlbWEoe1xuICAgICAgX2lkOiB7IHR5cGU6IE1vbmdvLk9iamVjdElEIH0sXG4gICAgICBib3hfaWQ6IHsgdHlwZTogU3RyaW5nIH0sXG4gICAgICB0aW1lc3RhbXBfbXM6IHsgdHlwZTogTnVtYmVyIH0sXG4gICAgICB2b2x0YWdlOiB7IHR5cGU6IE51bWJlciB9LFxuICAgICAgZnJlcXVlbmN5OiB7IHR5cGU6IE51bWJlciB9LFxuICAgICAgdGhkOiB7IHR5cGU6IE51bWJlciwgb3B0aW9uYWw6IHRydWUgfSxcbiAgICAgIGV4cGlyZUF0OiB7IHR5cGU6IERhdGUgfSxcbiAgICB9KSk7XG5cbiAgICB0aGlzLnB1YmxpY2F0aW9uTmFtZXMgPSB7XG4gICAgICBSRUNFTlRfTUVBU1VSRU1FTlRTOiAncmVjZW50X21lYXN1cmVtZW50cycsXG4gICAgfTtcbiAgICBpZiAoTWV0ZW9yLnNlcnZlcikge1xuICAgICAgdGhpcy5fY29sbGVjdGlvbi5yYXdDb2xsZWN0aW9uKCkuY3JlYXRlSW5kZXgoeyB0aW1lc3RhbXBfbXM6IDEsIGJveF9pZDogMSB9LCB7IGJhY2tncm91bmQ6IHRydWUgfSk7XG4gICAgfVxuICB9XG5cbiAgLyoqXG4gICAqIERlZmluZXMgYSBuZXcgTWVhc3VyZW1lbnQgZG9jdW1lbnQuXG4gICAqIEBwYXJhbSB7U3RyaW5nfSBib3hfaWQgLSBUaGUgT1BRQm94J3MgaWQgdmFsdWUgKG5vdCBNb25nbyBJRClcbiAgICogQHBhcmFtIHtOdW1iZXJ9IHRpbWVzdGFtcF9tcyAtIFRoZSB1bml4IHRpbWVzdGFtcCAobWlsbGlzKSBvZiB0aGUgbWVhc3VyZW1lbnQuXG4gICAqIEBwYXJhbSB7TnVtYmVyfSB2b2x0YWdlIC0gVGhlIHZvbHRhZ2UgbWVhc3VyZW1lbnQuXG4gICAqIEBwYXJhbSB7TnVtYmVyfSBmcmVxdWVuY3kgLSBUaGUgZnJlcXVlbmN5IG1lYXN1cmVtZW50LlxuICAgKiBAcGFyYW0ge051bWJlcn0gdGhkIC0gVGhlIHRoZCBtZWFzdXJlbWVudC5cbiAgICogQHJldHVybnMgVGhlIG5ld2x5IGNyZWF0ZWQgZG9jdW1lbnQgSUQuXG4gICAqL1xuICBkZWZpbmUoeyBib3hfaWQsIHRpbWVzdGFtcF9tcywgdm9sdGFnZSwgZnJlcXVlbmN5LCB0aGQgfSkge1xuICAgIGNvbnN0IGRvY0lEID0gdGhpcy5fY29sbGVjdGlvbi5pbnNlcnQoeyBib3hfaWQsIHRpbWVzdGFtcF9tcywgdm9sdGFnZSwgZnJlcXVlbmN5LCB0aGQgfSk7XG4gICAgcmV0dXJuIGRvY0lEO1xuICB9XG5cbiAgLyoqXG4gICAqIFJldHVybnMgYW4gb2JqZWN0IHJlcHJlc2VudGluZyBhIHNpbmdsZSBNZWFzdXJlbWVudC5cbiAgICogQHBhcmFtIHtPYmplY3R9IGRvY0lEIC0gVGhlIE1vbmdvLk9iamVjdElEIG9mIHRoZSBNZWFzdXJlbWVudC5cbiAgICogQHJldHVybnMge09iamVjdH0gLSBBbiBvYmplY3QgcmVwcmVzZW50aW5nIGEgc2luZ2xlIE1lYXN1cmVtZW50LlxuICAgKi9cbiAgZHVtcE9uZShkb2NJRCkge1xuICAgIC8qIGVzbGludC1kaXNhYmxlIGNhbWVsY2FzZSAqL1xuICAgIGNvbnN0IGRvYyA9IHRoaXMuZmluZERvYyhkb2NJRCk7XG4gICAgY29uc3QgYm94X2lkID0gZG9jLmJveF9pZDtcbiAgICBjb25zdCB0aW1lc3RhbXBfbXMgPSBkb2MudGltZXN0YW1wX21zO1xuICAgIGNvbnN0IHZvbHRhZ2UgPSBkb2Mudm9sdGFnZTtcbiAgICBjb25zdCBmcmVxdWVuY3kgPSBkb2MuZnJlcXVlbmN5O1xuICAgIGNvbnN0IHRoZCA9IGRvYy50aGQ7XG5cbiAgICByZXR1cm4geyBib3hfaWQsIHRpbWVzdGFtcF9tcywgdm9sdGFnZSwgZnJlcXVlbmN5LCB0aGQgfTtcbiAgICAvKiBlc2xpbnQtZW5hYmxlIGNhbWVsY2FzZSAqL1xuICB9XG5cbiAgY2hlY2tJbnRlZ3JpdHkoKSB7XG4gICAgY29uc3QgcHJvYmxlbXMgPSBbXTtcbiAgICBjb25zdCB0b3RhbENvdW50ID0gdGhpcy5jb3VudCgpO1xuICAgIGNvbnN0IHZhbGlkYXRpb25Db250ZXh0ID0gdGhpcy5nZXRTY2hlbWEoKS5uYW1lZENvbnRleHQoJ21lYXN1cmVtZW50c0ludGVncml0eScpO1xuICAgIGNvbnN0IHBiID0gcHJvZ3Jlc3NCYXJTZXR1cCh0b3RhbENvdW50LCAyMDAwLCBgQ2hlY2tpbmcgJHt0aGlzLl9jb2xsZWN0aW9uTmFtZX0gY29sbGVjdGlvbjogYCk7XG5cbiAgICAvLyBHZXQgYWxsIE9wcUJveCBJRHMuXG4gICAgY29uc3QgYm94SURzID0gT3BxQm94ZXMuZmluZCgpLm1hcChkb2MgPT4gZG9jLmJveF9pZCk7XG5cbiAgICB0aGlzLmZpbmQoKS5mb3JFYWNoKChkb2MsIGluZGV4KSA9PiB7XG4gICAgICBwYi51cGRhdGVCYXIoaW5kZXgpOyAvLyBVcGRhdGUgcHJvZ3Jlc3MgYmFyLlxuXG4gICAgICAvLyBWYWxpZGF0ZSBlYWNoIGRvY3VtZW50IGFnYWluc3QgdGhlIGNvbGxlY3Rpb24gc2NoZW1hLlxuICAgICAgdmFsaWRhdGlvbkNvbnRleHQudmFsaWRhdGUoZG9jKTtcbiAgICAgIGlmICghdmFsaWRhdGlvbkNvbnRleHQuaXNWYWxpZCgpKSB7XG4gICAgICAgIC8vIGVzbGludC1kaXNhYmxlLW5leHQtbGluZSBtYXgtbGVuXG4gICAgICAgIHByb2JsZW1zLnB1c2goYE1lYXN1cmVtZW50cyBkb2N1bWVudCBmYWlsZWQgc2NoZW1hIHZhbGlkYXRpb246ICR7ZG9jLl9pZH0gKEludmFsaWQga2V5czogJHtKU09OLnN0cmluZ2lmeSh2YWxpZGF0aW9uQ29udGV4dC5pbnZhbGlkS2V5cygpLCBudWxsLCAyKX0pYCk7XG4gICAgICB9XG4gICAgICB2YWxpZGF0aW9uQ29udGV4dC5yZXNldFZhbGlkYXRpb24oKTtcblxuICAgICAgLy8gRW5zdXJlIGJveF9pZCBvZiB0aGUgbWVhc3VyZW1lbnQgZXhpc3RzIGluIG9wcV9ib3hlcyBjb2xsZWN0aW9uLlxuICAgICAgaWYgKCFib3hJRHMuaW5jbHVkZXMoZG9jLmJveF9pZCkpIHtcbiAgICAgICAgcHJvYmxlbXMucHVzaChgTWVhc3VyZW1lbnRzIGJveF9pZCBkb2VzIG5vdCBleGlzdCBpbiBvcHFfYm94ZXMgY29sbGVjdGlvbjogJHtkb2MuYm94X2lkfSAoZG9jSUQ6ICR7ZG9jLl9pZH0pYCk7XG4gICAgICB9XG4gICAgfSk7XG5cbiAgICBwYi5jbGVhckludGVydmFsKCk7XG4gICAgcmV0dXJuIHByb2JsZW1zO1xuICB9XG5cbiAgLyoqXG4gICAqIExvYWRzIGFsbCBwdWJsaWNhdGlvbnMgcmVsYXRlZCB0byB0aGUgTWVhc3VyZW1lbnRzIGNvbGxlY3Rpb24uXG4gICAqIE5vdGU6IFdlIGNvbmRpdGlvbmFsbHkgaW1wb3J0IHRoZSBwdWJsaWNhdGlvbnMgZmlsZSBvbmx5IG9uIHRoZSBzZXJ2ZXIgYXMgYSB3YXkgdG8gaGlkZSBwdWJsaWNhdGlvbiBjb2RlIGZyb21cbiAgICogYmVpbmcgc2VudCB0byB0aGUgY2xpZW50LlxuICAgKi9cbiAgcHVibGlzaCgpIHsgLy8gZXNsaW50LWRpc2FibGUtbGluZSBjbGFzcy1tZXRob2RzLXVzZS10aGlzXG4gICAgaWYgKE1ldGVvci5pc1NlcnZlcikge1xuICAgICAgY29uc3Qgc2VsZiA9IHRoaXM7XG4gICAgICBNZXRlb3IucHVibGlzaCh0aGlzLnB1YmxpY2F0aW9uTmFtZXMuUkVDRU5UX01FQVNVUkVNRU5UUywgZnVuY3Rpb24gKHN0YXJ0VGltZVNlY29uZHNBZ28sIGJveElEKSB7XG4gICAgICAgIGNoZWNrKHN0YXJ0VGltZVNlY29uZHNBZ28sIE51bWJlcik7XG4gICAgICAgIGNoZWNrKGJveElELCBTdHJpbmcpO1xuXG4gICAgICAgIGNvbnN0IGluc3RhbmNlID0gdGhpcztcblxuICAgICAgICBjb25zdCBzdGFydFRpbWVNcyA9IERhdGUubm93KCkgLSAoc3RhcnRUaW1lU2Vjb25kc0FnbyAqIDEwMDApO1xuICAgICAgICAvLyBlc2xpbnQtZGlzYWJsZS1uZXh0LWxpbmUgbWF4LWxlblxuICAgICAgICBjb25zdCBwdWJsaXNoZWRNZWFzdXJlbWVudHNNYXAgPSBuZXcgTWFwKCk7IC8vIHt0aW1lc3RhbXA6IGlkfSAtIFRvIGtlZXAgdHJhY2sgb2YgY3VycmVudGx5IHB1Ymxpc2hlZCBtZWFzdXJlbWVudHMuXG5cbiAgICAgICAgY29uc3Qgc2VsZWN0b3IgPSAoYm94SUQpID8ge1xuICAgICAgICAgIGJveF9pZDogYm94SUQsXG4gICAgICAgICAgdGltZXN0YW1wX21zOiB7ICRndGU6IHN0YXJ0VGltZU1zIH0sXG4gICAgICAgIH0gOiB7IHRpbWVzdGFtcF9tczogeyAkZ3RlOiBzdGFydFRpbWVNcyB9IH07XG5cbiAgICAgICAgbGV0IGluaXQgPSB0cnVlO1xuICAgICAgICBjb25zdCBtZWFzdXJlbWVudHNIYW5kbGUgPSBzZWxmLmZpbmQoc2VsZWN0b3IsIHtcbiAgICAgICAgICBmaWVsZHM6IHsgX2lkOiAxLCB0aW1lc3RhbXBfbXM6IDEsIHZvbHRhZ2U6IDEsIGZyZXF1ZW5jeTogMSwgYm94X2lkOiAxIH0sXG4gICAgICAgICAgcG9sbGluZ0ludGVydmFsTXM6IDEwMDAsXG4gICAgICAgIH0pLm9ic2VydmVDaGFuZ2VzKHtcbiAgICAgICAgICBhZGRlZDogZnVuY3Rpb24gKGlkLCBmaWVsZHMpIHtcbiAgICAgICAgICAgIHB1Ymxpc2hlZE1lYXN1cmVtZW50c01hcC5zZXQoZmllbGRzLnRpbWVzdGFtcF9tcywgaWQpO1xuICAgICAgICAgICAgaW5zdGFuY2UuYWRkZWQoJ21lYXN1cmVtZW50cycsIGlkLCBmaWVsZHMpO1xuXG4gICAgICAgICAgICBpZiAoIWluaXQpIHtcbiAgICAgICAgICAgICAgY29uc3Qgc3RhcnRUaW1lID0gRGF0ZS5ub3coKSAtIChzdGFydFRpbWVTZWNvbmRzQWdvICogMTAwMCk7XG4gICAgICAgICAgICAgIC8vIE5vdGU6IChfaWQsIHRpbWVzdGFtcCkgY29ycmVzcG9uZHMgdG8gKHZhbHVlLCBrZXkpOyBmb3Igc29tZSByZWFzb24gTWFwJ3MgZm9yZWFjaCBpcyBjYWxsZWQgdGhpcyB3YXkuXG4gICAgICAgICAgICAgIHB1Ymxpc2hlZE1lYXN1cmVtZW50c01hcC5mb3JFYWNoKChfaWQsIHRpbWVzdGFtcCkgPT4ge1xuICAgICAgICAgICAgICAgIGlmICh0aW1lc3RhbXAgPCBzdGFydFRpbWUpIHtcbiAgICAgICAgICAgICAgICAgIGluc3RhbmNlLnJlbW92ZWQoJ21lYXN1cmVtZW50cycsIF9pZCk7XG4gICAgICAgICAgICAgICAgICBwdWJsaXNoZWRNZWFzdXJlbWVudHNNYXAuZGVsZXRlKHRpbWVzdGFtcCk7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICB9LFxuICAgICAgICB9KTtcbiAgICAgICAgaW5pdCA9IGZhbHNlO1xuICAgICAgICBpbnN0YW5jZS5yZWFkeSgpO1xuICAgICAgICBpbnN0YW5jZS5vblN0b3AoZnVuY3Rpb24gKCkge1xuICAgICAgICAgIG1lYXN1cmVtZW50c0hhbmRsZS5zdG9wKCk7XG4gICAgICAgIH0pO1xuICAgICAgfSk7XG4gICAgfVxuICB9XG59XG5cbi8qKlxuICogUHJvdmlkZXMgdGhlIHNpbmdsZXRvbiBpbnN0YW5jZSBvZiB0aGlzIGNsYXNzLlxuICogQHR5cGUge01lYXN1cmVtZW50c0NvbGxlY3Rpb259XG4gKi9cbmV4cG9ydCBjb25zdCBNZWFzdXJlbWVudHMgPSBuZXcgTWVhc3VyZW1lbnRzQ29sbGVjdGlvbigpO1xuIiwiaW1wb3J0IHsgTW9uZ28gfSBmcm9tICdtZXRlb3IvbW9uZ28nO1xuaW1wb3J0IF8gZnJvbSAnbG9kYXNoJztcbmltcG9ydCBNb21lbnQgZnJvbSAnbW9tZW50JztcbmltcG9ydCB7IFZhbGlkYXRlZE1ldGhvZCB9IGZyb20gJ21ldGVvci9tZGc6dmFsaWRhdGVkLW1ldGhvZCc7XG5pbXBvcnQgU2ltcGxlU2NoZW1hIGZyb20gJ3NpbXBsLXNjaGVtYSc7XG5pbXBvcnQgeyBNZWFzdXJlbWVudHMgfSBmcm9tICcuL01lYXN1cmVtZW50c0NvbGxlY3Rpb24uanMnO1xuaW1wb3J0IHsgRXZlbnRzIH0gZnJvbSAnLi4vZXZlbnRzL0V2ZW50c0NvbGxlY3Rpb24uanMnO1xuXG5leHBvcnQgY29uc3QgdG90YWxNZWFzdXJlbWVudHNDb3VudCA9IG5ldyBWYWxpZGF0ZWRNZXRob2Qoe1xuICBuYW1lOiAnTWVhc3VyZW1lbnRzLnRvdGFsTWVhc3VyZW1lbnRzQ291bnQnLFxuICB2YWxpZGF0ZTogbmV3IFNpbXBsZVNjaGVtYSgpLnZhbGlkYXRvcih7IGNsZWFuOiB0cnVlIH0pLFxuICBydW4oKSB7XG4gICAgcmV0dXJuIE1lYXN1cmVtZW50cy5maW5kKHt9KS5jb3VudCgpO1xuICB9LFxufSk7XG5cbmV4cG9ydCBjb25zdCBjaGVja0JveFN0YXR1cyA9IG5ldyBWYWxpZGF0ZWRNZXRob2Qoe1xuICBuYW1lOiAnTWVhc3VyZW1lbnRzLmNoZWNrQm94U3RhdHVzJyxcbiAgdmFsaWRhdGU6IG5ldyBTaW1wbGVTY2hlbWEoe1xuICAgIGJveF9pZDogeyB0eXBlOiBTdHJpbmcgfSxcbiAgfSkudmFsaWRhdG9yKHsgY2xlYW46IHRydWUgfSksXG4gIHJ1bih7IGJveF9pZCB9KSB7XG4gICAgaWYgKCF0aGlzLmlzU2ltdWxhdGlvbikge1xuICAgICAgY29uc3Qgb25lTWludXRlQWdvID0gTW9tZW50KCkuc3VidHJhY3QoNjAsICdzZWNvbmRzJykudmFsdWVPZigpO1xuICAgICAgY29uc3QgbWVhc3VyZW1lbnRzID0gTWVhc3VyZW1lbnRzLmZpbmRPbmUoeyBib3hfaWQsIHRpbWVzdGFtcF9tczogeyAkZ3RlOiBvbmVNaW51dGVBZ28gfSB9KTtcbiAgICAgIHJldHVybiAhIW1lYXN1cmVtZW50cztcbiAgICB9XG4gICAgcmV0dXJuIG51bGw7XG4gIH0sXG59KTtcblxuZXhwb3J0IGNvbnN0IGFjdGl2ZUJveElEcyA9IG5ldyBWYWxpZGF0ZWRNZXRob2Qoe1xuICBuYW1lOiAnTWVhc3VyZW1lbnRzLmFjdGl2ZUJveElEcycsXG4gIHZhbGlkYXRlOiBuZXcgU2ltcGxlU2NoZW1hKCkudmFsaWRhdG9yKHsgY2xlYW46IHRydWUgfSksXG4gIHJ1bigpIHtcbiAgICBpZiAoIXRoaXMuaXNTaW11bGF0aW9uKSB7XG4gICAgICBjb25zdCBvbmVNaW51dGVBZ28gPSBNb21lbnQoKS5zdWJ0cmFjdCg2MCwgJ3NlY29uZHMnKS52YWx1ZU9mKCk7XG4gICAgICBjb25zdCBtZWFzdXJlbWVudHMgPSBNZWFzdXJlbWVudHMuZmluZCh7IHRpbWVzdGFtcF9tczogeyAkZ3RlOiBvbmVNaW51dGVBZ28gfSB9KS5mZXRjaCgpO1xuICAgICAgaWYgKG1lYXN1cmVtZW50cy5sZW5ndGggPiAwKSB7XG4gICAgICAgIHJldHVybiBfLnVuaXEoXy5tYXAobWVhc3VyZW1lbnRzLCAnYm94X2lkJykpO1xuICAgICAgfVxuICAgIH1cbiAgICByZXR1cm4gbnVsbDtcbiAgfSxcbn0pO1xuXG5leHBvcnQgY29uc3QgZ2V0QWN0aXZlQm94SWRzID0gbmV3IFZhbGlkYXRlZE1ldGhvZCh7XG4gIG5hbWU6ICdNZWFzdXJlbWVudHMuZ2V0QWN0aXZlQm94SWRzJyxcbiAgdmFsaWRhdGU6IG5ldyBTaW1wbGVTY2hlbWEoe1xuICAgIHN0YXJ0VGltZU1zOiB7IHR5cGU6IE51bWJlciB9LFxuICB9KS52YWxpZGF0b3IoeyBjbGVhbjogdHJ1ZSB9KSxcbiAgcnVuKHsgc3RhcnRUaW1lTXMgfSkge1xuICAgIGNvbnN0IHJlY2VudE1lYXN1cmVtZW50cyA9IE1lYXN1cmVtZW50cy5maW5kKHtcbiAgICAgIHRpbWVzdGFtcF9tczogeyAkZ3RlOiBzdGFydFRpbWVNcyB9LFxuICAgIH0sIHtcbiAgICAgIGZpZWxkczogeyBib3hfaWQ6IDEgfSxcbiAgICB9KS5mZXRjaCgpO1xuXG4gICAgLy8gUmV0dXJucyBhbiBhcnJheSBvZiB1bmlxdWUgZGV2aWNlSWRzLCBzb3J0ZWQgYXNjLlxuICAgIHJldHVybiAocmVjZW50TWVhc3VyZW1lbnRzLmxlbmd0aCA+IDApXG4gICAgICA/IF8udW5pcShfLnBsdWNrKHJlY2VudE1lYXN1cmVtZW50cywgJ2JveF9pZCcpKS5zb3J0KChhLCBiKSA9PiBhIC0gYilcbiAgICAgIDogbnVsbDtcbiAgfSxcbn0pO1xuXG5leHBvcnQgY29uc3QgZ2V0RXZlbnRNZWFzdXJlbWVudHNCeU1ldGFEYXRhSWQgPSBuZXcgVmFsaWRhdGVkTWV0aG9kKHtcbiAgbmFtZTogJ01lYXN1cmVtZW50cy5nZXRFdmVudE1lYXN1cmVtZW50c0J5TWV0YURhdGFJZCcsXG4gIHZhbGlkYXRlOiBuZXcgU2ltcGxlU2NoZW1hKHtcbiAgICBldmVudE1ldGFEYXRhSWQ6IHsgdHlwZTogTW9uZ28uT2JqZWN0SUQgfSxcbiAgfSkudmFsaWRhdG9yKHsgY2xlYW46IHRydWUgfSksXG4gIHJ1bih7IGV2ZW50TWV0YURhdGFJZCB9KSB7XG4gICAgaWYgKCF0aGlzLmlzU2ltdWxhdGlvbikge1xuICAgICAgY29uc3QgZXZlbnRNZXRhRGF0YSA9IEV2ZW50cy5maW5kT25lKHsgX2lkOiBldmVudE1ldGFEYXRhSWQgfSk7XG5cbiAgICAgIGNvbnN0IGV2ZW50TWVhc3VyZW1lbnRzID0gTWVhc3VyZW1lbnRzLmZpbmQoe1xuICAgICAgICBib3hfaWQ6IGV2ZW50TWV0YURhdGEuYm94ZXNfdHJpZ2dlcmVkWzBdLCAvLyBKdXN0IGxvb2sgYXQgZmlyc3QgdHJpZ2dlcmluZyBkZXZpY2UgZm9yIG5vdy5cbiAgICAgICAgdGltZXN0YW1wX21zOiB7ICRndGU6IGV2ZW50TWV0YURhdGEuZXZlbnRfc3RhcnQsICRsdGU6IGV2ZW50TWV0YURhdGEuZXZlbnRfZW5kIH0sXG4gICAgICB9LCB7XG4gICAgICAgIHNvcnQ6IHsgZXZlbnRfZW5kOiAxIH0sXG4gICAgICB9KS5mZXRjaCgpO1xuXG4gICAgICBjb25zdCBmaXJzdE1lYXN1cmVtZW50VGltZXN0YW1wID0gZXZlbnRNZWFzdXJlbWVudHNbMF0udGltZXN0YW1wX21zO1xuICAgICAgY29uc3QgbGFzdE1lYXN1cmVtZW50VGltZXN0YW1wID0gZXZlbnRNZWFzdXJlbWVudHNbZXZlbnRNZWFzdXJlbWVudHMubGVuZ3RoIC0gMV0udGltZXN0YW1wX21zO1xuXG4gICAgICAvLyBMZXQncyBhbHNvIHJldHJpZXZlIHNvbWUgbWVhc3VyZW1lbnRzIHByZWNlZGluZyBhbmQgcHJvY2VlZGluZyBldmVudCByYW5nZS4gMjAlIG9mIGV2ZW50IHJhbmdlIG9uIGJvdGggc2lkZXMuXG4gICAgICBjb25zdCBldmVudER1cmF0aW9uTXMgPSAoZXZlbnRNZXRhRGF0YS5ldmVudF9lbmQgLSBldmVudE1ldGFEYXRhLmV2ZW50X3N0YXJ0KTtcbiAgICAgIGNvbnN0IHByZWNlZGluZ1RpbWVzdGFtcCA9IGV2ZW50TWV0YURhdGEuZXZlbnRfc3RhcnQgLSAoZXZlbnREdXJhdGlvbk1zICogMC4yKTtcbiAgICAgIGNvbnN0IHByb2NlZWRpbmdUaW1lc3RhbXAgPSBldmVudE1ldGFEYXRhLmV2ZW50X2VuZCArIChldmVudER1cmF0aW9uTXMgKiAwLjIpO1xuXG4gICAgICBjb25zdCBwcmVjZWRpbmdNZWFzdXJlbWVudHMgPSBNZWFzdXJlbWVudHMuZmluZCh7XG4gICAgICAgIGJveF9pZDogZXZlbnRNZXRhRGF0YS5ib3hlc190cmlnZ2VyZWRbMF0sXG4gICAgICAgIHRpbWVzdGFtcF9tczogeyAkZ3RlOiBwcmVjZWRpbmdUaW1lc3RhbXAsICRsdGU6IGZpcnN0TWVhc3VyZW1lbnRUaW1lc3RhbXAgfSxcbiAgICAgIH0sIHt9KS5mZXRjaCgpO1xuXG4gICAgICBjb25zdCBwcm9jZWVkaW5nTWVhc3VyZW1lbnRzID0gTWVhc3VyZW1lbnRzLmZpbmQoe1xuICAgICAgICBib3hfaWQ6IGV2ZW50TWV0YURhdGEuYm94ZXNfdHJpZ2dlcmVkWzBdLFxuICAgICAgICB0aW1lc3RhbXBfbXM6IHsgJGd0ZTogbGFzdE1lYXN1cmVtZW50VGltZXN0YW1wLCAkbHRlOiBwcm9jZWVkaW5nVGltZXN0YW1wIH0sXG4gICAgICB9LCB7fSkuZmV0Y2goKTtcblxuICAgICAgcmV0dXJuIHsgZXZlbnRNZWFzdXJlbWVudHMsIHByZWNlZGluZ01lYXN1cmVtZW50cywgcHJvY2VlZGluZ01lYXN1cmVtZW50cyB9O1xuICAgIH1cblxuICAgIHJldHVybiBudWxsO1xuICB9LFxufSk7XG5cbmV4cG9ydCBjb25zdCBnZXRFdmVudE1lYXN1cmVtZW50cyA9IG5ldyBWYWxpZGF0ZWRNZXRob2Qoe1xuICBuYW1lOiAnTWVhc3VyZW1lbnRzLmdldEV2ZW50TWVhc3VyZW1lbnRzJyxcbiAgdmFsaWRhdGU6IG5ldyBTaW1wbGVTY2hlbWEoe1xuICAgIGJveF9pZDogeyB0eXBlOiBOdW1iZXIsIG9wdGlvbmFsOiB0cnVlIH0sIC8vIEdldCByaWQgb2Ygb3B0aW9uYWwgbGF0ZXIuXG4gICAgc3RhcnRUaW1lOiB7IHR5cGU6IE51bWJlciwgb3B0aW9uYWw6IHRydWUgfSxcbiAgICBlbmRUaW1lOiB7IHR5cGU6IE51bWJlciwgb3B0aW9uYWw6IHRydWUgfSxcbiAgfSkudmFsaWRhdG9yKHsgY2xlYW46IHRydWUgfSksXG4gIHJ1bih7IGJveF9pZCwgc3RhcnRUaW1lLCBlbmRUaW1lIH0pIHtcbiAgICBpZiAoIXRoaXMuaXNTaW11bGF0aW9uKSB7XG4gICAgICBjb25zb2xlLmxvZyhib3hfaWQsIHN0YXJ0VGltZSwgZW5kVGltZSk7XG4gICAgICBjb25zdCBldmVudE1lYXN1cmVtZW50cyA9IE1lYXN1cmVtZW50cy5maW5kKHtcbiAgICAgICAgYm94X2lkLFxuICAgICAgICB0aW1lc3RhbXBfbXM6IHsgJGd0ZTogc3RhcnRUaW1lLCAkbHRlOiBlbmRUaW1lIH0sXG4gICAgICB9LCB7XG4gICAgICAgIHNvcnQ6IHsgdGltZXN0YW1wX21zOiAxIH0sXG4gICAgICB9KS5mZXRjaCgpO1xuXG4gICAgICBjb25zdCBmaXJzdE1lYXN1cmVtZW50VGltZXN0YW1wID0gZXZlbnRNZWFzdXJlbWVudHNbMF0udGltZXN0YW1wX21zO1xuICAgICAgY29uc3QgbGFzdE1lYXN1cmVtZW50VGltZXN0YW1wID0gZXZlbnRNZWFzdXJlbWVudHNbZXZlbnRNZWFzdXJlbWVudHMubGVuZ3RoIC0gMV0udGltZXN0YW1wX21zO1xuXG4gICAgICAvLyBMZXQncyBhbHNvIHJldHJpZXZlIHNvbWUgbWVhc3VyZW1lbnRzIHByZWNlZGluZyBhbmQgcHJvY2VlZGluZyBldmVudCByYW5nZS4gMjAlIG9mIGV2ZW50IHJhbmdlIG9uIGJvdGggc2lkZXMuXG4gICAgICBjb25zdCBkdXJhdGlvbiA9IChlbmRUaW1lIC0gc3RhcnRUaW1lKTtcbiAgICAgIGNvbnN0IHByZWNlZGluZ1RpbWVzdGFtcCA9IHN0YXJ0VGltZSAtIChkdXJhdGlvbiAqIDE1LjApO1xuICAgICAgY29uc3QgcHJvY2VlZGluZ1RpbWVzdGFtcCA9IGVuZFRpbWUgKyAoZHVyYXRpb24gKiAxNS4wKTtcblxuICAgICAgY29uc3QgcHJlY2VkaW5nTWVhc3VyZW1lbnRzID0gTWVhc3VyZW1lbnRzLmZpbmQoe1xuICAgICAgICBib3hfaWQsXG4gICAgICAgIHRpbWVzdGFtcF9tczogeyAkZ3RlOiBwcmVjZWRpbmdUaW1lc3RhbXAsICRsdGU6IGZpcnN0TWVhc3VyZW1lbnRUaW1lc3RhbXAgfSxcbiAgICAgIH0sIHt9KS5mZXRjaCgpO1xuXG4gICAgICBjb25zdCBwcm9jZWVkaW5nTWVhc3VyZW1lbnRzID0gTWVhc3VyZW1lbnRzLmZpbmQoe1xuICAgICAgICBib3hfaWQsXG4gICAgICAgIHRpbWVzdGFtcF9tczogeyAkZ3RlOiBsYXN0TWVhc3VyZW1lbnRUaW1lc3RhbXAsICRsdGU6IHByb2NlZWRpbmdUaW1lc3RhbXAgfSxcbiAgICAgIH0sIHt9KS5mZXRjaCgpO1xuXG4gICAgICByZXR1cm4geyBldmVudE1lYXN1cmVtZW50cywgcHJlY2VkaW5nTWVhc3VyZW1lbnRzLCBwcm9jZWVkaW5nTWVhc3VyZW1lbnRzIH07XG4gICAgfVxuICAgIHJldHVybiBudWxsO1xuICB9LFxufSk7XG5cbmV4cG9ydCBjb25zdCBkeWdyYXBoTWVyZ2VEYXRhc2V0cyA9ICh4RmllbGROYW1lLCB5RmllbGROYW1lLCAuLi5kYXRhc2V0cykgPT4ge1xuICBjb25zdCBtZXJnZWREYXRhID0gbmV3IE1hcCgpO1xuICBjb25zdCBudW1EYXRhc2V0cyA9IGRhdGFzZXRzLmxlbmd0aDtcblxuICBkYXRhc2V0cy5mb3JFYWNoKChkYXRhc2V0LCBpbmRleCkgPT4ge1xuICAgIC8vIER5Z3JhcGggcmVxdWlyZXMgYSBkYXRhIGZvcm1hdCBvZjpcbiAgICAvLyBbXG4gICAgLy8gIFt4MSwgeTEsIHkyLCB5MywgLi4uXSxcbiAgICAvLyAgW3gyLCB5MSwgeTIsIHkzLCAuLi5dXG4gICAgLy8gXVxuICAgIC8vIFdoZXJlIHggaXMgdGhlIGluZGVwZW5kZW50IHZhcmlhYmxlIGFuZCB5IGlzIHRoZSBkZXBlbmRhbnQgdmFyaWFibGUuIEFzIHN1Y2gsIHRoZSB5MSBjb2x1bW4gcmVwcmVzZW50cyBhIGRhdGFzZXQsXG4gICAgLy8gdGhlIHkyIGNvbHVtbiByZXByZXNlbnRzIGFub3RoZXIgZGF0YXNldCwgYW5kIHRoZSB5MyBjb2x1bW4gcmVwcmVzZW50cyB0aGUgZmluYWwgZGF0YXNldC4gRHlncmFwaCB3aWxsIGV4cGVjdFxuICAgIC8vIG51bGwgd2hlbiB0aGVyZSBpcyBubyB2YWx1ZSBmb3IgYSBnaXZlbiBkYXRhc2V0LlxuICAgIC8vXG4gICAgLy8gQXMgc3VjaCwgd2hlbiBpdGVyYXRpbmcgdGhyb3VnaCBvdXIgZGF0YXNldHMsIHdlIG5lZWQgdG8gaW5zZXJ0IGRhdGEgYXQgYXBwcm9wcmlhdGUgaW5kZXggb2YgYXJyYXksIGFuZCBzbyB3ZVxuICAgIC8vIG11c3Qga2VlcCB0cmFjayBvZiBjb3JyZWN0IGluZGV4IHRvIHdyaXRlIGludG8uXG4gICAgY29uc3Qgd3JpdGVJbmRleCA9IGluZGV4O1xuICAgIGRhdGFzZXQuZm9yRWFjaChkYXRhID0+IHtcbiAgICAgIGNvbnN0IHggPSBkYXRhW3hGaWVsZE5hbWVdO1xuICAgICAgY29uc3QgeSA9IGRhdGFbeUZpZWxkTmFtZV07XG5cbiAgICAgIGlmIChtZXJnZWREYXRhLmhhcyh4KSkge1xuICAgICAgICAvLyBHZXQgdGhlIGFycmF5IGFuZCB1cGRhdGUgYXQgYXBwcm9wcmlhdGUgaW5kZXguXG4gICAgICAgIGNvbnN0IGFyciA9IG1lcmdlZERhdGEuZ2V0KHgpO1xuICAgICAgICBhcnJbd3JpdGVJbmRleF0gPSB5O1xuICAgICAgICBtZXJnZWREYXRhLnNldCh4LCBhcnIpO1xuICAgICAgfSBlbHNlIHtcbiAgICAgICAgLy8gQ3JlYXRlIGEgbnVsbCBmaWxsZWQgYXJyYXkgb2YgbGVuZ3RoIGVxdWFsIHRvIG51bWJlciBvZiBkYXRhc2V0cy5cbiAgICAgICAgY29uc3QgbmV3QXJyID0gbmV3IEFycmF5KG51bURhdGFzZXRzKS5maWxsKG51bGwpO1xuICAgICAgICBuZXdBcnJbd3JpdGVJbmRleF0gPSB5OyAvLyBTZXQgdGhlIHkgdmFsdWUgYXQgdGhlIHByb3BlciBpbmRleC5cbiAgICAgICAgbWVyZ2VkRGF0YS5zZXQoeCwgbmV3QXJyKTtcbiAgICAgIH1cbiAgICB9KTtcbiAgfSk7XG5cbiAgY29uc3QgbWVyZ2VkRGF0YXNldCA9IEFycmF5LmZyb20obWVyZ2VkRGF0YS5rZXlzKCkpLm1hcChrZXkgPT4gW2tleSwgLi4ubWVyZ2VkRGF0YS5nZXQoa2V5KV0pO1xuXG4gIC8vIFNvcnQgYnkgdGhlIGluZGVwZW5kZW50IHZhcmlhYmxlLCB3aGljaCBpcyB0aGUgMHRoIGluZGV4IG9mIGVhY2ggYXJyYXkuXG4gIG1lcmdlZERhdGFzZXQuc29ydCgoYSwgYikgPT4gYVswXSAtIGJbMF0pO1xuXG4gIHJldHVybiBtZXJnZWREYXRhc2V0O1xufTtcbiIsImltcG9ydCAnLi9NZWFzdXJlbWVudHNDb2xsZWN0aW9uLmpzJztcbmltcG9ydCAnLi9NZWFzdXJlbWVudHNDb2xsZWN0aW9uTWV0aG9kcy5qcyc7XG4iLCJpbXBvcnQgU2ltcGxlU2NoZW1hIGZyb20gJ3NpbXBsLXNjaGVtYSc7XG5pbXBvcnQgeyBNZXRlb3IgfSBmcm9tICdtZXRlb3IvbWV0ZW9yJztcbmltcG9ydCBNb21lbnQgZnJvbSAnbW9tZW50JztcbmltcG9ydCBCYXNlQ29sbGVjdGlvbiBmcm9tICcuLi9iYXNlL0Jhc2VDb2xsZWN0aW9uLmpzJztcbmltcG9ydCB7IHByb2dyZXNzQmFyU2V0dXAgfSBmcm9tICcuLi8uLi9tb2R1bGVzL3V0aWxzJztcblxuXG4vKipcbiAqIENvbGxlY3Rpb24gY2xhc3MgZm9yIHRoZSBvcHFfYm94ZXMgY29sbGVjdGlvbi5cbiAqIERvY3M6IGh0dHBzOi8vb3Blbi1wb3dlci1xdWFsaXR5LmdpdGJvb2tzLmlvL29wZW4tcG93ZXItcXVhbGl0eS1tYW51YWwvY29udGVudC9kYXRhbW9kZWwvZGVzY3JpcHRpb24uaHRtbCNvcHFfYm94ZXNcbiAqL1xuY2xhc3MgT3BxQm94ZXNDb2xsZWN0aW9uIGV4dGVuZHMgQmFzZUNvbGxlY3Rpb24ge1xuXG4gIC8qKlxuICAgKiBDcmVhdGVzIHRoZSBjb2xsZWN0aW9uLlxuICAgKi9cbiAgY29uc3RydWN0b3IoKSB7XG4gICAgc3VwZXIoJ29wcV9ib3hlcycsIG5ldyBTaW1wbGVTY2hlbWEoe1xuICAgICAgYm94X2lkOiBTdHJpbmcsXG4gICAgICBuYW1lOiB7IHR5cGU6IFN0cmluZywgb3B0aW9uYWw6IHRydWUgfSxcbiAgICAgIGRlc2NyaXB0aW9uOiB7IHR5cGU6IFN0cmluZywgb3B0aW9uYWw6IHRydWUgfSxcbiAgICAgIHVucGx1Z2dlZDogeyB0eXBlOiBCb29sZWFuLCBvcHRpb25hbDogdHJ1ZSB9LFxuICAgICAgY2FsaWJyYXRpb25fY29uc3RhbnQ6IE51bWJlcixcbiAgICAgIGxvY2F0aW9uczogeyB0eXBlOiBBcnJheSB9LFxuICAgICAgJ2xvY2F0aW9ucy4kJzogeyB0eXBlOiBPYmplY3QsIGJsYWNrYm94OiB0cnVlIH0sXG4gICAgfSkpO1xuICB9XG5cbiAgLyoqXG4gICAqIERlZmluZXMgYSBuZXcgT3BxQm94IGRvY3VtZW50LlxuICAgKiBPbmx5IHdvcmtzIG9uIHNlcnZlciBzaWRlLlxuICAgKiBVcGRhdGVzIGluZm8gYXNzb2NpYXRlZCB3aXRoIGJveF9pZCBpZiBpdCBpcyBhbHJlYWR5IGRlZmluZWQuXG4gICAqIEBwYXJhbSB7U3RyaW5nfSBib3hfaWQgLSBUaGUgdW5pcXVlIGlkZW50aWZpY2F0aW9uIHZhbHVlIG9mIHRoZSBPUFFCb3guXG4gICAqIEBwYXJhbSB7U3RyaW5nfSBuYW1lIC0gVGhlIHVuaXF1ZSB1c2VyLWZyaWVuZGx5IG5hbWUgb2YgdGhlIE9QUUJveC5cbiAgICogQHBhcmFtIHtTdHJpbmd9IGRlc2NyaXB0aW9uIC0gVGhlIChvcHRpb25hbCkgZGVzY3JpcHRpb24gb2YgdGhlIE9QUUJveC5cbiAgICogQHBhcmFtIHtCb29sZWFufSB1bnBsdWdnZWQgLSBUcnVlIGlmIHRoZSBib3ggaXMgbm90IGF0dGFjaGVkIHRvIGFuIG91dGxldC4gRGVmYXVsdDogZmFsc2UgKHBsdWdnZWQgaW4pXG4gICAqIEBwYXJhbSB7TnVtYmVyfSBjYWxpYnJhdGlvbl9jb25zdGFudCAtIFRoZSBjYWxpYnJhdGlvbiBjb25zdGFudCB2YWx1ZSBvZiB0aGUgYm94LiBTZWUgZG9jcyBmb3IgZGV0YWlscy5cbiAgICogQHBhcmFtIHtbT2JqZWN0XX0gbG9jYXRpb25zIC0gVGhlIGhpc3Rvcnkgb2YgbG9jYXRpb25zIG9mIHRoZSBPUFFCb3guXG4gICAqIEByZXR1cm5zIFRoZSBkb2NJRCBvZiB0aGUgbmV3IG9yIGNoYW5nZWQgT1BRQm94IGRvY3VtZW50LCBvciB1bmRlZmluZWQgaWYgaW52b2tlZCBvbiB0aGUgY2xpZW50IHNpZGUuXG4gICAqL1xuICBkZWZpbmUoeyBib3hfaWQsIG5hbWUsIGRlc2NyaXB0aW9uLCBjYWxpYnJhdGlvbl9jb25zdGFudCwgbG9jYXRpb25zLCB1bnBsdWdnZWQgPSBmYWxzZSB9KSB7XG4gICAgaWYgKE1ldGVvci5pc1NlcnZlcikge1xuICAgICAgLy8gQ3JlYXRlIG9yIG1vZGlmeSB0aGUgT3BxQm94IGRvY3VtZW50IGFzc29jaWF0ZWQgd2l0aCB0aGlzIGJveF9pZC5cbiAgICAgIGNvbnN0IG5ld0xvY3MgPSB0aGlzLm1ha2VMb2NhdGlvbkFycmF5KGxvY2F0aW9ucyk7XG4gICAgICB0aGlzLl9jb2xsZWN0aW9uLnVwc2VydChcbiAgICAgICAgeyBib3hfaWQgfSxcbiAgICAgICAgeyAkc2V0OiB7IG5hbWUsIGRlc2NyaXB0aW9uLCBjYWxpYnJhdGlvbl9jb25zdGFudCwgbG9jYXRpb25zOiBuZXdMb2NzLCB1bnBsdWdnZWQgfSB9LFxuICAgICAgICApO1xuICAgICAgY29uc3QgZG9jSUQgPSB0aGlzLmZpbmRPbmUoeyBib3hfaWQgfSkuX2lkO1xuICAgICAgcmV0dXJuIGRvY0lEO1xuICAgIH1cbiAgICByZXR1cm4gdW5kZWZpbmVkO1xuICB9XG5cbiAgLyoqXG4gICAqIFJldHVybnMgYSBuZXcgbG9jYXRpb25zIGFycmF5IHN0cnVjdHVyZSB3aGVyZSB0aW1lX3N0YW1wX21zIGhhcyBiZWVuIHBhc3NlZCB0aHJvdWdoIE1vbWVudCBzbyB0aGF0XG4gICAqIHRoZSBzZXR0aW5ncyBmaWxlIGNhbiBwcm92aWRlIG1vcmUgdXNlci1mcmllbmRseSB2ZXJzaW9ucyBvZiB0aGUgdGltZXN0YW1wLlxuICAgKiBAcGFyYW0gbG9jYXRpb25zIFRoZSBsb2NhdGlvbnMgYXJyYXkuXG4gICAqIEByZXR1cm5zIEEgbmV3IGxvY2F0aW9ucyBhcnJheSBpbiB3aGljaCB0aW1lX3N0YW1wX21zIGhhcyBiZWVuIGNvbnZlcnRlZCB0byBVVEMgbWlsbGlzZWNvbmRzLlxuICAgKi9cbiAgbWFrZUxvY2F0aW9uQXJyYXkobG9jYXRpb25zKSB7XG4gICAgcmV0dXJuIGxvY2F0aW9ucy5tYXAobG9jYXRpb24gPT4ge1xuICAgICAgY29uc3QgbW9tZW50VGltZXN0YW1wID0gTW9tZW50KGxvY2F0aW9uLnRpbWVfc3RhbXBfbXMpO1xuICAgICAgaWYgKG1vbWVudFRpbWVzdGFtcC5pc1ZhbGlkKCkpIHtcbiAgICAgICAgbG9jYXRpb24udGltZV9zdGFtcF9tcyA9IG1vbWVudFRpbWVzdGFtcC52YWx1ZU9mKCk7IC8vIGVzbGludC1kaXNhYmxlLWxpbmVcbiAgICAgIH1cbiAgICAgIHJldHVybiBsb2NhdGlvbjtcbiAgICB9KTtcbiAgfVxuXG4gIC8qKlxuICAgKiBSZXR1cm5zIHRoZSBib3ggZG9jdW1lbnQgYXNzb2NpYXRlZCB3aXRoIGJveF9pZC5cbiAgICogVGhyb3dzIGFuIGVycm9yIGlmIG5vIGJveCBkb2N1bWVudCB3YXMgZm91bmQgZm9yIHRoZSBwYXNzZWQgYm94X2lkLlxuICAgKiBAcGFyYW0gYm94X2lkIFRoZSBib3ggSUQuXG4gICAqIEByZXR1cm5zIHthbnl9IFRoZSBib3ggZG9jdW1lbnQuXG4gICAqL1xuICBmaW5kQm94KGJveF9pZCkge1xuICAgIGNvbnN0IGJveERvYyA9IHRoaXMuX2NvbGxlY3Rpb24uZmluZE9uZSh7IGJveF9pZCB9KTtcbiAgICBpZiAoYm94RG9jKSB7XG4gICAgICByZXR1cm4gYm94RG9jO1xuICAgIH1cbiAgICB0aHJvdyBuZXcgTWV0ZW9yLkVycm9yKGBObyBib3ggZm91bmQgd2l0aCBpZDogJHtib3hfaWR9YCk7XG4gIH1cblxuICAvKipcbiAgICogUmV0dXJucyB0aGUgYm94SURzIG9mIGFsbCBib3hlcyBpbiB0aGUgY29sbGVjdGlvbi5cbiAgICogQHJldHVybiB7IEFycmF5IH0gQW4gYXJyYXkgb2YgYm94SWRzLlxuICAgKi9cbiAgZmluZEJveElkcygpIHtcbiAgICBjb25zdCBkb2NzID0gdGhpcy5fY29sbGVjdGlvbi5maW5kKHt9KS5mZXRjaCgpO1xuICAgIHJldHVybiAoZG9jcykgPyBfLm1hcChkb2NzLCBkb2MgPT4gZG9jLmJveF9pZCkgOiBbXTtcbiAgfVxuXG4gIC8qKlxuICAgKiBSZXR1cm5zIGFuIG9iamVjdCByZXByZXNlbnRpbmcgYSBzaW5nbGUgT3BxQm94LlxuICAgKiBAcGFyYW0ge09iamVjdH0gZG9jSUQgLSBUaGUgTW9uZ28uT2JqZWN0SUQgb2YgdGhlIE9wcUJveC5cbiAgICogQHJldHVybnMge09iamVjdH0gLSBBbiBvYmplY3QgcmVwcmVzZW50aW5nIGEgc2luZ2xlIE9wcUJveC5cbiAgICovXG4gIGR1bXBPbmUoZG9jSUQpIHtcbiAgICAvKiBlc2xpbnQtZGlzYWJsZSBjYW1lbGNhc2UgKi9cbiAgICBjb25zdCBkb2MgPSB0aGlzLmZpbmREb2MoZG9jSUQpO1xuICAgIGNvbnN0IGJveF9pZCA9IGRvYy5ib3hfaWQ7XG4gICAgY29uc3QgbmFtZSA9IGRvYy5uYW1lO1xuICAgIGNvbnN0IGRlc2NyaXB0aW9uID0gZG9jLmRlc2NyaXB0aW9uO1xuICAgIGNvbnN0IGNhbGlicmF0aW9uX2NvbnN0YW50ID0gZG9jLmNhbGlicmF0aW9uX2NvbnN0YW50O1xuICAgIGNvbnN0IGxvY2F0aW9ucyA9IGRvYy5sb2NhdGlvbnM7XG5cbiAgICByZXR1cm4geyBib3hfaWQsIG5hbWUsIGRlc2NyaXB0aW9uLCBjYWxpYnJhdGlvbl9jb25zdGFudCwgbG9jYXRpb25zIH07XG4gICAgLyogZXNsaW50LWVuYWJsZSBjYW1lbGNhc2UgKi9cbiAgfVxuXG4gIGNoZWNrSW50ZWdyaXR5KCkge1xuICAgIGNvbnN0IHByb2JsZW1zID0gW107XG4gICAgY29uc3QgdG90YWxDb3VudCA9IHRoaXMuY291bnQoKTtcbiAgICBjb25zdCB2YWxpZGF0aW9uQ29udGV4dCA9IHRoaXMuZ2V0U2NoZW1hKCkubmFtZWRDb250ZXh0KCdvcHFCb3hlc0ludGVncml0eScpO1xuICAgIGNvbnN0IHBiID0gcHJvZ3Jlc3NCYXJTZXR1cCh0b3RhbENvdW50LCAyMDAwLCBgQ2hlY2tpbmcgJHt0aGlzLl9jb2xsZWN0aW9uTmFtZX0gY29sbGVjdGlvbjogYCk7XG5cbiAgICB0aGlzLmZpbmQoKS5mb3JFYWNoKChkb2MsIGluZGV4KSA9PiB7XG4gICAgICBwYi51cGRhdGVCYXIoaW5kZXgpOyAvLyBVcGRhdGUgcHJvZ3Jlc3MgYmFyLlxuXG4gICAgICAvLyBWYWxpZGF0ZSBlYWNoIGRvY3VtZW50IGFnYWluc3QgdGhlIGNvbGxlY3Rpb24gc2NoZW1hLlxuICAgICAgdmFsaWRhdGlvbkNvbnRleHQudmFsaWRhdGUoZG9jKTtcbiAgICAgIGlmICghdmFsaWRhdGlvbkNvbnRleHQuaXNWYWxpZCgpKSB7XG4gICAgICAgIC8vIGVzbGludC1kaXNhYmxlLW5leHQtbGluZSBtYXgtbGVuXG4gICAgICAgIHByb2JsZW1zLnB1c2goYE9wcUJveCBkb2N1bWVudCBmYWlsZWQgc2NoZW1hIHZhbGlkYXRpb246ICR7ZG9jLl9pZH0gKEludmFsaWQga2V5czogJHtKU09OLnN0cmluZ2lmeSh2YWxpZGF0aW9uQ29udGV4dC5pbnZhbGlkS2V5cygpLCBudWxsLCAyKX0pYCk7XG4gICAgICB9XG4gICAgICB2YWxpZGF0aW9uQ29udGV4dC5yZXNldFZhbGlkYXRpb24oKTtcblxuICAgICAgLy8gRW5zdXJlIGJveF9pZCBmaWVsZCBpcyB1bmlxdWVcbiAgICAgIGlmICh0aGlzLmZpbmQoeyBib3hfaWQ6IGRvYy5ib3hfaWQgfSkuY291bnQoKSA+IDEpIHByb2JsZW1zLnB1c2goYE9wcUJveCBib3hfaWQgaXMgbm90IHVuaXF1ZTogJHtkb2MuYm94X2lkfWApO1xuXG4gICAgICAvLyBFbnN1cmUgbmFtZSBmaWVsZCBpcyB1bmlxdWUgKG5vdCBjb3VudGluZyBhbiB1bnNldCBuYW1lIC0gcmVwcmVzZW50ZWQgYnkgZW1wdHkgc3RyaW5ncylcbiAgICAgIC8vIGVzbGludC1kaXNhYmxlLW5leHQtbGluZSBtYXgtbGVuXG4gICAgICBpZiAoZG9jLm5hbWUgJiYgdGhpcy5maW5kKHsgbmFtZTogZG9jLm5hbWUgfSkuY291bnQoKSA+IDEpIHByb2JsZW1zLnB1c2goYE9wcUJveCBuYW1lIGlzIG5vdCB1bmlxdWU6ICR7ZG9jLm5hbWV9YCk7XG4gICAgfSk7XG5cbiAgICBwYi5jbGVhckludGVydmFsKCk7XG4gICAgcmV0dXJuIHByb2JsZW1zO1xuICB9XG59XG5cbi8qKlxuICogUHJvdmlkZXMgdGhlIHNpbmdsZXRvbiBpbnN0YW5jZSBvZiB0aGlzIGNsYXNzLlxuICogQHR5cGUge09wcUJveGVzQ29sbGVjdGlvbn1cbiAqL1xuZXhwb3J0IGNvbnN0IE9wcUJveGVzID0gbmV3IE9wcUJveGVzQ29sbGVjdGlvbigpO1xuIiwiaW1wb3J0IHsgVmFsaWRhdGVkTWV0aG9kIH0gZnJvbSAnbWV0ZW9yL21kZzp2YWxpZGF0ZWQtbWV0aG9kJztcbmltcG9ydCBTaW1wbGVTY2hlbWEgZnJvbSAnc2ltcGwtc2NoZW1hJztcbmltcG9ydCB7IE9wcUJveGVzIH0gZnJvbSAnLi9PcHFCb3hlc0NvbGxlY3Rpb24nO1xuXG5leHBvcnQgY29uc3QgdG90YWxPcHFCb3hlc0NvdW50ID0gbmV3IFZhbGlkYXRlZE1ldGhvZCh7XG4gIG5hbWU6ICdPcHFCb3hlcy50b3RhbE9wcUJveGVzQ291bnQnLFxuICB2YWxpZGF0ZTogbmV3IFNpbXBsZVNjaGVtYSgpLnZhbGlkYXRvcih7IGNsZWFuOiB0cnVlIH0pLFxuICBydW4oKSB7XG4gICAgcmV0dXJuIE9wcUJveGVzLmZpbmQoe30pLmNvdW50KCk7XG4gIH0sXG59KTtcblxuZXhwb3J0IGNvbnN0IGdldEJveENhbGlicmF0aW9uQ29uc3RhbnQgPSBuZXcgVmFsaWRhdGVkTWV0aG9kKHtcbiAgbmFtZTogJ09wcUJveGVzLmdldEJveENhbGlicmF0aW9uQ29uc3RhbnQnLFxuICB2YWxpZGF0ZTogbmV3IFNpbXBsZVNjaGVtYSh7XG4gICAgYm94X2lkOiB7IHR5cGU6IFN0cmluZyB9LFxuICB9KS52YWxpZGF0b3IoeyBjbGVhbjogdHJ1ZSB9KSxcbiAgcnVuKHsgYm94X2lkIH0pIHtcbiAgICBpZiAoIXRoaXMuaXNTaW11bGF0aW9uKSB7XG4gICAgICBjb25zdCBvcHFCb3ggPSBPcHFCb3hlcy5maW5kT25lKHsgYm94X2lkIH0pO1xuICAgICAgcmV0dXJuIChvcHFCb3gpID8gb3BxQm94LmNhbGlicmF0aW9uX2NvbnN0YW50IDogbnVsbDtcbiAgICB9XG4gICAgcmV0dXJuIG51bGw7XG4gIH0sXG59KTtcblxuZXhwb3J0IGNvbnN0IGdldEJveElEcyA9IG5ldyBWYWxpZGF0ZWRNZXRob2Qoe1xuICBuYW1lOiAnT3BxQm94ZXMuZ2V0Qm94SURzJyxcbiAgdmFsaWRhdGU6IG5ldyBTaW1wbGVTY2hlbWEoe30pLnZhbGlkYXRvcih7IGNsZWFuOiB0cnVlIH0pLFxuICBydW4oKSB7XG4gICAgaWYgKCF0aGlzLmlzU2ltdWxhdGlvbikge1xuICAgICAgY29uc3Qgb3BxQm94ZXMgPSBPcHFCb3hlcy5maW5kKHt9KTtcbiAgICAgIGNvbnN0IGJveElEcyA9IG9wcUJveGVzLm1hcChib3ggPT4gYm94LmJveF9pZCk7XG4gICAgICByZXR1cm4gYm94SURzO1xuICAgIH1cbiAgICByZXR1cm4gbnVsbDtcbiAgfSxcbn0pO1xuIiwiaW1wb3J0ICcuL09wcUJveGVzQ29sbGVjdGlvbi5qcyc7XG5pbXBvcnQgJy4vT3BxQm94ZXNDb2xsZWN0aW9uTWV0aG9kcy5qcyc7XG4iLCJpbXBvcnQgU2ltcGxlU2NoZW1hIGZyb20gJ3NpbXBsLXNjaGVtYSc7XG5pbXBvcnQgQmFzZUNvbGxlY3Rpb24gZnJvbSAnLi4vYmFzZS9CYXNlQ29sbGVjdGlvbi5qcyc7XG5pbXBvcnQgeyBFdmVudHMgfSBmcm9tICcuLi9ldmVudHMvRXZlbnRzQ29sbGVjdGlvbi5qcyc7XG5pbXBvcnQgeyBCb3hFdmVudHMgfSBmcm9tICcuLi9ib3gtZXZlbnRzL0JveEV2ZW50c0NvbGxlY3Rpb24uanMnO1xuaW1wb3J0IHsgTWVhc3VyZW1lbnRzIH0gZnJvbSAnLi4vbWVhc3VyZW1lbnRzL01lYXN1cmVtZW50c0NvbGxlY3Rpb24uanMnO1xuaW1wb3J0IHsgT3BxQm94ZXMgfSBmcm9tICcuLi9vcHEtYm94ZXMvT3BxQm94ZXNDb2xsZWN0aW9uLmpzJztcbmltcG9ydCB7IFRyZW5kcyB9IGZyb20gJy4uL3RyZW5kcy9UcmVuZHNDb2xsZWN0aW9uLmpzJztcbmltcG9ydCB7IFVzZXJQcm9maWxlcyB9IGZyb20gJy4uL3VzZXJzL1VzZXJQcm9maWxlc0NvbGxlY3Rpb24uanMnO1xuXG4vKiBlc2xpbnQtZGlzYWJsZSBpbmRlbnQgKi9cblxuY2xhc3MgU3lzdGVtU3RhdHNDb2xsZWN0aW9uIGV4dGVuZHMgQmFzZUNvbGxlY3Rpb24ge1xuXG4gIC8qKlxuICAgKiBDcmVhdGVzIHRoZSBTeXN0ZW0gU3RhdHMgY29sbGVjdGlvbi5cbiAgICovXG4gIGNvbnN0cnVjdG9yKCkge1xuICAgIHN1cGVyKCdzeXN0ZW1fc3RhdHMnLCBuZXcgU2ltcGxlU2NoZW1hKHtcbiAgICAgIGV2ZW50c19jb3VudDogTnVtYmVyLFxuICAgICAgZXZlbnRzX2NvdW50X3RvZGF5OiBOdW1iZXIsXG4gICAgICBib3hfZXZlbnRzX2NvdW50OiBOdW1iZXIsXG4gICAgICBib3hfZXZlbnRzX2NvdW50X3RvZGF5OiBOdW1iZXIsXG4gICAgICBtZWFzdXJlbWVudHNfY291bnQ6IE51bWJlcixcbiAgICAgIG1lYXN1cmVtZW50c19jb3VudF90b2RheTogTnVtYmVyLFxuICAgICAgdHJlbmRzX2NvdW50OiBOdW1iZXIsXG4gICAgICB0cmVuZHNfY291bnRfdG9kYXk6IE51bWJlcixcbiAgICAgIG9wcV9ib3hlc19jb3VudDogTnVtYmVyLFxuICAgICAgdXNlcnNfY291bnQ6IE51bWJlcixcbiAgICAgIHRpbWVzdGFtcDogRGF0ZSxcbiAgICAgIGJveF90cmVuZF9zdGF0czogeyB0eXBlOiBBcnJheSB9LFxuICAgICAgJ2JveF90cmVuZF9zdGF0cy4kJzogeyB0eXBlOiBPYmplY3QsIGJsYWNrYm94OiB0cnVlIH0sXG4gICAgICBoZWFsdGg6IHsgdHlwZTogQXJyYXkgfSxcbiAgICAgICdoZWFsdGguJCc6IHsgdHlwZTogT2JqZWN0LCBibGFja2JveDogdHJ1ZSB9LFxuICAgIH0pKTtcbiAgfVxuXG4gIC8qKlxuICAgKiBEZWZpbmVzIGEgbmV3IFN5c3RlbVN0YXRzIGRvY3VtZW50LlxuICAgKiBAcGFyYW0ge051bWJlcn0gZXZlbnRzX2NvdW50IC0gVGhlIHRvdGFsIG51bWJlciBvZiBFdmVudHMgZG9jdW1lbnRzLlxuICAgKiBAcGFyYW0ge051bWJlcn0gZXZlbnRzX2NvdW50X3RvZGF5IC0gVGhlIHRvdGFsIG51bWJlciBvZiBFdmVudHMgZG9jdW1lbnRzIHRvZGF5LlxuICAgKiBAcGFyYW0ge051bWJlcn0gYm94X2V2ZW50c19jb3VudCAtIFRoZSB0b3RhbCBudW1iZXIgb2YgQm94RXZlbnRzIGRvY3VtZW50cy5cbiAgICogQHBhcmFtIHtOdW1iZXJ9IGJveF9ldmVudHNfY291bnRfdG9kYXkgLSBUaGUgdG90YWwgbnVtYmVyIG9mIEJveEV2ZW50cyBkb2N1bWVudHMgdG9kYXkuXG4gICAqIEBwYXJhbSB7TnVtYmVyfSBtZWFzdXJlbWVudHNfY291bnQgLSBUaGUgdG90YWwgbnVtYmVyIG9mIE1lYXN1cmVtZW50cyBkb2N1bWVudHMuXG4gICAqIEBwYXJhbSB7TnVtYmVyfSBtZWFzdXJlbWVudHNfY291bnRfdG9kYXkgLSBUaGUgdG90YWwgbnVtYmVyIG9mIE1lYXN1cmVtZW50cyBkb2N1bWVudHMgdG9kYXkuXG4gICAqIEBwYXJhbSB7TnVtYmVyfSBvcHFfYm94ZXNfY291bnQgLSBUaGUgdG90YWwgbnVtYmVyIG9mIE9wcUJveGVzIGRvY3VtZW50cy5cbiAgICogQHBhcmFtIHtOdW1iZXJ9IHRyZW5kc19jb3VudCAtIFRoZSB0b3RhbCBudW1iZXIgb2YgVHJlbmRzIGRvY3VtZW50cy5cbiAgICogQHBhcmFtIHtOdW1iZXJ9IHRyZW5kc19jb3VudF90b2RheSAtIFRoZSB0b3RhbCBudW1iZXIgb2YgVHJlbmRzIGRvY3VtZW50cyB0b2RheS5cbiAgICogQHBhcmFtIHtOdW1iZXJ9IHVzZXJzX2NvdW50IC0gVGhlIHRvdGFsIG51bWJlciBvZiBVc2Vycy5cbiAgICogQHBhcmFtIHtPYmplY3R9IGJveF90cmVuZF9zdGF0cyAtIFN1bW1hcnkgc3RhdHMgb24gdHJlbmRzIGZvciBlYWNoIGJveC5cbiAgICogQHBhcmFtIHtPYmplY3R9IGhlYWx0aCAtIEhlYWx0aCBzdGF0dXMgb2YgYWxsIGJveGVzIGFuZCBzZXJ2aWNlcy5cbiAgICogQHJldHVybnMgVGhlIG5ld2x5IGNyZWF0ZWQgZG9jdW1lbnQgSUQuXG4gICAqL1xuICBkZWZpbmUoeyBldmVudHNfY291bnQsIGV2ZW50c19jb3VudF90b2RheSwgYm94X2V2ZW50c19jb3VudCwgYm94X2V2ZW50c19jb3VudF90b2RheSwgbWVhc3VyZW1lbnRzX2NvdW50LFxuICAgICAgICAgICBtZWFzdXJlbWVudHNfY291bnRfdG9kYXksIG9wcV9ib3hlc19jb3VudCwgdHJlbmRzX2NvdW50LCB0cmVuZHNfY291bnRfdG9kYXksIHVzZXJzX2NvdW50LFxuICAgICAgICAgICBib3hfdHJlbmRfc3RhdHMsIGhlYWx0aCB9KSB7XG4gICAgY29uc3QgZG9jSUQgPSB0aGlzLl9jb2xsZWN0aW9uLmluc2VydCh7IGV2ZW50c19jb3VudCwgYm94X2V2ZW50c19jb3VudCwgbWVhc3VyZW1lbnRzX2NvdW50LCBvcHFfYm94ZXNfY291bnQsXG4gICAgICB0cmVuZHNfY291bnQsIHVzZXJzX2NvdW50LCB0aW1lc3RhbXA6IG5ldyBEYXRlKCksIGJveF90cmVuZF9zdGF0cywgaGVhbHRoLFxuICAgIGV2ZW50c19jb3VudF90b2RheSwgYm94X2V2ZW50c19jb3VudF90b2RheSwgbWVhc3VyZW1lbnRzX2NvdW50X3RvZGF5LCB0cmVuZHNfY291bnRfdG9kYXkgfSk7XG4gICAgcmV0dXJuIGRvY0lEO1xuICB9XG5cbiAgLyoqXG4gICAqIFJldHVybnMgYW4gb2JqZWN0IHJlcHJlc2VudGluZyBhIHNpbmdsZSBTeXN0ZW1TdGF0cy5cbiAgICogQHBhcmFtIHtPYmplY3R9IGRvY0lEIC0gVGhlIE1vbmdvLk9iamVjdElEIG9mIHRoZSBTeXN0ZW1TdGF0LlxuICAgKiBAcmV0dXJucyB7T2JqZWN0fSAtIEFuIG9iamVjdCByZXByZXNlbnRpbmcgYSBzaW5nbGUgU3lzdGVtU3RhdC5cbiAgICovXG4gIGR1bXBPbmUoZG9jSUQpIHtcbiAgICAvKiBlc2xpbnQtZGlzYWJsZSBjYW1lbGNhc2UgKi9cbiAgICBjb25zdCBkb2MgPSB0aGlzLmZpbmREb2MoZG9jSUQpO1xuICAgIGNvbnN0IGV2ZW50c19jb3VudCA9IGRvYy5ldmVudHNfY291bnQ7XG4gICAgY29uc3QgZXZlbnRzX2NvdW50X3RvZGF5ID0gZG9jLmV2ZW50c19jb3VudF90b2RheTtcbiAgICBjb25zdCBib3hfZXZlbnRzX2NvdW50ID0gZG9jLmJveF9ldmVudHNfY291bnQ7XG4gICAgY29uc3QgYm94X2V2ZW50c19jb3VudF90b2RheSA9IGRvYy5ib3hfZXZlbnRzX2NvdW50X3RvZGF5O1xuICAgIGNvbnN0IG1lYXN1cmVtZW50c19jb3VudCA9IGRvYy5tZWFzdXJlbWVudHNfY291bnQ7XG4gICAgY29uc3QgbWVhc3VyZW1lbnRzX2NvdW50X3RvZGF5ID0gZG9jLm1lYXN1cmVtZW50c19jb3VudF90b2RheTtcbiAgICBjb25zdCB0cmVuZHNfY291bnQgPSBkb2MudHJlbmRzX2NvdW50O1xuICAgIGNvbnN0IHRyZW5kc19jb3VudF90b2RheSA9IGRvYy50cmVuZHNfY291bnRfdG9kYXk7XG4gICAgY29uc3Qgb3BxX2JveGVzX2NvdW50ID0gZG9jLm9wcV9ib3hlc19jb3VudDtcbiAgICBjb25zdCB1c2Vyc19jb3VudCA9IGRvYy51c2Vyc19jb3VudDtcbiAgICBjb25zdCB0aW1lc3RhbXAgPSBkb2MudGltZXN0YW1wO1xuICAgIGNvbnN0IGJveF90cmVuZF9zdGF0cyA9IGRvYy5ib3hfdHJlbmRfc3RhdHM7XG4gICAgcmV0dXJuIHsgZXZlbnRzX2NvdW50LCBib3hfZXZlbnRzX2NvdW50LCBtZWFzdXJlbWVudHNfY291bnQsIG9wcV9ib3hlc19jb3VudCwgdHJlbmRzX2NvdW50LCB1c2Vyc19jb3VudCxcbiAgICAgIHRpbWVzdGFtcCwgYm94X3RyZW5kX3N0YXRzLCBldmVudHNfY291bnRfdG9kYXksIGJveF9ldmVudHNfY291bnRfdG9kYXksIG1lYXN1cmVtZW50c19jb3VudF90b2RheSxcbiAgICB0cmVuZHNfY291bnRfdG9kYXkgfTtcbiAgICAvKiBlc2xpbnQtZW5hYmxlIGNhbWVsY2FzZSAqL1xuICB9XG5cbiAgLyoqXG4gICAqIE5vIG5lZWQgdG8gY2hlY2sgaW50ZWdyaXR5IGZvciB0aGlzIGNvbGxlY3Rpb24uXG4gICAqIEByZXR1cm5zIHtBcnJheX1cbiAgICovXG4gIGNoZWNrSW50ZWdyaXR5KCkgeyAvLyBlc2xpbnQtZGlzYWJsZS1saW5lXG4gICAgY29uc3QgcHJvYmxlbXMgPSBbXTtcbiAgICByZXR1cm4gcHJvYmxlbXM7XG4gIH1cblxuICAvKipcbiAgICogUmV0dXJuIGFuIG9iamVjdCB3aXRoIHRoZSBmb2xsb3dpbmcgZmllbGRzOlxuICAgKiBib3hJZDogVGhlIElEIG9mIHRoZSBib3ggYXNzb2NpYXRlZCB3aXRoIHRoaXMgdHJlbmQgZGF0YS5cbiAgICogZmlyc3RUcmVuZDogQSBudW1iZXIgKFVUQyB0aW1lc3RhbXApIG9mIHRoZSBlYXJsaWVzdCB0cmVuZCBkYXRhIGZvciB0aGlzIGJveCwgb3IgMCBpZiBub3QgZm91bmQuXG4gICAqIGxhdGVzdFRyZW5kOiBBIG51bWJlciAoVVRDIHRpbWVzdGFtcCkgb2YgdGhlIGxhdGVzdCB0cmVuZCBkYXRhIGZvciB0aGlzIGJveCwgb3IgMCBpZiBub3QgZm91bmQuXG4gICAqIHRvdGFsVHJlbmRzOiBBIE51bWJlciBpbmRpY2F0aW5nIHRoZSB0b3RhbCBudW1iZXIgb2YgdHJlbmRzLlxuICAgKiBAcGFyYW0gYm94SWQgVGhlIGJveCBJRC5cbiAgICogQHJldHVybnMgQW4gb2JqZWN0IHsgYm94SWQsIGZpcnN0VHJlbmQsIGxhc3RUcmVuZCwgdG90YWxUcmVuZHMgfS5cbiAgICovXG4gIGdldEJveFRyZW5kU3RhdChib3hJZCkgeyAvLyBlc2xpbnQtZGlzYWJsZS1saW5lXG4gICAgY29uc3QgZmlyc3RUcmVuZERvYyA9IFRyZW5kcy5vbGRlc3RUcmVuZChib3hJZCk7XG4gICAgY29uc3QgZmlyc3RUcmVuZCA9IGZpcnN0VHJlbmREb2MgPyBmaXJzdFRyZW5kRG9jLnRpbWVzdGFtcF9tcyA6IDA7XG4gICAgY29uc3QgbGFzdFRyZW5kRG9jID0gVHJlbmRzLm5ld2VzdFRyZW5kKGJveElkKTtcbiAgICBjb25zdCBsYXN0VHJlbmQgPSBsYXN0VHJlbmREb2MgPyBsYXN0VHJlbmREb2MudGltZXN0YW1wX21zIDogMDtcbiAgICBjb25zdCB0b3RhbFRyZW5kcyA9IFRyZW5kcy5jb3VudFRyZW5kcyhib3hJZCk7XG4gICAgcmV0dXJuIHsgYm94SWQsIGZpcnN0VHJlbmQsIGxhc3RUcmVuZCwgdG90YWxUcmVuZHMgfTtcbiAgfVxuXG4gIC8qKlxuICAgKiBDcmVhdGUgYW4gYXJyYXkgb2Ygb2JqZWN0cyB3aXRoIGZpZWxkczogdHlwZSwgbmFtZSwgaWNvbiwgY29sb3JcbiAgICogV2UganVzdCBkaXNwbGF5IGNvbnZlcnQgdGhpcyBhcnJheSB0byBsYWJlbHMgdG8gZGlzcGxheSBoZWFsdGguXG4gICAqL1xuICBnZXRIZWFsdGhBcnJheSgpIHtcbiAgICBjb25zdCBoZWFsdGggPSBbXTtcbiAgICBoZWFsdGgucHVzaCh7IHR5cGU6ICdzZXJ2aWNlJywgaW5kZXg6IDEsIG5hbWU6ICdNYXVrYScsIGljb246ICdjaGVjayBjaXJjbGUnLCBjb2xvcjogJ2dyZWVuJyB9KTtcbiAgICBoZWFsdGgucHVzaCh7IHR5cGU6ICdzZXJ2aWNlJywgaW5kZXg6IDIsIG5hbWU6ICdNYWthaScsIGljb246ICdjaGVjayBjaXJjbGUnLCBjb2xvcjogJ2dyZWVuJyB9KTtcbiAgICBoZWFsdGgucHVzaCh7IHR5cGU6ICdzZXJ2aWNlJywgaW5kZXg6IDMsIG5hbWU6ICdNb25nbycsIGljb246ICdjaGVjayBjaXJjbGUnLCBjb2xvcjogJ2dyZWVuJyB9KTtcbiAgICBoZWFsdGgucHVzaCh7IHR5cGU6ICdzZXJ2aWNlJywgaW5kZXg6IDQsIG5hbWU6ICdIZWFsdGgnLCBpY29uOiAnY2hlY2sgY2lyY2xlJywgY29sb3I6ICdncmVlbicgfSk7XG5cbiAgICBoZWFsdGgucHVzaCh7IHR5cGU6ICdib3gnLCBpbmRleDogMSwgbmFtZTogJ0JveCAwMScsIGljb246ICdjaGVjayBjaXJjbGUnLCBjb2xvcjogJ2dyZWVuJyB9KTtcbiAgICBoZWFsdGgucHVzaCh7IHR5cGU6ICdib3gnLCBpbmRleDogMiwgbmFtZTogJ0JveCAwMicsIGljb246ICdwbHVnJywgY29sb3I6ICdncmV5JyB9KTtcbiAgICBoZWFsdGgucHVzaCh7IHR5cGU6ICdib3gnLCBpbmRleDogMywgbmFtZTogJ0JveCAwMycsIGljb246ICdleGNsYW1hdGlvbiBjaXJjbGUnLCBjb2xvcjogJ3JlZCcgfSk7XG4gICAgaGVhbHRoLnB1c2goeyB0eXBlOiAnYm94JywgaW5kZXg6IDQsIG5hbWU6ICdCb3ggMDQnLCBpY29uOiAnY2hlY2sgY2lyY2xlJywgY29sb3I6ICdncmVlbicgfSk7XG4gICAgaGVhbHRoLnB1c2goeyB0eXBlOiAnYm94JywgaW5kZXg6IDUsIG5hbWU6ICdCb3ggMDUnLCBpY29uOiAnY2hlY2sgY2lyY2xlJywgY29sb3I6ICdncmVlbicgfSk7XG4gICAgcmV0dXJuIGhlYWx0aDtcbiAgfVxuXG4gIHVwZGF0ZUNvdW50cygpIHtcbiAgICAvLyBHZXQgY3VycmVudCBjb2xsZWN0aW9uIGNvdW50c1xuICAgIGNvbnN0IGV2ZW50c19jb3VudCA9IEV2ZW50cy5jb3VudCgpO1xuICAgIGNvbnN0IGV2ZW50c19jb3VudF90b2RheSA9IEV2ZW50cy5jb3VudFRvZGF5KCd0YXJnZXRfZXZlbnRfc3RhcnRfdGltZXN0YW1wX21zJyk7XG4gICAgY29uc3QgYm94X2V2ZW50c19jb3VudCA9IEJveEV2ZW50cy5jb3VudCgpO1xuICAgIGNvbnN0IGJveF9ldmVudHNfY291bnRfdG9kYXkgPSBCb3hFdmVudHMuY291bnRUb2RheSgnZXZlbnRfc3RhcnRfdGltZXN0YW1wX21zJyk7XG4gICAgY29uc3QgbWVhc3VyZW1lbnRzX2NvdW50ID0gTWVhc3VyZW1lbnRzLmNvdW50KCk7XG4gICAgY29uc3QgbWVhc3VyZW1lbnRzX2NvdW50X3RvZGF5ID0gTWVhc3VyZW1lbnRzLmNvdW50VG9kYXkoJ3RpbWVzdGFtcF9tcycpO1xuICAgIGNvbnN0IG9wcV9ib3hlc19jb3VudCA9IE9wcUJveGVzLmNvdW50KCk7XG4gICAgY29uc3QgdHJlbmRzX2NvdW50ID0gVHJlbmRzLmNvdW50KCk7XG4gICAgY29uc3QgdHJlbmRzX2NvdW50X3RvZGF5ID0gVHJlbmRzLmNvdW50VG9kYXkoJ3RpbWVzdGFtcF9tcycpO1xuICAgIGNvbnN0IHVzZXJzX2NvdW50ID0gVXNlclByb2ZpbGVzLmNvdW50KCk7IC8vIE5vdCBhIGJhc2UtY29sbGVjdGlvbiBjbGFzcy5cbiAgICBjb25zdCBib3hfdHJlbmRfc3RhdHMgPSBPcHFCb3hlcy5maW5kQm94SWRzKCkubWFwKGJveElkID0+IHRoaXMuZ2V0Qm94VHJlbmRTdGF0KGJveElkKSk7XG4gICAgY29uc3QgaGVhbHRoID0gdGhpcy5nZXRIZWFsdGhBcnJheSgpO1xuXG4gICAgLy8gRW5zdXJlIHRoZXJlIGlzIG9ubHkgb25lIGRvY3VtZW50IGluIHRoZSBjb2xsZWN0aW9uLiBXZSB3aWxsIG9ubHkgdXBkYXRlIHRoaXMgb25lIGRvY3VtZW50IHdpdGggY3VycmVudCBzdGF0cy5cbiAgICBjb25zdCBjb3VudCA9IHRoaXMuX2NvbGxlY3Rpb24uZmluZCgpLmNvdW50KCk7XG4gICAgaWYgKGNvdW50ID4gMSkge1xuICAgICAgLy8gUmVtb3ZlIGFsbCBkb2N1bWVudHMgYnV0IG9uZSwgd2hpY2ggd2UgY2hvb3NlIGFyYml0cmFyaWx5XG4gICAgICBjb25zdCBkb2MgPSB0aGlzLl9jb2xsZWN0aW9uLmZpbmRPbmUoKTtcbiAgICAgIHRoaXMuX2NvbGxlY3Rpb24ucmVtb3ZlKHsgX2lkOiB7ICRuZTogZG9jLl9pZCB9IH0pO1xuICAgIH0gZWxzZSBpZiAoY291bnQgPCAxKSB7XG4gICAgICAvLyBDcmVhdGUgbmV3IGRvYy4gU2hvdWxkIG9ubHkgdGhlb3JldGljYWxseSBoYXZlIHRvIGJlIGRvbmUgb25jZSwgd2hlbiB3ZSBmaXJzdCBjcmVhdGUgdGhlIGNvbGxlY3Rpb24uXG4gICAgICAvLyBlc2xpbnQtZGlzYWJsZS1uZXh0LWxpbmUgbWF4LWxlblxuICAgICAgcmV0dXJuIHRoaXMuZGVmaW5lKHsgZXZlbnRzX2NvdW50LCBib3hfZXZlbnRzX2NvdW50LCBtZWFzdXJlbWVudHNfY291bnQsIG9wcV9ib3hlc19jb3VudCwgdHJlbmRzX2NvdW50LCB1c2Vyc19jb3VudCwgYm94X3RyZW5kX3N0YXRzLCBoZWFsdGgsIGV2ZW50c19jb3VudF90b2RheSwgYm94X2V2ZW50c19jb3VudF90b2RheSwgbWVhc3VyZW1lbnRzX2NvdW50X3RvZGF5LFxuICAgICAgdHJlbmRzX2NvdW50X3RvZGF5IH0pO1xuICAgIH1cblxuICAgIC8vIFVwZGF0ZSB0aGUgb25lIGRvY3VtZW50IHdpdGggY3VycmVudCBjb2xsZWN0aW9uIGNvdW50cy5cbiAgICBjb25zdCBzeXN0ZW1TdGF0c0RvYyA9IHRoaXMuX2NvbGxlY3Rpb24uZmluZE9uZSgpO1xuICAgIHJldHVybiBzeXN0ZW1TdGF0c0RvYyAmJiB0aGlzLl9jb2xsZWN0aW9uLnVwZGF0ZShzeXN0ZW1TdGF0c0RvYy5faWQsIHtcbiAgICAgICRzZXQ6IHsgZXZlbnRzX2NvdW50LCBib3hfZXZlbnRzX2NvdW50LCBtZWFzdXJlbWVudHNfY291bnQsIG9wcV9ib3hlc19jb3VudCwgdHJlbmRzX2NvdW50LCB1c2Vyc19jb3VudCxcbiAgICAgICAgdGltZXN0YW1wOiBuZXcgRGF0ZSgpLCBib3hfdHJlbmRfc3RhdHMsIGhlYWx0aCwgZXZlbnRzX2NvdW50X3RvZGF5LCBib3hfZXZlbnRzX2NvdW50X3RvZGF5LFxuICAgICAgICBtZWFzdXJlbWVudHNfY291bnRfdG9kYXksIHRyZW5kc19jb3VudF90b2RheSB9LFxuICAgIH0pO1xuICB9XG59XG5cbi8qKlxuICogUHJvdmlkZXMgdGhlIHNpbmdsZXRvbiBpbnN0YW5jZSBvZiB0aGlzIGNsYXNzLlxuICogQHR5cGUge1N5c3RlbVN0YXRzQ29sbGVjdGlvbn1cbiAqL1xuZXhwb3J0IGNvbnN0IFN5c3RlbVN0YXRzID0gbmV3IFN5c3RlbVN0YXRzQ29sbGVjdGlvbigpO1xuIiwiaW1wb3J0IHsgTWV0ZW9yIH0gZnJvbSAnbWV0ZW9yL21ldGVvcic7XG5pbXBvcnQgeyBNb25nbyB9IGZyb20gJ21ldGVvci9tb25nbyc7XG5pbXBvcnQgU2ltcGxlU2NoZW1hIGZyb20gJ3NpbXBsLXNjaGVtYSc7XG5pbXBvcnQgeyBjaGVjayB9IGZyb20gJ21ldGVvci9jaGVjayc7XG5pbXBvcnQgQmFzZUNvbGxlY3Rpb24gZnJvbSAnLi4vYmFzZS9CYXNlQ29sbGVjdGlvbi5qcyc7XG5pbXBvcnQgeyBPcHFCb3hlcyB9IGZyb20gJy4uL29wcS1ib3hlcy9PcHFCb3hlc0NvbGxlY3Rpb24nO1xuaW1wb3J0IHsgcHJvZ3Jlc3NCYXJTZXR1cCB9IGZyb20gJy4uLy4uL21vZHVsZXMvdXRpbHMnO1xuXG5jbGFzcyBUcmVuZHNDb2xsZWN0aW9uIGV4dGVuZHMgQmFzZUNvbGxlY3Rpb24ge1xuXG4gIC8qKlxuICAgKiBDcmVhdGVzIHRoZSBUcmVuZHMgY29sbGVjdGlvbi5cbiAgICovXG4gIGNvbnN0cnVjdG9yKCkge1xuICAgIHN1cGVyKCd0cmVuZHMnLCBuZXcgU2ltcGxlU2NoZW1hKHtcbiAgICAgIF9pZDogeyB0eXBlOiBNb25nby5PYmplY3RJRCB9LFxuICAgICAgYm94X2lkOiB7IHR5cGU6IFN0cmluZyB9LFxuICAgICAgdGltZXN0YW1wX21zOiB7IHR5cGU6IE51bWJlciB9LFxuICAgICAgdm9sdGFnZTogeyB0eXBlOiBPYmplY3QgfSxcbiAgICAgICd2b2x0YWdlLm1pbic6IHsgdHlwZTogTnVtYmVyIH0sXG4gICAgICAndm9sdGFnZS5tYXgnOiB7IHR5cGU6IE51bWJlciB9LFxuICAgICAgJ3ZvbHRhZ2UuYXZlcmFnZSc6IHsgdHlwZTogTnVtYmVyIH0sXG4gICAgICBmcmVxdWVuY3k6IHsgdHlwZTogT2JqZWN0IH0sXG4gICAgICAnZnJlcXVlbmN5Lm1pbic6IHsgdHlwZTogTnVtYmVyIH0sXG4gICAgICAnZnJlcXVlbmN5Lm1heCc6IHsgdHlwZTogTnVtYmVyIH0sXG4gICAgICAnZnJlcXVlbmN5LmF2ZXJhZ2UnOiB7IHR5cGU6IE51bWJlciB9LFxuICAgICAgdGhkOiB7IHR5cGU6IE9iamVjdCwgb3B0aW9uYWw6IHRydWUgfSxcbiAgICAgICd0aGQubWluJzogeyB0eXBlOiBOdW1iZXIgfSxcbiAgICAgICd0aGQubWF4JzogeyB0eXBlOiBOdW1iZXIgfSxcbiAgICAgICd0aGQuYXZlcmFnZSc6IHsgdHlwZTogTnVtYmVyIH0sXG4gICAgfSkpO1xuXG4gICAgdGhpcy5wdWJsaWNhdGlvbk5hbWVzID0ge1xuICAgICAgR0VUX1JFQ0VOVF9UUkVORFM6ICdnZXRfcmVjZW50X3RyZW5kcycsXG4gICAgICBUUkVORFNfUkVDRU5UX01PTlRIOiAndHJlbmRzX3JlY2VudF9tb250aCcsXG4gICAgfTtcbiAgICBpZiAoTWV0ZW9yLnNlcnZlcikge1xuICAgICAgdGhpcy5fY29sbGVjdGlvbi5yYXdDb2xsZWN0aW9uKCkuY3JlYXRlSW5kZXgoeyB0aW1lc3RhbXBfbXM6IDEsIGJveF9pZDogMSB9LCB7IGJhY2tncm91bmQ6IHRydWUgfSk7XG4gICAgfVxuICB9XG5cbiAgLyoqXG4gICAqIERlZmluZXMgYSBuZXcgVHJlbmRzIGRvY3VtZW50LlxuICAgKiBAcGFyYW0ge1N0cmluZ30gYm94X2lkIC0gVGhlIE9QUUJveCdzIGlkIHZhbHVlIChub3QgTW9uZ28gSUQpXG4gICAqIEBwYXJhbSB7TnVtYmVyfSB0aW1lc3RhbXBfbXMgLSBUaGUgdW5peCB0aW1lc3RhbXAgKG1pbGxpcykgb2YgdGhlIHRyZW5kLlxuICAgKiBAcGFyYW0ge051bWJlcn0gdm9sdGFnZSAtIFRoZSB2b2x0YWdlIHRyZW5kIG9iamVjdC5cbiAgICogQHBhcmFtIHtOdW1iZXJ9IGZyZXF1ZW5jeSAtIFRoZSBmcmVxdWVuY3kgdHJlbmQgb2JqZWN0LlxuICAgKiBAcGFyYW0ge051bWJlcn0gdGhkIC0gVGhlIHRoZCB0cmVuZCBvYmplY3QuXG4gICAqIEByZXR1cm5zIFRoZSBuZXdseSBjcmVhdGVkIGRvY3VtZW50IElELlxuICAgKi9cbiAgZGVmaW5lKHsgYm94X2lkLCB0aW1lc3RhbXBfbXMsIHZvbHRhZ2UsIGZyZXF1ZW5jeSwgdGhkIH0pIHtcbiAgICBjb25zdCBkb2NJRCA9IHRoaXMuX2NvbGxlY3Rpb24uaW5zZXJ0KHsgYm94X2lkLCB0aW1lc3RhbXBfbXMsIHZvbHRhZ2UsIGZyZXF1ZW5jeSwgdGhkIH0pO1xuICAgIHJldHVybiBkb2NJRDtcbiAgfVxuXG4gIC8qKlxuICAgKiBSZXR1cm5zIHRoZSBvbGRlc3QgVHJlbmQgZG9jdW1lbnQgYXNzb2NpYXRlZCB3aXRoIGJveF9pZCBieSB0aW1lc3RhbXAsIG9yIG51bGwgaWYgdGhlcmUgYXJlIG5vIFRyZW5kcyBmb3IgYm94X2lkLlxuICAgKiBAcGFyYW0gYm94X2lkIFRoZSBib3hfaWRcbiAgICogQHJldHVybnMgVGhlIFRyZW5kIGRvY3VtZW50LCBvciBudWxsLlxuICAgKi9cbiAgb2xkZXN0VHJlbmQoYm94X2lkKSB7XG4gICAgcmV0dXJuIHRoaXMuX2NvbGxlY3Rpb24uZmluZE9uZSh7IGJveF9pZCwgdGltZXN0YW1wX21zOiB7ICRndDogMCB9IH0sIHsgc29ydDogeyB0aW1lc3RhbXBfbXM6IDEgfSB9KTtcbiAgfVxuXG4gIC8qKlxuICAgKiBSZXR1cm5zIHRoZSBuZXdlc3QgVHJlbmQgZG9jdW1lbnQgYXNzb2NpYXRlZCB3aXRoIGJveF9pZCBieSB0aW1lc3RhbXAsIG9yIG51bGwgaWYgdGhlcmUgYXJlIG5vIFRyZW5kcyBmb3IgYm94X2lkLlxuICAgKiBAcGFyYW0gYm94X2lkIFRoZSBib3hfaWRcbiAgICogQHJldHVybnMgVGhlIFRyZW5kIGRvY3VtZW50LCBvciBudWxsLlxuICAgKi9cbiAgbmV3ZXN0VHJlbmQoYm94X2lkKSB7XG4gICAgcmV0dXJuIHRoaXMuX2NvbGxlY3Rpb24uZmluZE9uZSh7IGJveF9pZCB9LCB7IHNvcnQ6IHsgdGltZXN0YW1wX21zOiAtMSB9IH0pO1xuICB9XG5cbiAgLyoqXG4gICAqIFJldHVybnMgdGhlIG51bWJlciBvZiBUcmVuZCBkb2N1bWVudHMgYXNzb2NpYXRlZCB3aXRoIGJveF9pZC5cbiAgICogQHBhcmFtIGJveF9pZCBUaGUgYm94IElELlxuICAgKiBAcmV0dXJucyBUaGUgbnVtYmVyIG9mIFRyZW5kIGRvY3VtZW50cyB3aXRoIHRoYXQgSUQuXG4gICAqL1xuICBjb3VudFRyZW5kcyhib3hfaWQpIHtcbiAgICByZXR1cm4gdGhpcy5fY29sbGVjdGlvbi5maW5kKHsgYm94X2lkIH0pLmNvdW50KCk7XG4gIH1cblxuICAvKipcbiAgICogUmV0dXJucyBhbiBvYmplY3QgcmVwcmVzZW50aW5nIGEgc2luZ2xlIFRyZW5kLlxuICAgKiBAcGFyYW0ge09iamVjdH0gZG9jSUQgLSBUaGUgTW9uZ28uT2JqZWN0SUQgb2YgdGhlIFRyZW5kLlxuICAgKiBAcmV0dXJucyB7T2JqZWN0fSAtIEFuIG9iamVjdCByZXByZXNlbnRpbmcgYSBzaW5nbGUgVHJlbmQuXG4gICAqL1xuICBkdW1wT25lKGRvY0lEKSB7XG4gICAgLyogZXNsaW50LWRpc2FibGUgY2FtZWxjYXNlICovXG4gICAgY29uc3QgZG9jID0gdGhpcy5maW5kRG9jKGRvY0lEKTtcbiAgICBjb25zdCBib3hfaWQgPSBkb2MuYm94X2lkO1xuICAgIGNvbnN0IHRpbWVzdGFtcF9tcyA9IGRvYy50aW1lc3RhbXBfbXM7XG4gICAgY29uc3Qgdm9sdGFnZSA9IGRvYy52b2x0YWdlO1xuICAgIGNvbnN0IGZyZXF1ZW5jeSA9IGRvYy5mcmVxdWVuY3k7XG4gICAgY29uc3QgdGhkID0gZG9jLnRoZDtcblxuICAgIHJldHVybiB7IGJveF9pZCwgdGltZXN0YW1wX21zLCB2b2x0YWdlLCBmcmVxdWVuY3ksIHRoZCB9O1xuICAgIC8qIGVzbGludC1lbmFibGUgY2FtZWxjYXNlICovXG4gIH1cblxuICBjaGVja0ludGVncml0eSgpIHtcbiAgICBjb25zdCBwcm9ibGVtcyA9IFtdO1xuICAgIGNvbnN0IHRvdGFsQ291bnQgPSB0aGlzLmNvdW50KCk7XG4gICAgY29uc3QgdmFsaWRhdGlvbkNvbnRleHQgPSB0aGlzLmdldFNjaGVtYSgpLm5hbWVkQ29udGV4dCgndHJlbmRzSW50ZWdyaXR5Jyk7XG4gICAgY29uc3QgcGIgPSBwcm9ncmVzc0JhclNldHVwKHRvdGFsQ291bnQsIDIwMDAsIGBDaGVja2luZyAke3RoaXMuX2NvbGxlY3Rpb25OYW1lfSBjb2xsZWN0aW9uOiBgKTtcblxuICAgIC8vIEdldCBhbGwgT3BxQm94IElEcy5cbiAgICBjb25zdCBib3hJRHMgPSBPcHFCb3hlcy5maW5kKCkubWFwKGRvYyA9PiBkb2MuYm94X2lkKTtcblxuICAgIHRoaXMuZmluZCgpLmZvckVhY2goKGRvYywgaW5kZXgpID0+IHtcbiAgICAgIHBiLnVwZGF0ZUJhcihpbmRleCk7IC8vIFVwZGF0ZSBwcm9ncmVzcyBiYXIuXG5cbiAgICAgIC8vIFZhbGlkYXRlIGVhY2ggZG9jdW1lbnQgYWdhaW5zdCB0aGUgY29sbGVjdGlvbiBzY2hlbWEuXG4gICAgICB2YWxpZGF0aW9uQ29udGV4dC52YWxpZGF0ZShkb2MpO1xuICAgICAgaWYgKCF2YWxpZGF0aW9uQ29udGV4dC5pc1ZhbGlkKCkpIHtcbiAgICAgICAgLy8gZXNsaW50LWRpc2FibGUtbmV4dC1saW5lIG1heC1sZW5cbiAgICAgICAgcHJvYmxlbXMucHVzaChgVHJlbmRzIGRvY3VtZW50IGZhaWxlZCBzY2hlbWEgdmFsaWRhdGlvbjogJHtkb2MuX2lkfSAoSW52YWxpZCBrZXlzOiAke0pTT04uc3RyaW5naWZ5KHZhbGlkYXRpb25Db250ZXh0LmludmFsaWRLZXlzKCksIG51bGwsIDIpfSlgKTtcbiAgICAgIH1cbiAgICAgIHZhbGlkYXRpb25Db250ZXh0LnJlc2V0VmFsaWRhdGlvbigpO1xuXG4gICAgICAvLyBFbnN1cmUgYm94X2lkIG9mIHRoZSB0cmVuZCBleGlzdHMgaW4gb3BxX2JveGVzIGNvbGxlY3Rpb24uXG4gICAgICBpZiAoIWJveElEcy5pbmNsdWRlcyhkb2MuYm94X2lkKSkge1xuICAgICAgICBwcm9ibGVtcy5wdXNoKGBUcmVuZHMgYm94X2lkIGRvZXMgbm90IGV4aXN0IGluIG9wcV9ib3hlcyBjb2xsZWN0aW9uOiAke2RvYy5ib3hfaWR9IChkb2NJRDogJHtkb2MuX2lkfSlgKTtcbiAgICAgIH1cbiAgICB9KTtcblxuICAgIHBiLmNsZWFySW50ZXJ2YWwoKTtcbiAgICByZXR1cm4gcHJvYmxlbXM7XG4gIH1cblxuICAvKipcbiAgICogTG9hZHMgYWxsIHB1YmxpY2F0aW9ucyByZWxhdGVkIHRvIHRoZSBUcmVuZHMgY29sbGVjdGlvbi5cbiAgICovXG4gIHB1Ymxpc2goKSB7IC8vIGVzbGludC1kaXNhYmxlLWxpbmUgY2xhc3MtbWV0aG9kcy11c2UtdGhpc1xuICAgIGlmIChNZXRlb3IuaXNTZXJ2ZXIpIHtcbiAgICAgIGNvbnN0IHNlbGYgPSB0aGlzO1xuXG4gICAgICBNZXRlb3IucHVibGlzaCh0aGlzLnB1YmxpY2F0aW9uTmFtZXMuR0VUX1JFQ0VOVF9UUkVORFMsIGZ1bmN0aW9uICh7IG51bVRyZW5kcyB9KSB7XG4gICAgICAgIGNoZWNrKG51bVRyZW5kcywgTnVtYmVyKTtcblxuICAgICAgICBjb25zdCB0cmVuZHMgPSBzZWxmLmZpbmQoe30sIHsgc29ydDogeyB0aW1lc3RhbXBfbXM6IC0xIH0sIGxpbWl0OiBudW1UcmVuZHMgfSk7XG4gICAgICAgIHJldHVybiB0cmVuZHM7XG4gICAgICB9KTtcbiAgICB9XG4gIH1cbn1cblxuLyoqXG4gKiBQcm92aWRlcyB0aGUgc2luZ2xldG9uIGluc3RhbmNlIG9mIHRoaXMgY2xhc3MuXG4gKiBAdHlwZSB7VHJlbmRzQ29sbGVjdGlvbn1cbiAqL1xuZXhwb3J0IGNvbnN0IFRyZW5kcyA9IG5ldyBUcmVuZHNDb2xsZWN0aW9uKCk7XG4iLCJpbXBvcnQgeyBWYWxpZGF0ZWRNZXRob2QgfSBmcm9tICdtZXRlb3IvbWRnOnZhbGlkYXRlZC1tZXRob2QnO1xuaW1wb3J0IFNpbXBsZVNjaGVtYSBmcm9tICdzaW1wbC1zY2hlbWEnO1xuaW1wb3J0IE1vbWVudCBmcm9tICdtb21lbnQnO1xuaW1wb3J0IF8gZnJvbSAnbG9kYXNoJztcbmltcG9ydCB7IGRlbWFwaWZ5IH0gZnJvbSAnZXM2LW1hcGlmeSc7XG5pbXBvcnQgeyBUcmVuZHMgfSBmcm9tICcuL1RyZW5kc0NvbGxlY3Rpb24nO1xuXG5leHBvcnQgY29uc3QgdG90YWxUcmVuZHNDb3VudCA9IG5ldyBWYWxpZGF0ZWRNZXRob2Qoe1xuICBuYW1lOiAnVHJlbmRzLnRvdGFsVHJlbmRzQ291bnQnLFxuICB2YWxpZGF0ZTogbmV3IFNpbXBsZVNjaGVtYSgpLnZhbGlkYXRvcih7IGNsZWFuOiB0cnVlIH0pLFxuICBydW4oKSB7XG4gICAgcmV0dXJuIFRyZW5kcy5maW5kKHt9KS5jb3VudCgpO1xuICB9LFxufSk7XG5cbmV4cG9ydCBjb25zdCBnZXRNb3N0UmVjZW50VHJlbmRNb250aCA9IG5ldyBWYWxpZGF0ZWRNZXRob2Qoe1xuICBuYW1lOiAnVHJlbmRzLm1vc3RSZWNlbnRUcmVuZE1vbnRoJyxcbiAgdmFsaWRhdGU6IG5ldyBTaW1wbGVTY2hlbWEoe30pLnZhbGlkYXRvcih7IGNsZWFuOiB0cnVlIH0pLFxuICBydW4oKSB7XG4gICAgaWYgKCF0aGlzLmlzU2ltdWxhdGlvbikge1xuICAgICAgY29uc3QgdHJlbmQgPSBUcmVuZHMuZmluZE9uZSh7fSwgeyBzb3J0OiB7IHRpbWVzdGFtcF9tczogLTEgfSB9KTtcbiAgICAgIGNvbnN0IHRyZW5kTW9tZW50ID0gTW9tZW50KHRyZW5kLnRpbWVzdGFtcF9tcyk7XG4gICAgICBjb25zdCBtb250aCA9IHRyZW5kTW9tZW50Lm1vbnRoKCk7IC8vIDAtaW5kZXhlZCBtb250aCBpbnRlZ2VycyAoSmFudWFyeSBpcyAwKVxuICAgICAgY29uc3QgeWVhciA9IHRyZW5kTW9tZW50LnllYXIoKTtcbiAgICAgIHJldHVybiB7IGJveF9pZDogdHJlbmQuYm94X2lkLCBtb250aCwgeWVhciB9O1xuICAgIH1cbiAgICByZXR1cm4gbnVsbDtcbiAgfSxcbn0pO1xuXG5cbi8qKlxuICogUmV0dXJucyBkYWlseSB0cmVuZCBkYXRhIGFuZCByYW5nZSB0cmVuZCBkYXRhIHdpdGggdGhlIGJveCBJRHMgYXMgdGhlaXIga2V5c1xuICogQHBhcmFtIHtTdHJpbmdbXX0gYm94SURzOiBMaXN0IG9mIGJveCBJRHMgdG8gZ2V0IGRhdGEgZm9yXG4gKiBAcGFyYW0ge051bWJlcn0gc3RhcnREYXRlX21zOiBTdGFydCBvZiByYW5nZSBpbiBVbml4IGVwb2NoIHRpbWVcbiAqIEBwYXJhbSB7TnVtYmVyfSBlbmREYXRlX21zOiBFbmQgb2YgcmFuZ2UgaW4gVW5peCBlcG9jaCB0aW1lXG4gKiBAcmV0dXJucyBBbiBhcnJheSBvZiBzaGFwZSB7IGJveElEOiB7IGRhaWx5VHJlbmRzLCByYW5nZVRyZW5kcyB9IH1cbiAqXG4gKiAhISEgVEhJUyBGVU5DVElPTiBJUyBGT1IgUkVGRVJFTkNFLCBOT1QgRk9SIFVTRSAhISFcbiAqL1xuZXhwb3J0IGNvbnN0IGRhaWx5VHJlbmRzSW5SYW5nZSA9IG5ldyBWYWxpZGF0ZWRNZXRob2Qoe1xuICBuYW1lOiAnVHJlbmRzLmRhaWx5VHJlbmRzSW5SYW5nZScsXG4gIHZhbGlkYXRlOiBuZXcgU2ltcGxlU2NoZW1hKHtcbiAgICBib3hJRHM6IHsgdHlwZTogQXJyYXkgfSxcbiAgICAnYm94SURzLiQnOiB7IHR5cGU6IFN0cmluZyB9LFxuICAgIHN0YXJ0RGF0ZV9tczogeyB0eXBlOiBOdW1iZXIgfSxcbiAgICBlbmREYXRlX21zOiB7IHR5cGU6IE51bWJlciB9LFxuICB9KS52YWxpZGF0b3IoeyBjbGVhbjogdHJ1ZSB9KSxcbiAgcnVuKHsgYm94SURzLCBzdGFydERhdGVfbXMsIGVuZERhdGVfbXMgfSkge1xuICAgIC8vIFRoZSBzaGFwZSBvZiB3aGF0IG91ciBkYWlseSBhbmQgbW9udGhseSB0cmVuZCBzdW1tYXJpZXMgd2lsbCBsb29rIGxpa2UuXG4gICAgY29uc3QgdHJlbmRTdW1tYXJ5U2hhcGUgPSB7XG4gICAgICB2b2x0YWdlOiB7XG4gICAgICAgIG1pbjogTnVtYmVyLk1BWF9TQUZFX0lOVEVHRVIsXG4gICAgICAgIG1pbkRhdGU6IG51bGwsXG4gICAgICAgIG1heDogTnVtYmVyLk1JTl9TQUZFX0lOVEVHRVIsXG4gICAgICAgIG1heERhdGU6IG51bGwsXG4gICAgICAgIGF2ZXJhZ2U6IDAsXG4gICAgICAgIGNvdW50OiAwLFxuICAgICAgfSxcbiAgICAgIGZyZXF1ZW5jeToge1xuICAgICAgICBtaW46IE51bWJlci5NQVhfU0FGRV9JTlRFR0VSLFxuICAgICAgICBtaW5EYXRlOiBudWxsLFxuICAgICAgICBtYXg6IE51bWJlci5NSU5fU0FGRV9JTlRFR0VSLFxuICAgICAgICBtYXhEYXRlOiBudWxsLFxuICAgICAgICBhdmVyYWdlOiAwLFxuICAgICAgICBjb3VudDogMCxcbiAgICAgIH0sXG4gICAgICB0aGQ6IHtcbiAgICAgICAgbWluOiBOdW1iZXIuTUFYX1NBRkVfSU5URUdFUixcbiAgICAgICAgbWluRGF0ZTogbnVsbCxcbiAgICAgICAgbWF4OiBOdW1iZXIuTUlOX1NBRkVfSU5URUdFUixcbiAgICAgICAgbWF4RGF0ZTogbnVsbCxcbiAgICAgICAgYXZlcmFnZTogMCxcbiAgICAgICAgY291bnQ6IDAsXG4gICAgICB9LFxuICAgICAgdG90YWxEb2NDb3VudDogMCxcbiAgICB9O1xuICAgIC8vIEZvciBlYWNoIGJveCwgZmluZCB0aGUgdHJlbmRzIGFzc29jaWF0ZWQgd2l0aCBpdCBhbmRcbiAgICAvLyBzdW1tYXJpemUgZWFjaCBkYXkncyB0cmVuZHMgaW50byBhbiBvYmplY3Qgd2l0aCB0aGVcbiAgICAvLyB0aW1lc3RhbXAgb2YgdGhlIHN0YXJ0IG9mIHRoYXQgZGF5IChpbiBtcykgYXMgaXRzIGtleVxuICAgIC8vIGkuZS4geyB0aW1lc3RhbXA6IGRhaWx5VHJlbmREYXRhIH1cbiAgICByZXR1cm4gT2JqZWN0LmFzc2lnbiguLi5ib3hJRHMubWFwKGJveElEID0+IHtcbiAgICAgIGNvbnN0IGFzc29jaWF0ZWRUcmVuZHMgPSBUcmVuZHMuZmluZCh7XG4gICAgICAgIGJveF9pZDogYm94SUQsXG4gICAgICAgIHRpbWVzdGFtcF9tczogeyAkZ3Q6IHN0YXJ0RGF0ZV9tcywgJGx0ZTogTW9tZW50KGVuZERhdGVfbXMpLmVuZE9mKCdkYXknKS52YWx1ZU9mKCkgfSxcbiAgICAgIH0pLmZldGNoKCk7XG5cbiAgICAgIC8vIE5ldyBNb21lbnRzIGFyZSBpbnN0YW50aWF0ZWQgZXZlcnkgdGltZSwgYmVjYXVzZSB0aGV5IG11dGF0ZSBldmVuIHdoZW4gcmVhc3NpZ25lZCB0byBhIHZhcmlhYmxlLlxuICAgICAgY29uc3Qgc3RhcnQgPSBNb21lbnQoc3RhcnREYXRlX21zKTtcbiAgICAgIGNvbnN0IGVuZCA9IE1vbWVudChlbmREYXRlX21zKTtcbiAgICAgIC8vIENyZWF0ZSBzdHJ1Y3R1cmUgb2YgdGhlIGRhaWx5VHJlbmQgb2JqZWN0XG4gICAgICBjb25zdCBkYWlseVRyZW5kcyA9IG5ldyBNYXAoKTtcbiAgICAgIGZvciAobGV0IGkgPSBzdGFydC5zdGFydE9mKCdkYXknKTsgaSA8PSBlbmQuc3RhcnRPZignZGF5Jyk7IGkgPSBpLmFkZCgxLCAnZGF5cycpKSB7XG4gICAgICAgIGRhaWx5VHJlbmRzLnNldChpLnZhbHVlT2YoKSwgXy5jbG9uZURlZXAodHJlbmRTdW1tYXJ5U2hhcGUpKTtcbiAgICAgIH1cblxuICAgICAgLy8gSW5wdXQgcmVhbCB2YWx1ZXMgaW50byB0aGUgZGFpbHlUcmVuZCBvYmplY3RcbiAgICAgIGFzc29jaWF0ZWRUcmVuZHMuZm9yRWFjaCh0cmVuZCA9PiB7XG4gICAgICAgIGNvbnN0IHRyZW5kRGF5X21zID0gTW9tZW50KHRyZW5kLnRpbWVzdGFtcF9tcykuc3RhcnRPZignZGF5JykudmFsdWVPZigpO1xuICAgICAgICBjb25zdCBkdHYgPSBkYWlseVRyZW5kcy5nZXQodHJlbmREYXlfbXMpOyAvLyBEYWlseSBUcmVuZCBWYWx1ZXNcbiAgICAgICAgZHR2LnRvdGFsRG9jQ291bnQrKztcblxuICAgICAgICAvLyBWb2x0YWdlXG4gICAgICAgIGlmICh0cmVuZC52b2x0YWdlKSB7XG4gICAgICAgICAgZHR2LnZvbHRhZ2UuY291bnQrKztcbiAgICAgICAgICBpZiAodHJlbmQudm9sdGFnZS5taW4gPCBkdHYudm9sdGFnZS5taW4pIHtcbiAgICAgICAgICAgIGR0di52b2x0YWdlLm1pbiA9IHRyZW5kLnZvbHRhZ2UubWluO1xuICAgICAgICAgICAgZHR2LnZvbHRhZ2UubWluRGF0ZSA9IHRyZW5kLnRpbWVzdGFtcF9tcztcbiAgICAgICAgICB9XG4gICAgICAgICAgaWYgKHRyZW5kLnZvbHRhZ2UubWF4ID4gZHR2LnZvbHRhZ2UubWF4KSB7XG4gICAgICAgICAgICBkdHYudm9sdGFnZS5tYXggPSB0cmVuZC52b2x0YWdlLm1heDtcbiAgICAgICAgICAgIGR0di52b2x0YWdlLm1heERhdGUgPSB0cmVuZC50aW1lc3RhbXBfbXM7XG4gICAgICAgICAgfVxuICAgICAgICAgIGR0di52b2x0YWdlLmF2ZXJhZ2UgKz0gKHRyZW5kLnZvbHRhZ2UuYXZlcmFnZSAtIGR0di52b2x0YWdlLmF2ZXJhZ2UpIC8gZHR2LnZvbHRhZ2UuY291bnQ7XG4gICAgICAgIH1cbiAgICAgICAgLy8gRnJlcXVlbmN5XG4gICAgICAgIGlmICh0cmVuZC5mcmVxdWVuY3kpIHtcbiAgICAgICAgICBkdHYuZnJlcXVlbmN5LmNvdW50Kys7XG4gICAgICAgICAgaWYgKHRyZW5kLmZyZXF1ZW5jeS5taW4gPCBkdHYuZnJlcXVlbmN5Lm1pbikge1xuICAgICAgICAgICAgZHR2LmZyZXF1ZW5jeS5taW4gPSB0cmVuZC5mcmVxdWVuY3kubWluO1xuICAgICAgICAgICAgZHR2LmZyZXF1ZW5jeS5taW5EYXRlID0gdHJlbmQudGltZXN0YW1wX21zO1xuICAgICAgICAgIH1cbiAgICAgICAgICBpZiAodHJlbmQuZnJlcXVlbmN5Lm1heCA+IGR0di5mcmVxdWVuY3kubWF4KSB7XG4gICAgICAgICAgICBkdHYuZnJlcXVlbmN5Lm1heCA9IHRyZW5kLmZyZXF1ZW5jeS5tYXg7XG4gICAgICAgICAgICBkdHYuZnJlcXVlbmN5Lm1heERhdGUgPSB0cmVuZC50aW1lc3RhbXBfbXM7XG4gICAgICAgICAgfVxuICAgICAgICAgIGR0di5mcmVxdWVuY3kuYXZlcmFnZSArPSAodHJlbmQuZnJlcXVlbmN5LmF2ZXJhZ2UgLSBkdHYuZnJlcXVlbmN5LmF2ZXJhZ2UpIC8gZHR2LmZyZXF1ZW5jeS5jb3VudDtcbiAgICAgICAgfVxuICAgICAgICAvLyBUSERcbiAgICAgICAgaWYgKHRyZW5kLnRoZCkge1xuICAgICAgICAgIGR0di50aGQuY291bnQrKztcbiAgICAgICAgICBpZiAodHJlbmQudGhkLm1pbiA8IGR0di50aGQubWluKSB7XG4gICAgICAgICAgICBkdHYudGhkLm1pbiA9IHRyZW5kLnRoZC5taW47XG4gICAgICAgICAgICBkdHYudGhkLm1pbkRhdGUgPSB0cmVuZC50aW1lc3RhbXBfbXM7XG4gICAgICAgICAgfVxuICAgICAgICAgIGlmICh0cmVuZC50aGQubWF4ID4gZHR2LnRoZC5tYXgpIHtcbiAgICAgICAgICAgIGR0di50aGQubWF4ID0gdHJlbmQudGhkLm1heDtcbiAgICAgICAgICAgIGR0di50aGQubWF4RGF0ZSA9IHRyZW5kLnRpbWVzdGFtcF9tcztcbiAgICAgICAgICB9XG4gICAgICAgICAgZHR2LnRoZC5hdmVyYWdlICs9ICh0cmVuZC50aGQuYXZlcmFnZSAtIGR0di50aGQuYXZlcmFnZSkgLyBkdHYudGhkLmNvdW50O1xuICAgICAgICB9XG4gICAgICB9KTtcblxuICAgICAgLy8gRGVsZXRlIGZpZWxkcyB0aGF0IGFyZSBlbXB0eVxuICAgICAgZGFpbHlUcmVuZHMuZm9yRWFjaChkdHYgPT4ge1xuICAgICAgICBpZiAoZHR2LnZvbHRhZ2UuY291bnQgPT09IDApIGRlbGV0ZSBkdHYudm9sdGFnZTsgLy8gZXNsaW50LWRpc2FibGUtbGluZSBuby1wYXJhbS1yZWFzc2lnblxuICAgICAgICBpZiAoZHR2LmZyZXF1ZW5jeS5jb3VudCA9PT0gMCkgZGVsZXRlIGR0di5mcmVxdWVuY3k7IC8vIGVzbGludC1kaXNhYmxlLWxpbmUgbm8tcGFyYW0tcmVhc3NpZ25cbiAgICAgICAgaWYgKGR0di50aGQuY291bnQgPT09IDApIGRlbGV0ZSBkdHYudGhkOyAvLyBlc2xpbnQtZGlzYWJsZS1saW5lIG5vLXBhcmFtLXJlYXNzaWduXG4gICAgICB9KTtcbiAgICAgIC8vIERhaWx5IHVwdGltZSBjYWxjdWxhdGlvbnNcbiAgICAgIGRhaWx5VHJlbmRzLmZvckVhY2goZHR2ID0+IHtcbiAgICAgICAgLy8gVGhpcyBudW1iZXIgaXMgbm90IGFjY3VyYXRlLCBidXQgd2lsbCBiZSB1c2VkIHVudGlsIGEgYmV0dGVyIG1ldGhvZCBpcyBmb3VuZC5cbiAgICAgICAgZHR2LnVwdGltZSA9IChkdHYudG90YWxEb2NDb3VudCAvIDE0NDApICogMTAwOyAvLyBlc2xpbnQtZGlzYWJsZS1saW5lIG5vLXBhcmFtLXJlYXNzaWduXG4gICAgICB9KTtcblxuICAgICAgLy8gQ2FsY3VsYXRlcyBzdW1tYXJ5IGZvciB0aGUgZW50aXJlIHJhbmdlLlxuICAgICAgY29uc3QgcnR2ID0gXy5jbG9uZURlZXAodHJlbmRTdW1tYXJ5U2hhcGUpOyAvLyBydHYgPSByYW5nZSB0cmVuZCB2YWx1ZVxuICAgICAgZGFpbHlUcmVuZHMuZm9yRWFjaChkdHYgPT4geyAvLyBkdHYgPSBEYWlseSBUcmVuZCBWYWx1ZXNcbiAgICAgICAgLy8gUmVwcmVzZW50cyB0aGUgdHJ1ZSB0b3RhbCBkb2MgY291bnQgb2YgYWxsIHRyZW5kIGRvY3VtZW50cyBwYXJzZWQgZm9yIHRoaXMgcmFuZ2UuXG4gICAgICAgIHJ0di50b3RhbERvY0NvdW50ICs9IGR0di50b3RhbERvY0NvdW50O1xuXG4gICAgICAgIC8vIFZvbHRhZ2VcbiAgICAgICAgaWYgKGR0di52b2x0YWdlKSB7XG4gICAgICAgICAgcnR2LnZvbHRhZ2UuY291bnQrKztcbiAgICAgICAgICBpZiAoZHR2LnZvbHRhZ2UubWluIDwgcnR2LnZvbHRhZ2UubWluKSB7XG4gICAgICAgICAgICBydHYudm9sdGFnZS5taW4gPSBkdHYudm9sdGFnZS5taW47XG4gICAgICAgICAgICBydHYudm9sdGFnZS5taW5EYXRlID0gZHR2LnZvbHRhZ2UubWluRGF0ZTtcbiAgICAgICAgICB9XG4gICAgICAgICAgaWYgKGR0di52b2x0YWdlLm1heCA+IHJ0di52b2x0YWdlLm1heCkge1xuICAgICAgICAgICAgcnR2LnZvbHRhZ2UubWF4ID0gZHR2LnZvbHRhZ2UubWF4O1xuICAgICAgICAgICAgcnR2LnZvbHRhZ2UubWF4RGF0ZSA9IGR0di52b2x0YWdlLm1heERhdGU7XG4gICAgICAgICAgfVxuICAgICAgICAgIHJ0di52b2x0YWdlLmF2ZXJhZ2UgKz0gKGR0di52b2x0YWdlLmF2ZXJhZ2UgLSBydHYudm9sdGFnZS5hdmVyYWdlKSAvIHJ0di52b2x0YWdlLmNvdW50O1xuICAgICAgICB9XG4gICAgICAgIC8vIEZyZXF1ZW5jeVxuICAgICAgICBpZiAoZHR2LmZyZXF1ZW5jeSkge1xuICAgICAgICAgIHJ0di5mcmVxdWVuY3kuY291bnQrKztcbiAgICAgICAgICBpZiAoZHR2LmZyZXF1ZW5jeS5taW4gPCBydHYuZnJlcXVlbmN5Lm1pbikge1xuICAgICAgICAgICAgcnR2LmZyZXF1ZW5jeS5taW4gPSBkdHYuZnJlcXVlbmN5Lm1pbjtcbiAgICAgICAgICAgIHJ0di5mcmVxdWVuY3kubWluRGF0ZSA9IGR0di5mcmVxdWVuY3kubWluRGF0ZTtcbiAgICAgICAgICB9XG4gICAgICAgICAgaWYgKGR0di5mcmVxdWVuY3kubWF4ID4gcnR2LmZyZXF1ZW5jeS5tYXgpIHtcbiAgICAgICAgICAgIHJ0di5mcmVxdWVuY3kubWF4ID0gZHR2LmZyZXF1ZW5jeS5tYXg7XG4gICAgICAgICAgICBydHYuZnJlcXVlbmN5Lm1heERhdGUgPSBkdHYuZnJlcXVlbmN5Lm1heERhdGU7XG4gICAgICAgICAgfVxuICAgICAgICAgIHJ0di5mcmVxdWVuY3kuYXZlcmFnZSArPSAoZHR2LmZyZXF1ZW5jeS5hdmVyYWdlIC0gcnR2LmZyZXF1ZW5jeS5hdmVyYWdlKSAvIHJ0di5mcmVxdWVuY3kuY291bnQ7XG4gICAgICAgIH1cbiAgICAgICAgLy8gVEhEXG4gICAgICAgIGlmIChkdHYudGhkKSB7XG4gICAgICAgICAgcnR2LnRoZC5jb3VudCsrO1xuICAgICAgICAgIGlmIChkdHYudGhkLm1pbiA8IHJ0di50aGQubWluKSB7XG4gICAgICAgICAgICBydHYudGhkLm1pbiA9IGR0di50aGQubWluO1xuICAgICAgICAgICAgcnR2LnRoZC5taW5EYXRlID0gZHR2LnRoZC5taW5EYXRlO1xuICAgICAgICAgIH1cbiAgICAgICAgICBpZiAoZHR2LnRoZC5tYXggPiBydHYudGhkLm1heCkge1xuICAgICAgICAgICAgcnR2LnRoZC5tYXggPSBkdHYudGhkLm1heDtcbiAgICAgICAgICAgIHJ0di50aGQubWF4RGF0ZSA9IGR0di50aGQubWF4RGF0ZTtcbiAgICAgICAgICB9XG4gICAgICAgICAgcnR2LnRoZC5hdmVyYWdlICs9IChkdHYudGhkLmF2ZXJhZ2UgLSBydHYudGhkLmF2ZXJhZ2UpIC8gcnR2LnRoZC5jb3VudDtcbiAgICAgICAgfVxuICAgICAgfSk7XG5cbiAgICAgIC8vIERlbGV0ZSBlbXB0eSBmaWVsZHNcbiAgICAgIGlmIChydHYudm9sdGFnZS5jb3VudCA9PT0gMCkgZGVsZXRlIHJ0di52b2x0YWdlOyAvLyBlc2xpbnQtZGlzYWJsZS1saW5lIG5vLXBhcmFtLXJlYXNzaWduXG4gICAgICBpZiAocnR2LmZyZXF1ZW5jeS5jb3VudCA9PT0gMCkgZGVsZXRlIHJ0di5mcmVxdWVuY3k7IC8vIGVzbGludC1kaXNhYmxlLWxpbmUgbm8tcGFyYW0tcmVhc3NpZ25cbiAgICAgIGlmIChydHYudGhkLmNvdW50ID09PSAwKSBkZWxldGUgcnR2LnRoZDsgLy8gZXNsaW50LWRpc2FibGUtbGluZSBuby1wYXJhbS1yZWFzc2lnblxuXG4gICAgICByZXR1cm4geyBbYm94SURdOiB7IGRhaWx5VHJlbmRzOiBkZW1hcGlmeShkYWlseVRyZW5kcyksIHJhbmdlVHJlbmRzOiBydHYgfSB9O1xuICAgIH0pKTtcbiAgfSxcbn0pO1xuXG4vKipcbiAqIFJldHVybnMgYW4gYXJyYXkgb2YgZGFpbHkgdHJlbmQgZGF0YSB3aXRoIHRoZSBib3ggSURzIGFzIHRoZWlyIGtleXNcbiAqIEBwYXJhbSB7U3RyaW5nW119IGJveElEczogTGlzdCBvZiBib3ggSURzIHRvIGdldCBkYXRhIGZvclxuICogQHBhcmFtIHtOdW1iZXJ9IHN0YXJ0RGF0ZV9tczogU3RhcnQgb2YgcmFuZ2UgaW4gVW5peCBlcG9jaCB0aW1lXG4gKiBAcGFyYW0ge051bWJlcn0gZW5kRGF0ZV9tczogRW5kIG9mIHJhbmdlIGluIFVuaXggZXBvY2ggdGltZVxuICogQHJldHVybnMgQW4gT2JqZWN0IG9mIG9iamVjdHMsIGluIHRoaXMgZm9ybTogeyBib3hJRDogZGFpbHlUcmVuZHMgfX0uXG4gKi9cbmV4cG9ydCBjb25zdCBkYWlseVRyZW5kcyA9IG5ldyBWYWxpZGF0ZWRNZXRob2Qoe1xuICBuYW1lOiAnVHJlbmRzLmRhaWx5VHJlbmRzJyxcbiAgdmFsaWRhdGU6IG5ldyBTaW1wbGVTY2hlbWEoe1xuICAgIGJveElEczogeyB0eXBlOiBBcnJheSB9LFxuICAgICdib3hJRHMuJCc6IHsgdHlwZTogU3RyaW5nIH0sXG4gICAgc3RhcnREYXRlX21zOiB7IHR5cGU6IE51bWJlciB9LFxuICAgIGVuZERhdGVfbXM6IHsgdHlwZTogTnVtYmVyIH0sXG4gIH0pLnZhbGlkYXRvcih7IGNsZWFuOiB0cnVlIH0pLFxuICBydW4oeyBib3hJRHMsIHN0YXJ0RGF0ZV9tcywgZW5kRGF0ZV9tcyB9KSB7XG4gICAgLy8gRm9yIGVhY2ggYm94LCBmaW5kIHRoZSB0cmVuZHMgYXNzb2NpYXRlZCB3aXRoIGl0IGFuZFxuICAgIC8vIHN1bW1hcml6ZSBlYWNoIGRheSdzIHRyZW5kcyBpbnRvIGFuIG9iamVjdCB3aXRoIHRoZVxuICAgIC8vIHRpbWVzdGFtcCBvZiB0aGUgc3RhcnQgb2YgdGhhdCBkYXkgKGluIG1zKSBhcyBpdHMga2V5XG4gICAgLy8gaS5lLiB7IHRpbWVzdGFtcDogZGFpbHlUcmVuZERhdGEgfVxuICAgIHJldHVybiBPYmplY3QuYXNzaWduKC4uLmJveElEcy5tYXAoYm94SUQgPT4ge1xuICAgICAgY29uc3QgYXNzb2NpYXRlZFRyZW5kcyA9IFRyZW5kcy5maW5kKHtcbiAgICAgICAgYm94X2lkOiBib3hJRCxcbiAgICAgICAgdGltZXN0YW1wX21zOiB7ICRndDogc3RhcnREYXRlX21zLCAkbHRlOiBNb21lbnQoZW5kRGF0ZV9tcykuZW5kT2YoJ2RheScpLnZhbHVlT2YoKSB9LFxuICAgICAgfSkuZmV0Y2goKTtcblxuICAgICAgLy8gTmV3IE1vbWVudHMgYXJlIGluc3RhbnRpYXRlZCBldmVyeSB0aW1lLCBiZWNhdXNlIHRoZXkgbXV0YXRlIGV2ZW4gd2hlbiByZWFzc2lnbmVkIHRvIGEgdmFyaWFibGUuXG4gICAgICBjb25zdCBzdGFydCA9IE1vbWVudChzdGFydERhdGVfbXMpO1xuICAgICAgY29uc3QgZW5kID0gTW9tZW50KGVuZERhdGVfbXMpO1xuICAgICAgLy8gQ3JlYXRlIHN0cnVjdHVyZSBvZiB0aGUgZGFpbHlUcmVuZCBvYmplY3RcbiAgICAgIGNvbnN0IGRhaWx5VHJlbmRzTWFwID0gbmV3IE1hcCgpO1xuICAgICAgZm9yIChsZXQgaSA9IHN0YXJ0LnN0YXJ0T2YoJ2RheScpOyBpIDw9IGVuZC5zdGFydE9mKCdkYXknKTsgaSA9IGkuYWRkKDEsICdkYXlzJykpIHtcbiAgICAgICAgZGFpbHlUcmVuZHNNYXAuc2V0KGkudmFsdWVPZigpLCB7XG4gICAgICAgICAgdm9sdGFnZToge1xuICAgICAgICAgICAgbWluOiBJbmZpbml0eSxcbiAgICAgICAgICAgIG1heDogLUluZmluaXR5LFxuICAgICAgICAgICAgYXZlcmFnZTogMCxcbiAgICAgICAgICAgIGNvdW50OiAwLFxuICAgICAgICAgIH0sXG4gICAgICAgICAgZnJlcXVlbmN5OiB7XG4gICAgICAgICAgICBtaW46IEluZmluaXR5LFxuICAgICAgICAgICAgbWF4OiAtSW5maW5pdHksXG4gICAgICAgICAgICBhdmVyYWdlOiAwLFxuICAgICAgICAgICAgY291bnQ6IDAsXG4gICAgICAgICAgfSxcbiAgICAgICAgICB0aGQ6IHtcbiAgICAgICAgICAgIG1pbjogSW5maW5pdHksXG4gICAgICAgICAgICBtYXg6IC1JbmZpbml0eSxcbiAgICAgICAgICAgIGF2ZXJhZ2U6IDAsXG4gICAgICAgICAgICBjb3VudDogMCxcbiAgICAgICAgICB9LFxuICAgICAgICB9KTtcbiAgICAgIH1cblxuICAgICAgLy8gSW5wdXQgcmVhbCB2YWx1ZXMgaW50byB0aGUgZGFpbHlUcmVuZCBvYmplY3RcbiAgICAgIGFzc29jaWF0ZWRUcmVuZHMuZm9yRWFjaCh0cmVuZCA9PiB7XG4gICAgICAgIGNvbnN0IHRyZW5kRGF5X21zID0gTW9tZW50KHRyZW5kLnRpbWVzdGFtcF9tcykuc3RhcnRPZignZGF5JykudmFsdWVPZigpO1xuICAgICAgICBjb25zdCBkdHYgPSBkYWlseVRyZW5kc01hcC5nZXQodHJlbmREYXlfbXMpOyAvLyBEYWlseSBUcmVuZCBWYWx1ZXNcblxuICAgICAgICAvLyBWb2x0YWdlXG4gICAgICAgIGlmICh0cmVuZC52b2x0YWdlKSB7XG4gICAgICAgICAgZHR2LnZvbHRhZ2UuY291bnQrKztcbiAgICAgICAgICBpZiAodHJlbmQudm9sdGFnZS5taW4gPCBkdHYudm9sdGFnZS5taW4pIGR0di52b2x0YWdlLm1pbiA9IHRyZW5kLnZvbHRhZ2UubWluO1xuICAgICAgICAgIGlmICh0cmVuZC52b2x0YWdlLm1heCA+IGR0di52b2x0YWdlLm1heCkgZHR2LnZvbHRhZ2UubWF4ID0gdHJlbmQudm9sdGFnZS5tYXg7XG4gICAgICAgICAgZHR2LnZvbHRhZ2UuYXZlcmFnZSArPSAodHJlbmQudm9sdGFnZS5hdmVyYWdlIC0gZHR2LnZvbHRhZ2UuYXZlcmFnZSkgLyBkdHYudm9sdGFnZS5jb3VudDtcbiAgICAgICAgfVxuICAgICAgICAvLyBGcmVxdWVuY3lcbiAgICAgICAgaWYgKHRyZW5kLmZyZXF1ZW5jeSkge1xuICAgICAgICAgIGR0di5mcmVxdWVuY3kuY291bnQrKztcbiAgICAgICAgICBpZiAodHJlbmQuZnJlcXVlbmN5Lm1pbiA8IGR0di5mcmVxdWVuY3kubWluKSBkdHYuZnJlcXVlbmN5Lm1pbiA9IHRyZW5kLmZyZXF1ZW5jeS5taW47XG4gICAgICAgICAgaWYgKHRyZW5kLmZyZXF1ZW5jeS5tYXggPiBkdHYuZnJlcXVlbmN5Lm1heCkgZHR2LmZyZXF1ZW5jeS5tYXggPSB0cmVuZC5mcmVxdWVuY3kubWF4O1xuICAgICAgICAgIGR0di5mcmVxdWVuY3kuYXZlcmFnZSArPSAodHJlbmQuZnJlcXVlbmN5LmF2ZXJhZ2UgLSBkdHYuZnJlcXVlbmN5LmF2ZXJhZ2UpIC8gZHR2LmZyZXF1ZW5jeS5jb3VudDtcbiAgICAgICAgfVxuICAgICAgICAvLyBUSERcbiAgICAgICAgaWYgKHRyZW5kLnRoZCkge1xuICAgICAgICAgIGR0di50aGQuY291bnQrKztcbiAgICAgICAgICBpZiAodHJlbmQudGhkLm1pbiA8IGR0di50aGQubWluKSBkdHYudGhkLm1pbiA9IHRyZW5kLnRoZC5taW47XG4gICAgICAgICAgaWYgKHRyZW5kLnRoZC5tYXggPiBkdHYudGhkLm1heCkgZHR2LnRoZC5tYXggPSB0cmVuZC50aGQubWF4O1xuICAgICAgICAgIGR0di50aGQuYXZlcmFnZSArPSAodHJlbmQudGhkLmF2ZXJhZ2UgLSBkdHYudGhkLmF2ZXJhZ2UpIC8gZHR2LnRoZC5jb3VudDtcbiAgICAgICAgfVxuICAgICAgfSk7XG5cbiAgICAgIC8vIERlbGV0ZSBmaWVsZHMgdGhhdCBhcmUgZW1wdHlcbiAgICAgIGRhaWx5VHJlbmRzTWFwLmZvckVhY2goZHR2ID0+IHtcbiAgICAgICAgaWYgKGR0di52b2x0YWdlLmNvdW50ID09PSAwKSBkZWxldGUgZHR2LnZvbHRhZ2U7IC8vIGVzbGludC1kaXNhYmxlLWxpbmUgbm8tcGFyYW0tcmVhc3NpZ25cbiAgICAgICAgZWxzZSBkZWxldGUgZHR2LnZvbHRhZ2UuY291bnQ7IC8vIGVzbGludC1kaXNhYmxlLWxpbmUgbm8tcGFyYW0tcmVhc3NpZ25cbiAgICAgICAgaWYgKGR0di5mcmVxdWVuY3kuY291bnQgPT09IDApIGRlbGV0ZSBkdHYuZnJlcXVlbmN5OyAvLyBlc2xpbnQtZGlzYWJsZS1saW5lIG5vLXBhcmFtLXJlYXNzaWduXG4gICAgICAgIGVsc2UgZGVsZXRlIGR0di5mcmVxdWVuY3kuY291bnQ7IC8vIGVzbGludC1kaXNhYmxlLWxpbmUgbm8tcGFyYW0tcmVhc3NpZ25cbiAgICAgICAgaWYgKGR0di50aGQuY291bnQgPT09IDApIGRlbGV0ZSBkdHYudGhkOyAvLyBlc2xpbnQtZGlzYWJsZS1saW5lIG5vLXBhcmFtLXJlYXNzaWduXG4gICAgICAgIGVsc2UgZGVsZXRlIGR0di50aGQuY291bnQ7IC8vIGVzbGludC1kaXNhYmxlLWxpbmUgbm8tcGFyYW0tcmVhc3NpZ25cbiAgICAgIH0pO1xuXG4gICAgICByZXR1cm4geyBbYm94SURdOiBkZW1hcGlmeShkYWlseVRyZW5kc01hcCkgfTtcbiAgICB9KSk7XG4gIH0sXG59KTtcbiIsImltcG9ydCAnLi9UcmVuZHNDb2xsZWN0aW9uLmpzJztcbmltcG9ydCAnLi9UcmVuZHNDb2xsZWN0aW9uTWV0aG9kcy5qcyc7XG4iLCJpbXBvcnQgeyBNZXRlb3IgfSBmcm9tICdtZXRlb3IvbWV0ZW9yJztcbmltcG9ydCBTaW1wbGVTY2hlbWEgZnJvbSAnc2ltcGwtc2NoZW1hJztcbmltcG9ydCBCYXNlQ29sbGVjdGlvbiBmcm9tICcuLi9iYXNlL0Jhc2VDb2xsZWN0aW9uJztcblxuLyoqXG4gKiBVc2VyIFByb2ZpbGVzIChmaXJzdCBhbmQgbGFzdCBuYW1lLCByb2xlLCBhbmQgdXNlcm5hbWUgKGVtYWlsKS5cbiAqIFRvIGNyZWF0ZSBhIG5ldyBVc2VyLCBjYWxsIFVzZXJQcm9maWxlcy5kZWZpbmUoKSwgd2hpY2ggYm90aCBkZWZpbmVzIHRoZSBwcm9maWxlIGFuZCBjcmVhdGVzIHRoZSBNZXRlb3IudXNlci5cbiAqIERvY3M6IGh0dHBzOi8vb3Blbi1wb3dlci1xdWFsaXR5LmdpdGJvb2tzLmlvL29wZW4tcG93ZXItcXVhbGl0eS1tYW51YWwvY29udGVudC9kYXRhbW9kZWwvZGVzY3JpcHRpb24uaHRtbCN1c2Vyc1xuICovXG5jbGFzcyBCb3hPd25lcnNDb2xsZWN0aW9uIGV4dGVuZHMgQmFzZUNvbGxlY3Rpb24ge1xuXG4gIC8qKlxuICAgKiBDcmVhdGVzIHRoZSBVc2VyIFByb2ZpbGVzIGNvbGxlY3Rpb24uXG4gICAqL1xuICBjb25zdHJ1Y3RvcigpIHtcbiAgICBzdXBlcignQm94T3duZXJzJywgbmV3IFNpbXBsZVNjaGVtYSh7XG4gICAgICB1c2VybmFtZTogU3RyaW5nLFxuICAgICAgYm94SWQ6IFN0cmluZyxcbiAgICB9KSk7XG4gIH1cblxuICAvKipcbiAgICogRGVmaW5lcyB1c2VybmFtZSBhcyBhbiBvd25lciBvZiBib3hJZC5cbiAgICogSWYgdXNlcm5hbWUgaXMgYWxyZWFkeSBzcGVjaWZpZWQgYXMgYW4gb3duZXIgb2YgYm94SUQsIHRoYXQgZG9jSUQgaXMgcmV0dXJuZWQuXG4gICAqIE90aGVyd2lzZSBhIG5ldyBCb3hPd25lcnMgZG9jdW1lbnQgaXMgY3JlYXRlZCBhbmQgaXRzIGRvY0lEIGlzIHJldHVybmVkLlxuICAgKiBOb3RlIHRoYXQgbm8gY2hlY2tpbmcgaXMgZG9uZSB0byBzZWUgaWYgdXNlcm5hbWUgYW5kL29yIGJveElkIGlzIGEgdmFsaWQgdXNlcm5hbWUgb3IgYm94SWQuIFNvLCBiZSBjYXJlZnVsLlxuICAgKiBPbmx5IHdvcmtzIG9uIHRoZSBzZXJ2ZXIgc2lkZS5cbiAgICogQHBhcmFtIHtTdHJpbmd9IHVzZXJuYW1lIC0gTXVzdCBiZSB0aGUgdXNlcidzIGVtYWlsIGFkZHJlc3MuXG4gICAqIEBwYXJhbSB7TnVtYmVyfSBib3hJZCAtIFRoZSBpZCBvZiB0aGUgYm94IChhbiBpbnRlZ2VyKS5cbiAgICogQHJldHVybiBUaGUgZG9jSUQgZm9yIHRoaXMgb3duZXJzaGlwIGRvY3VtZW50LlxuICAgKi9cbiAgLy8gZXNsaW50LWRpc2FibGUtbmV4dC1saW5lIGNsYXNzLW1ldGhvZHMtdXNlLXRoaXNcbiAgZGVmaW5lKHsgdXNlcm5hbWUsIGJveElkIH0pIHtcbiAgICBpZiAoTWV0ZW9yLmlzU2VydmVyKSB7XG4gICAgICBjb25zdCBleGlzdGluZ0RvYyA9IHRoaXMuZmluZE9uZSh1c2VybmFtZSwgYm94SWQpO1xuICAgICAgaWYgKGV4aXN0aW5nRG9jKSB7XG4gICAgICAgIHJldHVybiBleGlzdGluZ0RvYy5faWQ7XG4gICAgICB9XG4gICAgICByZXR1cm4gdGhpcy5fY29sbGVjdGlvbi5pbnNlcnQoeyB1c2VybmFtZSwgYm94SWQgfSk7XG4gICAgfVxuICAgIC8vIFJldHVybiB1bmRlZmluZWQgaWYgZXhlY3V0ZWQgb24gdGhlIGNsaWVudCAod2hpY2ggc2hvdWxkbid0IGV2ZXIgaGFwcGVuLilcbiAgICByZXR1cm4gdW5kZWZpbmVkO1xuICB9XG5cbiAgLyoqXG4gICAqIFJldHVybnMgYW4gYXJyYXkgb2YgdGhlIGJveCBkb2N1bWVudHMgb3duZWQgYnkgdXNlcm5hbWUuXG4gICAqIEBwYXJhbSB1c2VybmFtZSBUaGUgdXNlcm5hbWUuXG4gICAqIEByZXR1cm4geyBBcnJheSB9IEFuIGFycmF5IG9mIGJveCBkb2N1bWVudHMgb3duZWQgYnkgdGhpcyB1c2VyLlxuICAgKi9cbiAgZmluZEJveGVzV2l0aE93bmVyKHVzZXJuYW1lKSB7XG4gICAgcmV0dXJuIHRoaXMuX2NvbGxlY3Rpb24uZmluZCh7IHVzZXJuYW1lIH0pLmZldGNoKCk7XG4gIH1cblxuICAvKipcbiAgICogUmV0dXJucyBhIChwb3NzaWJseSBlbXB0eSkgYXJyYXkgb2YgYm94SWRzIG93bmVkIGJ5IHVzZXJuYW1lLlxuICAgKiBAcGFyYW0gdXNlcm5hbWUgVGhlIHVzZXJuYW1lXG4gICAqIEByZXR1cm4geyBBcnJheSB9IEFuIGFycmF5IG9mIGJveElkcyBvd25lZCBieSB0aGlzIHVzZXIuXG4gICAqL1xuICBmaW5kQm94SWRzV2l0aE93bmVyKHVzZXJuYW1lKSB7XG4gICAgY29uc3QgZG9jcyA9IHRoaXMuX2NvbGxlY3Rpb24uZmluZCh7IHVzZXJuYW1lIH0pLmZldGNoKCk7XG4gICAgcmV0dXJuIChkb2NzKSA/IF8ubWFwKGRvY3MsIGRvYyA9PiBkb2MuYm94SWQpIDogW107XG4gIH1cblxuICAvKipcbiAgICogUmV0dXJucyBhIChwb3NzaWJseSBlbXB0eSkgYXJyYXkgb2YgdXNlcm5hbWVzIHdobyBvd24gdGhlIGJveC5cbiAgICogQHBhcmFtIGJveElkIFRoZSBib3hJZC5cbiAgICogQHJldHVybiB7IEFycmF5IH0gQW4gYXJyYXkgb2YgdXNlcm5hbWVzIHdobyBvd24gYm94SWQuXG4gICAqL1xuICBmaW5kT3duZXJzV2l0aEJveElkKGJveElkKSB7XG4gICAgY29uc3QgZG9jcyA9IHRoaXMuX2NvbGxlY3Rpb24uZmluZCh7IGJveElkIH0pLmZldGNoKCk7XG4gICAgcmV0dXJuIChkb2NzKSA/IF8ubWFwKGRvY3MsIGRvYyA9PiBkb2MudXNlcm5hbWUpIDogW107XG4gIH1cblxuICBmaW5kT25lKHVzZXJuYW1lLCBib3hJZCkge1xuICAgIHJldHVybiB0aGlzLl9jb2xsZWN0aW9uLmZpbmRPbmUoeyB1c2VybmFtZSwgYm94SWQgfSk7XG4gIH1cblxuICAvKipcbiAgICogUmVtb3ZlcyBhbGwgb2YgdGhlIGRvY3VtZW50cyBhc3NvY2lhdGVkIHdpdGggdXNlcm5hbWUgZnJvbSB0aGlzIGNvbGxlY3Rpb24uXG4gICAqIEBwYXJhbSB1c2VybmFtZSBUaGUgdXNlciAob3duZXIgb2YgYm94ZXMpLlxuICAgKi9cbiAgcmVtb3ZlQm94ZXNXaXRoT3duZXIodXNlcm5hbWUpIHtcbiAgICB0aGlzLl9jb2xsZWN0aW9uLnJlbW92ZSh7IHVzZXJuYW1lIH0pO1xuICB9XG5cbiAgLyoqXG4gICAqIFJldHVybnMgYW4gb2JqZWN0IHJlcHJlc2VudGluZyBhIHNpbmdsZSBCb3hPd25lciBkb2N1bWVudC5cbiAgICogQHBhcmFtIHtPYmplY3R9IGRvY0lEIC0gVGhlIE1vbmdvLk9iamVjdElEIG9mIHRoZSBCb3hPd25lci5cbiAgICogQHJldHVybnMge09iamVjdH0gLSBBbiBvYmplY3QgcmVwcmVzZW50aW5nIGEgc2luZ2xlIEJveE93bmVyIGRvY3VtZW50LlxuICAgKi9cbiAgZHVtcE9uZShkb2NJRCkge1xuICAgIGNvbnN0IGRvYyA9IHRoaXMuZmluZERvYyhkb2NJRCk7XG4gICAgY29uc3QgdXNlcm5hbWUgPSBkb2MudXNlcm5hbWU7XG4gICAgY29uc3QgYm94SWQgPSBkb2MuYm94SWQ7XG4gICAgcmV0dXJuIHsgdXNlcm5hbWUsIGJveElkIH07XG4gIH1cblxuXG59XG5cbi8qKlxuICogUHJvdmlkZXMgdGhlIHNpbmdsZXRvbiBpbnN0YW5jZSBvZiB0aGlzIGNsYXNzLlxuICovXG5leHBvcnQgY29uc3QgQm94T3duZXJzID0gbmV3IEJveE93bmVyc0NvbGxlY3Rpb24oKTtcbiIsImltcG9ydCB7IE1ldGVvciB9IGZyb20gJ21ldGVvci9tZXRlb3InO1xuaW1wb3J0IHsgQWNjb3VudHMgfSBmcm9tICdtZXRlb3IvYWNjb3VudHMtYmFzZSc7XG5pbXBvcnQgeyBSb2xlcyB9IGZyb20gJ21ldGVvci9hbGFubmluZzpyb2xlcyc7XG5pbXBvcnQgeyBfIH0gZnJvbSAnbG9kYXNoJztcbmltcG9ydCBTaW1wbGVTY2hlbWEgZnJvbSAnc2ltcGwtc2NoZW1hJztcbmltcG9ydCBCYXNlQ29sbGVjdGlvbiBmcm9tICcuLi9iYXNlL0Jhc2VDb2xsZWN0aW9uJztcbmltcG9ydCB7IEJveE93bmVycyB9IGZyb20gJy4vQm94T3duZXJzQ29sbGVjdGlvbic7XG5cbi8qKlxuICogVXNlciBQcm9maWxlcyAoZmlyc3QgYW5kIGxhc3QgbmFtZSwgcm9sZSwgYW5kIHVzZXJuYW1lIChlbWFpbCkuXG4gKiBUbyBjcmVhdGUgYSBuZXcgVXNlciwgY2FsbCBVc2VyUHJvZmlsZXMuZGVmaW5lKCksIHdoaWNoIGJvdGggZGVmaW5lcyB0aGUgcHJvZmlsZSBhbmQgY3JlYXRlcyB0aGUgTWV0ZW9yLnVzZXIuXG4gKiBEb2NzOiBodHRwczovL29wZW4tcG93ZXItcXVhbGl0eS5naXRib29rcy5pby9vcGVuLXBvd2VyLXF1YWxpdHktbWFudWFsL2NvbnRlbnQvZGF0YW1vZGVsL2Rlc2NyaXB0aW9uLmh0bWwjdXNlcnNcbiAqL1xuY2xhc3MgVXNlclByb2ZpbGVzQ29sbGVjdGlvbiBleHRlbmRzIEJhc2VDb2xsZWN0aW9uIHtcblxuICAvKipcbiAgICogQ3JlYXRlcyB0aGUgVXNlciBQcm9maWxlcyBjb2xsZWN0aW9uLlxuICAgKi9cbiAgY29uc3RydWN0b3IoKSB7XG4gICAgc3VwZXIoJ1VzZXJQcm9maWxlcycsIG5ldyBTaW1wbGVTY2hlbWEoe1xuICAgICAgdXNlcm5hbWU6IFN0cmluZyxcbiAgICAgIGZpcnN0TmFtZTogU3RyaW5nLFxuICAgICAgbGFzdE5hbWU6IFN0cmluZyxcbiAgICAgIHJvbGU6IFN0cmluZyxcbiAgICB9KSk7XG4gIH1cblxuICAvKipcbiAgICogRGVmaW5lcyBhIG5ldyBVc2VyUHJvZmlsZSBpZiB1c2VybmFtZSBpcyBub3QgZGVmaW5lZCBpbiBNZXRlb3IudXNlcnMsIGFuZCBhZGRzIHRoZSB1c2VyIHRvIE1ldGVvci51c2Vycy5cbiAgICogVXBkYXRlcyBhbiBleGlzdGluZyBVc2VyIFByb2ZpbGUgaWYgdXNlcm5hbWUgaXMgYWxyZWFkeSBkZWZpbmVkIGluIE1ldGVvci51c2Vycy5cbiAgICogQHBhcmFtIHtTdHJpbmd9IHVzZXJuYW1lIC0gTXVzdCBiZSB0aGUgdXNlcidzIGVtYWlsIGFkZHJlc3MuXG4gICAqIEBwYXJhbSB7U3RyaW5nfSBwYXNzd29yZCAtIFRoZSB1c2VyJ3MgcGFzc3dvcmQuIChPbmx5IHVzZWQgd2hlbiBhZGRpbmcgYSB1c2VyIHRvIE1ldGVvci51c2Vycy4pXG4gICAqIEBwYXJhbSB7U3RyaW5nfSBmaXJzdE5hbWUgLSBUaGUgdXNlcidzIGZpcnN0IG5hbWUuXG4gICAqIEBwYXJhbSB7U3RyaW5nfSBsYXN0TmFtZSAtIFRoZSB1c2VyJ3MgbGFzdCBuYW1lLlxuICAgKiBAcGFyYW0ge1N0cmluZ30gcm9sZSAtIFRoZSByb2xlIG9mIHRoZSB1c2VyOiBlaXRoZXIgJ2FkbWluJyBvciAndXNlcicuXG4gICAqIEBwYXJhbSB7W051bWJlcl19IGJveElkcyAtIEFuIGFycmF5IG9mIFN0cmluZ3MgY29udGFpbmluZyB0aGUgSURzIG9mIHRoZSBib3hlcyB0aGF0IGNhbiBiZSBtYW5hZ2VkIGJ5IHRoaXMgdXNlci5cbiAgICovXG4gIC8vIGVzbGludC1kaXNhYmxlLW5leHQtbGluZSBjbGFzcy1tZXRob2RzLXVzZS10aGlzXG4gIGRlZmluZSh7IHVzZXJuYW1lLCBwYXNzd29yZCwgZmlyc3ROYW1lLCBsYXN0TmFtZSwgYm94SWRzID0gW10sIHJvbGUgPSAndXNlcicgfSkge1xuICAgIGlmIChNZXRlb3IuaXNTZXJ2ZXIpIHtcbiAgICAgIC8vIGJveElkcyBhcnJheSBtdXN0IGNvbnRhaW4gaW50ZWdlcnMuXG4gICAgICBib3hJZHMuZm9yRWFjaChib3hJZCA9PiB7XG4gICAgICAgIGlmICghXy5pc1N0cmluZyhib3hJZCkpIHtcbiAgICAgICAgICB0aHJvdyBuZXcgTWV0ZW9yLkVycm9yKGBBbGwgYm94SWRzIG11c3QgYmUgYSBzdHJpbmc6ICR7Ym94SWR9YCk7XG4gICAgICAgIH1cbiAgICAgIH0pO1xuXG4gICAgICAvLyBSb2xlIG11c3QgYmUgZWl0aGVyICd1c2VyJyBvciAnYWRtaW4nLlxuICAgICAgaWYgKHJvbGUgIT09ICd1c2VyJyAmJiByb2xlICE9PSAnYWRtaW4nKSB7XG4gICAgICAgIHRocm93IG5ldyBNZXRlb3IuRXJyb3IoJ0ludmFsaWQgdXNlciByb2xlIC0gbXVzdCBlaXRoZXIgYmUgXCJ1c2VyXCIgb3IgXCJhZG1pblwiJyk7XG4gICAgICB9XG5cbiAgICAgIC8vIEZpZ3VyZSBvdXQgaWYgdGhlIHVzZXIgaXMgYWxyZWFkeSBkZWZpbmVkIGluIE1ldGVvciBBY2NvdW50cy5cbiAgICAgIGxldCB1c2VyID0gQWNjb3VudHMuZmluZFVzZXJCeVVzZXJuYW1lKHVzZXJuYW1lKTtcbiAgICAgIGxldCB1c2VySWQgPSB1c2VyICYmIHVzZXIuX2lkO1xuICAgICAgLy8gRGVmaW5lIHRoZSBuZXcgdXNlciBpbiBNZXRlb3IgQWNjb3VudHMgaWYgbmVjZXNzYXJ5LlxuICAgICAgaWYgKCF1c2VySWQpIHtcbiAgICAgICAgdXNlcklkID0gQWNjb3VudHMuY3JlYXRlVXNlcih7IHVzZXJuYW1lLCBlbWFpbDogdXNlcm5hbWUsIHBhc3N3b3JkIH0pO1xuICAgICAgICB1c2VyID0gQWNjb3VudHMuZmluZFVzZXJCeVVzZXJuYW1lKHVzZXJuYW1lKTtcbiAgICAgIH1cblxuICAgICAgLy8gQ3JlYXRlIG9yIG1vZGlmeSB0aGUgVXNlclByb2ZpbGVzIGRvY3VtZW50IGFzc29jaWF0ZWQgd2l0aCB0aGlzIHVzZXJuYW1lLlxuICAgICAgdGhpcy5fY29sbGVjdGlvbi51cHNlcnQoeyB1c2VybmFtZSB9LCB7ICRzZXQ6IHsgZmlyc3ROYW1lLCBsYXN0TmFtZSwgcm9sZSB9IH0pO1xuICAgICAgY29uc3QgcHJvZmlsZUlkID0gdGhpcy5maW5kT25lKHsgdXNlcm5hbWUgfSkuX2lkO1xuXG4gICAgICAvLyBTZXQgdGhlIHJvbGUgdXNpbmcgdGhlIFJvbGVzIHBhY2thZ2UuIFRoaXMgbWFrZXMgaXQgZWFzaWVyIHRvIGRvIFJvbGUtYmFzZWQgZGVjaXNpb25zIG9uIGNsaWVudC5cbiAgICAgIGlmICh1c2VySWQpIHtcbiAgICAgICAgUm9sZXMuYWRkVXNlcnNUb1JvbGVzKHVzZXJJZCwgcm9sZSk7XG4gICAgICB9XG5cbiAgICAgIC8vIFJlbW92ZSBhbnkgY3VycmVudCBib3ggb3duZXJzaGlwcywgYWRkIG5ldyBvd25lcnNoaXBzIGFzIHNwZWNpZmllZCBpbiBib3hJZHMuXG4gICAgICBCb3hPd25lcnMucmVtb3ZlQm94ZXNXaXRoT3duZXIodXNlcm5hbWUpO1xuICAgICAgYm94SWRzLm1hcChib3hJZCA9PiBCb3hPd25lcnMuZGVmaW5lKHsgdXNlcm5hbWUsIGJveElkIH0pKTtcblxuICAgICAgLy8gUmV0dXJuIHRoZSBwcm9maWxlSUQgaWYgZXhlY3V0ZWQgb24gdGhlIHNlcnZlci5cbiAgICAgIHJldHVybiBwcm9maWxlSWQ7XG4gICAgfVxuICAgIC8vIFJldHVybiB1bmRlZmluZWQgaWYgZXhlY3V0ZWQgb24gdGhlIGNsaWVudCAod2hpY2ggc2hvdWxkbid0IGV2ZXIgaGFwcGVuLilcbiAgICByZXR1cm4gdW5kZWZpbmVkO1xuICB9XG5cbiAgLyoqXG4gICAqIFJldHVybnMgdGhlIHByb2ZpbGUgZG9jdW1lbnQgY29ycmVzcG9uZGluZyB0byB1c2VybmFtZSwgb3IgdGhyb3dzIGVycm9yIGlmIG5vdCBmb3VuZC5cbiAgICogQHBhcmFtIHVzZXJuYW1lXG4gICAqIEByZXR1cm5zIHtPYmplY3R9IFRoZSBwcm9maWxlIGRvY3VtZW50LlxuICAgKiBAdGhyb3dzIHsgTWV0ZW9yLkVycm9yIH0gSWYgdGhlIHByb2ZpbGUgZG9jdW1lbnQgZG9lcyBub3QgZXhpc3QgZm9yIHRoaXMgdXNlcm5hbWUuXG4gICAqL1xuICBmaW5kQnlVc2VybmFtZSh1c2VybmFtZSkge1xuICAgIGNvbnN0IHByb2ZpbGUgPSB0aGlzLl9jb2xsZWN0aW9uLmZpbmRPbmUoeyB1c2VybmFtZSB9KTtcbiAgICBpZiAocHJvZmlsZSkge1xuICAgICAgcmV0dXJuIHByb2ZpbGU7XG4gICAgfVxuICAgIHRocm93IG5ldyBNZXRlb3IuRXJyb3IoYENvdWxkIG5vdCBmaW5kIHByb2ZpbGUgY29ycmVzcG9uZGluZyB0byAke3VzZXJuYW1lfWApO1xuICB9XG5cbiAgLyoqXG4gICAqIFJldHVybnMgYW4gb2JqZWN0IHJlcHJlc2VudGluZyBhIHNpbmdsZSBVc2VyUHJvZmlsZS5cbiAgICogQHBhcmFtIHtPYmplY3R9IGRvY0lEIC0gVGhlIE1vbmdvLk9iamVjdElEIG9mIHRoZSBVc2VyLlxuICAgKiBAcmV0dXJucyB7T2JqZWN0fSAtIEFuIG9iamVjdCByZXByZXNlbnRpbmcgYSBzaW5nbGUgVXNlclByb2ZpbGUuXG4gICAqL1xuICBkdW1wT25lKGRvY0lEKSB7XG4gICAgY29uc3QgZG9jID0gdGhpcy5maW5kRG9jKGRvY0lEKTtcbiAgICBjb25zdCB1c2VybmFtZSA9IGRvYy51c2VybmFtZTtcbiAgICBjb25zdCBmaXJzdE5hbWUgPSBkb2MuZmlyc3ROYW1lO1xuICAgIGNvbnN0IGxhc3ROYW1lID0gZG9jLmxhc3ROYW1lO1xuICAgIGNvbnN0IHJvbGUgPSBkb2Mucm9sZXM7XG4gICAgcmV0dXJuIHsgdXNlcm5hbWUsIGZpcnN0TmFtZSwgbGFzdE5hbWUsIHJvbGUgfTtcbiAgfVxuXG4gIC8qKlxuICAgKiBSZW1vdmVzIHRoZSB1c2VyIGZyb20gTWV0ZW9yLnVzZXJzIGFuZCBmcm9tIFVzZXJQcm9maWxlcy5cbiAgICogSWYgdXNlcm5hbWUgZG9lcyBub3QgZXhpc3QsIHRoZW4gcmV0dXJucyBmYWxzZS5cbiAgICogV2lsbCBvbmx5IHdvcmsgb24gdGhlIHNlcnZlci1zaWRlLlxuICAgKiBAcGFyYW0gdXNlcm5hbWUgQSB1c2VybmFtZVxuICAgKiBAcmV0dXJucyBUcnVlIGlmIHRoZSB1c2VybmFtZSBleGlzdHMgYW5kIHdhcyBkZWxldGVkLCBmYWxzZSBvdGhlcndpc2UuXG4gICAqL1xuICByZW1vdmUodXNlcm5hbWUpIHtcbiAgICBpZiAoTWV0ZW9yLmlzU2VydmVyKSB7XG4gICAgICBjb25zdCBwcm9maWxlID0gdGhpcy5maW5kT25lKHsgdXNlcm5hbWUgfSk7XG4gICAgICBpZiAocHJvZmlsZSkge1xuICAgICAgICB0aGlzLl9jb2xsZWN0aW9uLnJlbW92ZSh7IHVzZXJuYW1lIH0pO1xuICAgICAgICBjb25zdCB1c2VyID0gQWNjb3VudHMuZmluZFVzZXJCeVVzZXJuYW1lKHVzZXJuYW1lKTtcbiAgICAgICAgaWYgKHVzZXIpIHtcbiAgICAgICAgICBNZXRlb3IudXNlcnMucmVtb3ZlKHVzZXIuX2lkKTtcbiAgICAgICAgfVxuICAgICAgICByZXR1cm4gdHJ1ZTtcbiAgICAgIH1cbiAgICB9XG4gICAgcmV0dXJuIGZhbHNlO1xuICB9XG5cbiAgLyoqXG4gICAqIFJlbW92ZXMgYWxsIFVzZXJQcm9maWxlcyBhbmQgYXNzb2NpYXRlZCBNZXRlb3IudXNlcnMuXG4gICAqIFRoaXMgaXMgaW1wbGVtZW50ZWQgYnkgbWFwcGluZyB0aHJvdWdoIGFsbCBlbGVtZW50cyBiZWNhdXNlIG1pbmktbW9uZ28gZG9lcyBub3QgaW1wbGVtZW50IHRoZSByZW1vdmUgb3BlcmF0aW9uLlxuICAgKiBXaWxsIG9ubHkgd29yayBvbiB0aGUgc2VydmVyIHNpZGUuXG4gICAqIHJlbW92ZUFsbCBzaG91bGQgb25seSB1c2VkIGZvciB0ZXN0aW5nIHB1cnBvc2VzLCBzbyBpdCBkb2Vzbid0IG5lZWQgdG8gYmUgZWZmaWNpZW50LlxuICAgKiBAcmV0dXJucyB0cnVlXG4gICAqL1xuICByZW1vdmVBbGwoKSB7XG4gICAgaWYgKE1ldGVvci5pc1NlcnZlcikge1xuICAgICAgY29uc3QgdXNlclByb2ZpbGVzID0gdGhpcy5fY29sbGVjdGlvbi5maW5kKCkuZmV0Y2goKTtcbiAgICAgIGNvbnN0IGluc3RhbmNlID0gdGhpcztcbiAgICAgIF8uZm9yRWFjaCh1c2VyUHJvZmlsZXMsIChwcm9maWxlKSA9PiBpbnN0YW5jZS5yZW1vdmUocHJvZmlsZS51c2VybmFtZSkpO1xuICAgIH1cbiAgICByZXR1cm4gdHJ1ZTtcbiAgfVxufVxuXG4vKipcbiAqIFByb3ZpZGVzIHRoZSBzaW5nbGV0b24gaW5zdGFuY2Ugb2YgdGhpcyBjbGFzcy5cbiAqIEB0eXBlIHtVc2VyUHJvZmlsZXNDb2xsZWN0aW9ufVxuICovXG5leHBvcnQgY29uc3QgVXNlclByb2ZpbGVzID0gbmV3IFVzZXJQcm9maWxlc0NvbGxlY3Rpb24oKTtcbiIsImltcG9ydCAnLi9Cb3hPd25lcnNDb2xsZWN0aW9uJztcbmltcG9ydCAnLi9Vc2VyUHJvZmlsZXNDb2xsZWN0aW9uJztcblxuIiwiaW1wb3J0ICcuLi8uLi9hcGkvdXNlcnMnO1xuaW1wb3J0ICcuLi8uLi9hcGkvbWVhc3VyZW1lbnRzJztcbmltcG9ydCAnLi4vLi4vYXBpL3RyZW5kcyc7XG5pbXBvcnQgJy4uLy4uL2FwaS9ib3gtZXZlbnRzJztcbmltcG9ydCAnLi4vLi4vYXBpL2V2ZW50cyc7XG5pbXBvcnQgJy4uLy4uL2FwaS9vcHEtYm94ZXMnO1xuaW1wb3J0ICcuLi8uLi9hcGkvZnMtZmlsZXMnO1xuaW1wb3J0ICcuLi8uLi9hcGkvZnMtY2h1bmtzJztcbiIsImltcG9ydCAnLi9zeW5jZWQtY3Jvbic7XG5pbXBvcnQgJy4vcHVibGljYXRpb25zJztcbmltcG9ydCAnLi9pbml0LXVzZXJzJztcbmltcG9ydCAnLi9pbml0LWJveGVzJztcbiIsImltcG9ydCB7IE1ldGVvciB9IGZyb20gJ21ldGVvci9tZXRlb3InO1xuaW1wb3J0IHsgT3BxQm94ZXMgfSBmcm9tICcuLi8uLi9hcGkvb3BxLWJveGVzL09wcUJveGVzQ29sbGVjdGlvbic7XG5cblxuZnVuY3Rpb24gaW5pdEJveGVzKCkge1xuICAvLyBEZWZhdWx0IGJveGVzIHRvIGFuIGVtcHR5IGFycmF5IGlmIHRoZXkgYXJlIG5vdCBzcGVjaWZpZWQgaW4gdGhlIHNldHRpbmdzIGZpbGUuXG4gIGNvbnN0IGJveGVzID0gTWV0ZW9yLnNldHRpbmdzLm9wcUJveGVzIHx8IFtdO1xuICBjb25zb2xlLmxvZyhgSW5pdGlhbGl6aW5nICR7Ym94ZXMubGVuZ3RofSBPUFEgYm94ZXMuYCk7XG4gIGJveGVzLm1hcChib3ggPT4gT3BxQm94ZXMuZGVmaW5lKGJveCkpO1xufVxuXG5NZXRlb3Iuc3RhcnR1cCgoKSA9PiB7XG4gIGluaXRCb3hlcygpO1xufSk7XG4iLCJpbXBvcnQgeyBNZXRlb3IgfSBmcm9tICdtZXRlb3IvbWV0ZW9yJztcbmltcG9ydCB7IFVzZXJQcm9maWxlcyB9IGZyb20gJy4uLy4uL2FwaS91c2Vycy9Vc2VyUHJvZmlsZXNDb2xsZWN0aW9uJztcblxuXG5mdW5jdGlvbiBpbml0VXNlcnMoKSB7XG4gIC8vIERlZmF1bHQgcHJvZmlsZXMgdG8gYW4gZW1wdHkgYXJyYXkgaWYgdGhleSBhcmUgbm90IHNwZWNpZmllZCBpbiB0aGUgc2V0dGluZ3MgZmlsZS5cbiAgY29uc3QgcHJvZmlsZXMgPSBNZXRlb3Iuc2V0dGluZ3MudXNlclByb2ZpbGVzIHx8IFtdO1xuICBjb25zb2xlLmxvZyhgSW5pdGlhbGl6aW5nICR7cHJvZmlsZXMubGVuZ3RofSB1c2VyIHByb2ZpbGVzLmApO1xuICBwcm9maWxlcy5tYXAocHJvZmlsZSA9PiBVc2VyUHJvZmlsZXMuZGVmaW5lKHByb2ZpbGUpKTtcbn1cblxuTWV0ZW9yLnN0YXJ0dXAoKCkgPT4ge1xuICBpbml0VXNlcnMoKTtcbn0pO1xuIiwiaW1wb3J0IHsgQm94RXZlbnRzIH0gZnJvbSAnLi4vLi4vYXBpL2JveC1ldmVudHMvQm94RXZlbnRzQ29sbGVjdGlvbic7XG5pbXBvcnQgeyBCb3hPd25lcnMgfSBmcm9tICcuLi8uLi9hcGkvdXNlcnMvQm94T3duZXJzQ29sbGVjdGlvbic7XG5pbXBvcnQgeyBFdmVudHMgfSBmcm9tICcuLi8uLi9hcGkvZXZlbnRzL0V2ZW50c0NvbGxlY3Rpb24nO1xuaW1wb3J0IHsgVHJlbmRzIH0gZnJvbSAnLi4vLi4vYXBpL3RyZW5kcy9UcmVuZHNDb2xsZWN0aW9uLmpzJztcbmltcG9ydCB7IFN5c3RlbVN0YXRzIH0gZnJvbSAnLi4vLi4vYXBpL3N5c3RlbS1zdGF0cy9TeXN0ZW1TdGF0c0NvbGxlY3Rpb24uanMnO1xuaW1wb3J0IHsgT3BxQm94ZXMgfSBmcm9tICcuLi8uLi9hcGkvb3BxLWJveGVzL09wcUJveGVzQ29sbGVjdGlvbic7XG5pbXBvcnQgeyBNZWFzdXJlbWVudHMgfSBmcm9tICcuLi8uLi9hcGkvbWVhc3VyZW1lbnRzL01lYXN1cmVtZW50c0NvbGxlY3Rpb24nO1xuaW1wb3J0IHsgVXNlclByb2ZpbGVzIH0gZnJvbSAnLi4vLi4vYXBpL3VzZXJzL1VzZXJQcm9maWxlc0NvbGxlY3Rpb24nO1xuXG5Cb3hFdmVudHMucHVibGlzaCgpO1xuQm94T3duZXJzLnB1Ymxpc2goKTtcbkV2ZW50cy5wdWJsaXNoKCk7XG5NZWFzdXJlbWVudHMucHVibGlzaCgpO1xuT3BxQm94ZXMucHVibGlzaCgpO1xuU3lzdGVtU3RhdHMucHVibGlzaCgpO1xuVHJlbmRzLnB1Ymxpc2goKTtcblVzZXJQcm9maWxlcy5wdWJsaXNoKCk7XG4iLCJpbXBvcnQgeyBNZXRlb3IgfSBmcm9tICdtZXRlb3IvbWV0ZW9yJztcbmltcG9ydCB7IFN5bmNlZENyb24gfSBmcm9tICdtZXRlb3IvcGVyY29sYXRlOnN5bmNlZC1jcm9uJztcbmltcG9ydCB7IFN5c3RlbVN0YXRzIH0gZnJvbSAnLi4vLi4vYXBpL3N5c3RlbS1zdGF0cy9TeXN0ZW1TdGF0c0NvbGxlY3Rpb24uanMnO1xuXG5TeW5jZWRDcm9uLmNvbmZpZyh7XG4gIGxvZzogTWV0ZW9yLnNldHRpbmdzLnN5bmNlZENyb25Mb2dnaW5nLFxufSk7XG5cbmZ1bmN0aW9uIHN0YXJ0dXBTeXN0ZW1TdGF0c0Nyb25qb2IoKSB7XG4gIC8vIERlZmF1bHQgdGhlIHVwZGF0ZSBpbnRlcnZhbCB0byA2MCBzZWNvbmRzIGlmIG5vdCBzdXBwbGllZCBpbiBjb25maWd1cmF0aW9uIGZpbGUuXG4gIGNvbnN0IHVwZGF0ZUludGVydmFsU2Vjb25kcyA9IE1ldGVvci5zZXR0aW5ncy5zeXN0ZW1TdGF0c1VwZGF0ZUludGVydmFsU2Vjb25kcyB8fCA2MDtcbiAgU3luY2VkQ3Jvbi5hZGQoe1xuICAgIG5hbWU6ICdVcGRhdGUgdGhlIFN5c3RlbVN0YXRzIGNvbGxlY3Rpb24gd2l0aCBjdXJyZW50IGNvbGxlY3Rpb24gY291bnRzJyxcbiAgICBzY2hlZHVsZShwYXJzZXIpIHtcbiAgICAgIHJldHVybiBwYXJzZXIudGV4dChgZXZlcnkgJHt1cGRhdGVJbnRlcnZhbFNlY29uZHN9IHNlY29uZHNgKTsgLy8gUGFyc2VyIGlzIGEgbGF0ZXIuanMgcGFyc2Ugb2JqZWN0LlxuICAgIH0sXG4gICAgam9iKCkge1xuICAgICAgU3lzdGVtU3RhdHMudXBkYXRlQ291bnRzKCk7XG4gICAgfSxcbiAgfSk7XG4gIGNvbnNvbGUubG9nKGBTdGFydGluZyBTeW5jZWRDcm9uIHRvIHVwZGF0ZSBTeXN0ZW0gU3RhdHMgZXZlcnkgJHt1cGRhdGVJbnRlcnZhbFNlY29uZHN9IHNlY29uZHMuYCk7XG4gIFN5bmNlZENyb24uc3RhcnQoKTtcbn1cblxuTWV0ZW9yLnN0YXJ0dXAoKCkgPT4ge1xuICBzdGFydHVwU3lzdGVtU3RhdHNDcm9uam9iKCk7XG59KTtcbiIsImltcG9ydCB7IE1ldGVvciB9IGZyb20gJ21ldGVvci9tZXRlb3InO1xuaW1wb3J0IHsgY2hlY2sgfSBmcm9tICdtZXRlb3IvY2hlY2snO1xuaW1wb3J0IE1vbWVudCBmcm9tICdtb21lbnQnO1xuXG4vKipcbiAqIE91dHB1dHMgYSBwcm9ncmVzcyBiYXIgaW4gdGhlIGNvbnNvbGUgdG8gcmVwcmVzZW50IGFuIG9uZ29pbmcgb3BlcmF0aW9uLlxuICogTXVzdCBiZSB1cGRhdGVkIHdpdGggdXBkYXRlQmFyKCksIGFuZCBjbG9zZWQgd2l0aCBjbGVhckludGVydmFsKCksIGJvdGggb2Ygd2hpY2ggYXJlIHJldHVybmVkIGJ5IHRoaXMgZnVuY3Rpb24uXG4gKiBAcGFyYW0ge051bWJlcn0gdG90YWwgLSBUaGUgbnVtYmVyIHJlcHJlc2VudGluZyB0aGUgZW5kIGluZGV4IG9mIHRoZSBvcGVyYXRpb24gKGVnLiB0aGUgY29sbGVjdGlvbiBzaXplKVxuICogQHBhcmFtIHtOdW1iZXJ9IHVwZGF0ZVJhdGUgLSBUaGUgbnVtYmVyIG9mIG1pbGxpc2Vjb25kcyB0byB3YWl0IGJldHdlZW4gZWFjaCBwcm9ncmVzcyBiYXIgdXBkYXRlLlxuICogQHBhcmFtIHtTdHJpbmd9IG1lc3NhZ2UgLSBBbiBpbmZvcm1hdGl2ZSBtZXNzYWdlIHBsYWNlZCBuZXh0IHRvIHRoZSBwcm9ncmVzcyBiYXIuXG4gKiBAcmV0dXJucyB7T2JqZWN0fSBBbiBvYmplY3Qgd2l0aCBhIGNsZWFySW50ZXJ2YWwoKSBhbmQgdXBkYXRlQmFyKCkgZnVuY3Rpb25zLlxuICovXG5leHBvcnQgZnVuY3Rpb24gcHJvZ3Jlc3NCYXJTZXR1cCh0b3RhbCwgdXBkYXRlUmF0ZSwgbWVzc2FnZSkge1xuICBsZXQgdGltZXJIYW5kbGUgPSBudWxsO1xuICBsZXQgY3VycmVudFZhbCA9IDA7XG4gIGNvbnN0IHRvdGFsVmFsID0gdG90YWwgLSAxOyAvLyBBc3N1bWluZyAwIGJhc2VkIGNvdW50aW5nLlxuXG4gIGlmICghdGltZXJIYW5kbGUpIHtcbiAgICB0aW1lckhhbmRsZSA9IE1ldGVvci5zZXRJbnRlcnZhbCgoKSA9PiB7XG4gICAgICBwcm9ncmVzc0JhclByaW50ZXIoY3VycmVudFZhbCwgdG90YWxWYWwsICc9JywgMzAsIG1lc3NhZ2UpOyAvLyBlc2xpbnQtZGlzYWJsZS1saW5lIG5vLXVzZS1iZWZvcmUtZGVmaW5lXG4gICAgfSwgdXBkYXRlUmF0ZSk7XG4gIH1cblxuICByZXR1cm4ge1xuICAgIGNsZWFySW50ZXJ2YWwoKSB7XG4gICAgICBpZiAodGltZXJIYW5kbGUpIE1ldGVvci5jbGVhckludGVydmFsKHRpbWVySGFuZGxlKTtcbiAgICAgIHByb2Nlc3Muc3Rkb3V0LndyaXRlKCdcXG4nKTsgLy8gRmluYWwgbmV3bGluZSBhZnRlciBwcm9ncmVzc0JhclByaW50ZXIgaXMgZG9uZS5cbiAgICB9LFxuICAgIHVwZGF0ZUJhcihuZXdDdXJyZW50KSB7XG4gICAgICBjdXJyZW50VmFsID0gbmV3Q3VycmVudDtcbiAgICB9LFxuICB9O1xufVxuXG4vKipcbiAqIFByaW50cyB0aGUgY3VycmVudCBwcm9ncmVzcyBiYXIgc3RhdGUgdG8gdGhlIGNvbnNvbGUuXG4gKiBAcGFyYW0ge051bWJlcn0gY3VycmVudCAtIFRoZSBjdXJyZW50IHBvc2l0aW9uIGluIHRoZSBvcGVyYXRpb24gKGVnLiB0aGUgY3VycmVudCBpbmRleCBwb3NpdGlvbiBkdXJpbmcgaXRlcmF0aW9uKVxuICogQHBhcmFtIHtOdW1iZXJ9IHRvdGFsIC0gVGhlIGVuZCBwb3NpdGlvbiBvZiB0aGUgb3BlcmF0aW9uIChlZy4gdGhlIHNpemUgb2YgYSBjb2xsZWN0aW9uLCBsZW5ndGggb2YgYW4gYXJyYXkpLlxuICogQHBhcmFtIHtTdHJpbmd9IHRpY2tDaGFyIC0gVGhlIGNoYXJhY3RlciB0byByZXByZXNlbnQgYSBzaW5nbGUgdGljayBtYXJrIGluIHRoZSBwcm9ncmVzcyBiYXIuXG4gKiBAcGFyYW0ge051bWJlcn0gbWF4VGlja3MgLSBUaGUgdG90YWwgbnVtYmVyIG9mIHRpY2tzIHRoZSBwcm9ncmVzcyBiYXIgc2hvdWxkIGhhdmUuXG4gKiBAcGFyYW0ge1N0cmluZ30gbWVzc2FnZSAtIEFuIGluZm9ybWF0aXZlIG1lc3NhZ2UgcGxhY2VkIG5leHQgdG8gdGhlIHByb2dyZXNzIGJhci5cbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIHByb2dyZXNzQmFyUHJpbnRlcihjdXJyZW50LCB0b3RhbCwgdGlja0NoYXIsIG1heFRpY2tzLCBtZXNzYWdlKSB7XG4gIC8vIENyZWF0ZSAnZW1wdHknIHByb2dyZXNzIGJhciwgaW50ZXJuYWxseSByZXByZXNlbnRlZCBhcyBhbiBhcnJheS4gU2V0IHN0YXJ0IGFuZCBlbmQgYnJhY2tldHMgb2YgdGhlIHByb2dyZXNzIGJhci5cbiAgY29uc3QgcHJvZ3Jlc3NCYXIgPSBBcnJheS5mcm9tKCcuJy5yZXBlYXQobWF4VGlja3MgKyAyKSk7XG4gIHByb2dyZXNzQmFyWzBdID0gJ1snO1xuICBwcm9ncmVzc0Jhcltwcm9ncmVzc0Jhci5sZW5ndGggLSAxXSA9ICddJztcblxuICBjb25zdCBwcm9ncmVzc1BlcmNlbnRhZ2UgPSAoY3VycmVudCAvIHRvdGFsKSAqIDEwMDtcbiAgY29uc3QgY3VycmVudEJhcnMgPSBtYXhUaWNrcyAqIChwcm9ncmVzc1BlcmNlbnRhZ2UgLyAxMDAuMCk7XG4gIHByb2dyZXNzQmFyLmZpbGwodGlja0NoYXIsIDEsIGN1cnJlbnRCYXJzICsgMSk7XG4gIC8vIHByb2Nlc3Muc3Rkb3V0LndyaXRlKCdcXDAzM1tGJyk7IC8vIEFOU0kgY29kZSB0byBtb3ZlIGN1cnNvciB1cCBvbmUgbGluZS5cbiAgcHJvY2Vzcy5zdGRvdXQud3JpdGUoJ1xceDFCW0YnKTsgLy8gVXNpbmcgaGV4IGluc3RlYWQgb2Ygb2N0YWwgY29kZSBiZWNhdXNlIG9mIGVzbGludCBwYXJzZXIgZXJyb3IuXG4gIHByb2Nlc3Muc3Rkb3V0LndyaXRlKGBcXG5cXHIke21lc3NhZ2V9ICR7cHJvZ3Jlc3NCYXIuam9pbignJyl9ICgke3Byb2dyZXNzUGVyY2VudGFnZS50b0ZpeGVkKDEpfSUpYCk7XG59XG5cbi8qKlxuICogQ2FsY3VsYXRlcyB0aGUgYXBwcm9wcmlhdGUgY29sb3IgcmVwcmVzZW50YXRpb24gb2YgYSBudW1lcmljIHZhbHVlLiBFdmFsdWF0ZWQgb24gYSBsaW5lYXIgc2NhbGUuXG4gKiBAcGFyYW0ge051bWJlcn0gZGF0YVZhbHVlIC0gVGhlIHZhbHVlIHRvIGV2YWx1YXRlIGEgY29sb3IgZm9yLlxuICogQHBhcmFtIHtOdW1iZXJ9IG1pblZhbHVlIC0gVGhlIG1pbmltdW0gdmFsdWUgdG8gYmUgcmVwcmVzZW50ZWQgd2l0aCB0aGUgZmlyc3QgY29sb3IgaW4gdGhlIGNvbG9yUmFuZ2UgYXJyYXkuXG4gKiBAcGFyYW0ge051bWJlcn0gbWF4VmFsdWUgLSBUaGUgbWF4aW11bSB2YWx1ZSB0byBiZSByZXByZXNlbnRlZCB3aXRoIHRoZSBsYXN0IGNvbG9yIGluIHRoZSBjb2xvclJhbmdlIGFycmF5LlxuICogQHBhcmFtIHtTdHJpbmdbXX0gY29sb3JSYW5nZSAtIEFuIGFycmF5IG9mIGhleCBjb2xvcnMsIG9yZGVyZWQgZnJvbSBsZWFzdCB0byBncmVhdGVzdCBpbnRlbmRlZCBjb2xvciB2YWx1ZS5cbiAqIEByZXR1cm5zIHtTdHJpbmd9IC0gVGhlIGNhbGN1bGF0ZWQgaGV4IGNvbG9yIHJlcHJlc2VudGF0aW9uIG9mIHRoZSBnaXZlbiB2YWx1ZS5cbiAqL1xuZXhwb3J0IGNvbnN0IGNvbG9yUXVhbnRpZnkgPSAoZGF0YVZhbHVlLCBtaW5WYWx1ZSwgbWF4VmFsdWUsIGNvbG9yUmFuZ2UpID0+IHtcbiAgY2hlY2soZGF0YVZhbHVlLCBOdW1iZXIpO1xuICBjaGVjayhtaW5WYWx1ZSwgTnVtYmVyKTtcbiAgY2hlY2sobWF4VmFsdWUsIE51bWJlcik7XG4gIGNoZWNrKGNvbG9yUmFuZ2UsIFtTdHJpbmddKTtcblxuICAvLyBEb21haW5EaWZmZXJlbmNlIC8gTnVtQ29sb3JzXG4gIC8vIEdpdmVzIHVzIHRoZSB2YWx1ZSB0aGF0IGV2ZW5seSBzcGxpdHMgdXAgdGhlIGRhdGFEb21haW4gYmFzZWQgb24gdGhlIGdpdmVuIG51bWJlciBvZiBjb2xvcnMuXG4gIGNvbnN0IGRhdGFEb21haW5JbmNyZW1lbnQgPSBNYXRoLmFicyhtYXhWYWx1ZSAtIG1pblZhbHVlKSAvIGNvbG9yUmFuZ2UubGVuZ3RoO1xuXG4gIGxldCByZXN1bHRDb2xvciA9IG51bGw7XG4gIGZvciAobGV0IGkgPSAwOyBpIDwgY29sb3JSYW5nZS5sZW5ndGg7IGkrKykge1xuICAgIGlmIChkYXRhVmFsdWUgPCBtaW5WYWx1ZSArIChkYXRhRG9tYWluSW5jcmVtZW50ICogKGkgKyAxKSkpIHtcbiAgICAgIHJlc3VsdENvbG9yID0gY29sb3JSYW5nZVtpXTtcbiAgICAgIGJyZWFrO1xuICAgIH1cbiAgfVxuXG4gIC8vIFRha2VzIGNhcmUgb2YgY2FzZSB3aGVyZSBkYXRhVmFsdWUgaXMgbGFyZ2VyIHRoYW4gbWF4VmFsdWUgKGNob29zZXMgdGhlIGxhc3QgY29sb3IpLiBOb3RlIHRoYXQgdGhlIGFib3ZlIGxvb3BcbiAgLy8gd2lsbCB0YWtlIGNhcmUgb2YgdGhlIGNhc2Ugd2hlcmUgZGF0YVZhbHVlIGlzIHNtYWxsZXIgdGhhbiBtaW5WYWx1ZSAoY2hvb3NlcyB0aGUgZmlyc3QgY29sb3IpXG4gIGlmICghcmVzdWx0Q29sb3IpIHJlc3VsdENvbG9yID0gY29sb3JSYW5nZVtjb2xvclJhbmdlLmxlbmd0aCAtIDFdO1xuXG4gIHJldHVybiByZXN1bHRDb2xvcjtcbn07XG5cbi8qKlxuICogUmV0dXJucyBhIHVuaXF1ZSBzdHJpbmcgcmVwcmVzZW50YXRpb24gb2YgdGhlIGdpdmVuIGRhdGUgJ3JvdW5kZWQnIHRvIHRoZSBkZXNpcmVkIHVuaXQgb2YgdGltZS5cbiAqIEBwYXJhbSB7RGF0ZX0gZGF0ZSAtIFRoZSBkYXRlIG9iamVjdCB0byBldmFsdWF0ZS5cbiAqIEBwYXJhbSB0aW1lVW5pdCAtIFRoZSB1bml0IG9mIHRpbWUgdG8gcm91bmQgdG8uIEFsbG93ZWQgdmFsdWVzOiAneWVhcicsICdtb250aCcsICd3ZWVrJywgJ2RheScsXG4gKiAnZGF5T2ZNb250aCcsICdob3VyT2ZEYXknXG4gKiBAcmV0dXJucyB7U3RyaW5nfSAtIFRoZSBhcHByb3ByaWF0ZSBzdHJpbmcgdmFsdWUgb2YgdGhlIGdpdmVuIERhdGUsIGJhc2VkIG9uIHRoZSBnaXZlbiB1bml0IG9mIHRpbWUuXG4gKi9cbmV4cG9ydCBjb25zdCB0aW1lVW5pdFN0cmluZyA9IChkYXRlLCB0aW1lVW5pdCkgPT4ge1xuICBjb25zdCBtRGF0ZSA9IE1vbWVudChkYXRlKTtcbiAgY29uc3QgaG91ciA9IG1EYXRlLmhvdXIoKTsgLy8gMC0yM1xuICBjb25zdCBkYXlPZk1vbnRoID0gbURhdGUuZGF0ZSgpOyAvLyAxLTMxXG4gIGNvbnN0IGRheSA9IG1EYXRlLmRheU9mWWVhcigpOyAvLyAxLTM2NlxuICBjb25zdCB3ZWVrID0gbURhdGUud2VlaygpOyAvLyAxLTUyXG4gIGNvbnN0IG1vbnRoID0gbURhdGUubW9udGgoKTsgLy8gMC0xMVxuICBjb25zdCB5ZWFyID0gbURhdGUueWVhcigpOyAvLyA0IGRpZ2l0IHllYXJcblxuICAvLyBBbGwga2V5cyBhcmUgYXBwZW5kZWQgd2l0aCB5ZWFyIHRvIGVuc3VyZSB1bmlxdWVuZXNzIG9mIGtleSAoaW4gY2FzZSB3ZSdyZSBnaXZlbiBhIGxvbmcgdGltZSByYW5nZSkuXG4gIGxldCB0aW1lVW5pdEtleTtcbiAgc3dpdGNoICh0aW1lVW5pdCkge1xuICAgIGNhc2UgJ2hvdXJPZkRheSc6XG4gICAgICAvLyBIb3VyIG9mIGRheS4gRm9ybWF0OiBob3VyLWRheS15ZWFyLiBFLmcuIDIzLTM2NS0yMDE0LCA0LTEyNS0xOTk5LCBldGMuXG4gICAgICB0aW1lVW5pdEtleSA9IGAke2hvdXJ9LSR7ZGF5fS0ke3llYXJ9YDtcbiAgICAgIGJyZWFrO1xuICAgIGNhc2UgJ2RheU9mTW9udGgnOlxuICAgICAgLy8gRGF5IG9mIG1vbnRoLiBGb3JtYXQ6IGRheU9mTW9udGgtbW9udGgteWVhci4gRS5nLiAyOC0xMS0yMDA4LCAzMS00LTIwMTIsIGV0Yy5cbiAgICAgIHRpbWVVbml0S2V5ID0gYCR7ZGF5T2ZNb250aH0tJHttb250aH0tJHt5ZWFyfWA7XG4gICAgICBicmVhaztcbiAgICBjYXNlICdkYXknOlxuICAgICAgLy8gRGF5IG9mIHllYXIuIEZvcm1hdDogZGF5T2ZZZWFyLXllYXIuIEUuZy4gMzY1LTIwMDIsIDE0Ny0xOTQ1LCBldGMuXG4gICAgICB0aW1lVW5pdEtleSA9IGAke2RheX0tJHt5ZWFyfWA7XG4gICAgICBicmVhaztcbiAgICBjYXNlICd3ZWVrJzpcbiAgICAgIC8vIFdlZWsgb2YgeWVhci4gRm9ybWF0OiB3ZWVrLXllYXIuIEUuZy4gNTEtMjAwNiwgNC0xOTk4LCBldGMuXG4gICAgICB0aW1lVW5pdEtleSA9IGAke3dlZWt9LSR7eWVhcn1gO1xuICAgICAgYnJlYWs7XG4gICAgY2FzZSAnbW9udGgnOlxuICAgICAgLy8gTW9udGggb2YgeWVhci4gRm9ybWF0OiBtb250aC15ZWFyLiBFLmcuIDItMTk4OCwgMTEtMjAxNCwgZXRjLlxuICAgICAgdGltZVVuaXRLZXkgPSBgJHttb250aH0tJHt5ZWFyfWA7XG4gICAgICBicmVhaztcbiAgICBjYXNlICd5ZWFyJzpcbiAgICAgIC8vIDQgZGlnaXQgeWVhci4gRm9ybWF0OiB5ZWFyLiBFLmcuIDE5NDUsIDE5OTksIDIwMTcsIGV0Yy5cbiAgICAgIHRpbWVVbml0S2V5ID0geWVhcjtcbiAgICAgIGJyZWFrO1xuICAgIGRlZmF1bHQ6XG4gICAgICBicmVhaztcbiAgfVxuXG4gIHJldHVybiB0aW1lVW5pdEtleTtcbn07XG4iLCJpbXBvcnQgJy4uL2ltcG9ydHMvc3RhcnR1cC9ib3RoL2luZGV4LmpzJztcbmltcG9ydCAnLi4vaW1wb3J0cy9zdGFydHVwL3NlcnZlci9pbmRleC5qcyc7XG4iXX0=
